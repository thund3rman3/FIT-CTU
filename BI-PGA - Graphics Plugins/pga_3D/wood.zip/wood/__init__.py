bl_info = {
    "name" : "Wood",
    "description" : "Procedural Wood Material",
    "author" : "Josef Jech",
    "version" : (1, 0, 0),
    "blender" : (4, 3, 2),
    "location" : "Node",
    "category" : "Material",
}

import bpy
import mathutils
import os

def set_render_engine():
    if bpy.context.scene.render.engine != 'CYCLES':
        bpy.context.scene.render.engine = 'CYCLES'

    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    space.shading.type = 'RENDERED'

    preferences = bpy.context.preferences.addons['cycles'].preferences
    preferences.get_devices()
    available_devices = preferences.devices

    gpu_available = any(device.type in {'CUDA', 'OPTIX', 'HIP'} for device in available_devices)

    if gpu_available:
        preferences.compute_device_type = 'CUDA'
        bpy.context.scene.cycles.device = 'GPU'
        
        for device in available_devices:
            if device.type in {'CUDA', 'OPTIX', 'HIP'}:
                device.use = True
        print("Render engine nastaven na Cycles a výpočet na GPU.")
    else:
        bpy.context.scene.cycles.device = 'CPU'

class Wood(bpy.types.Operator):
    bl_idname = "node.wood"
    bl_label = "Wood"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        mat = bpy.data.materials.new(name = "Wood")
        mat.use_nodes = True
        #initialize Wood node group
        def wood_node_group():

            wood = mat.node_tree
            #start with a clean node tree
            for node in wood.nodes:
                wood.nodes.remove(node)
            wood.color_tag = 'NONE'
            wood.description = ""
            wood.default_group_node_width = 140
            

            #wood interface

            #initialize wood nodes
            #node Material Output
            material_output = wood.nodes.new("ShaderNodeOutputMaterial")
            material_output.name = "Material Output"
            material_output.is_active_output = True
            material_output.target = 'ALL'
            #Displacement
            material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Thickness
            material_output.inputs[3].default_value = 0.0

            #node Principled BSDF
            principled_bsdf = wood.nodes.new("ShaderNodeBsdfPrincipled")
            principled_bsdf.name = "Principled BSDF"
            principled_bsdf.distribution = 'MULTI_GGX'
            principled_bsdf.subsurface_method = 'RANDOM_WALK'
            #Metallic
            principled_bsdf.inputs[1].default_value = 0.0
            #IOR
            principled_bsdf.inputs[3].default_value = 1.5499999523162842
            #Alpha
            principled_bsdf.inputs[4].default_value = 1.0
            #Diffuse Roughness
            principled_bsdf.inputs[7].default_value = 0.0
            #Subsurface Weight
            principled_bsdf.inputs[8].default_value = 0.0
            #Subsurface Radius
            principled_bsdf.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
            #Subsurface Scale
            principled_bsdf.inputs[10].default_value = 0.05000000074505806
            #Subsurface Anisotropy
            principled_bsdf.inputs[12].default_value = 0.0
            #Specular IOR Level
            principled_bsdf.inputs[13].default_value = 0.5
            #Specular Tint
            principled_bsdf.inputs[14].default_value = (1.0, 1.0, 1.0, 1.0)
            #Anisotropic
            principled_bsdf.inputs[15].default_value = 0.0
            #Anisotropic Rotation
            principled_bsdf.inputs[16].default_value = 0.0
            #Tangent
            principled_bsdf.inputs[17].default_value = (0.0, 0.0, 0.0)
            #Transmission Weight
            principled_bsdf.inputs[18].default_value = 0.0
            #Coat Weight
            principled_bsdf.inputs[19].default_value = 0.0
            #Coat Roughness
            principled_bsdf.inputs[20].default_value = 0.029999999329447746
            #Coat IOR
            principled_bsdf.inputs[21].default_value = 1.5
            #Coat Tint
            principled_bsdf.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
            #Coat Normal
            principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
            #Sheen Weight
            principled_bsdf.inputs[24].default_value = 0.0
            #Sheen Roughness
            principled_bsdf.inputs[25].default_value = 0.5
            #Sheen Tint
            principled_bsdf.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
            #Emission Color
            principled_bsdf.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
            #Emission Strength
            principled_bsdf.inputs[28].default_value = 0.0
            #Thin Film Thickness
            principled_bsdf.inputs[29].default_value = 0.0
            #Thin Film IOR
            principled_bsdf.inputs[30].default_value = 1.3300000429153442

            #node Texture Coordinate
            texture_coordinate = wood.nodes.new("ShaderNodeTexCoord")
            texture_coordinate.name = "Texture Coordinate"
            texture_coordinate.from_instancer = False
            if "Cube" in bpy.data.objects:
                texture_coordinate.object = bpy.data.objects["Cube"]

            #node Mapping
            mapping = wood.nodes.new("ShaderNodeMapping")
            mapping.name = "Mapping"
            mapping.vector_type = 'POINT'
            #Location
            mapping.inputs[1].default_value = (0.0, 0.0, 0.0)
            #Rotation
            mapping.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Scale
            mapping.inputs[3].default_value = (5.0, 0.5, 1.0)

            #node Wave Texture
            wave_texture = wood.nodes.new("ShaderNodeTexWave")
            wave_texture.label = "wave grain"
            wave_texture.name = "Wave Texture"
            wave_texture.bands_direction = 'X'
            wave_texture.rings_direction = 'Z'
            wave_texture.wave_profile = 'SIN'
            wave_texture.wave_type = 'BANDS'
            #Scale
            wave_texture.inputs[1].default_value = 5.0
            #Distortion
            wave_texture.inputs[2].default_value = 50.0
            #Detail
            wave_texture.inputs[3].default_value = 15.0
            #Detail Scale
            wave_texture.inputs[4].default_value = 0.5
            #Detail Roughness
            wave_texture.inputs[5].default_value = 0.545918345451355
            #Phase Offset
            wave_texture.inputs[6].default_value = 0.0

            #node Voronoi Texture
            voronoi_texture = wood.nodes.new("ShaderNodeTexVoronoi")
            voronoi_texture.label = "Voronoi suky"
            voronoi_texture.name = "Voronoi Texture"
            voronoi_texture.distance = 'EUCLIDEAN'
            voronoi_texture.feature = 'SMOOTH_F1'
            voronoi_texture.normalize = False
            voronoi_texture.voronoi_dimensions = '3D'
            #Scale
            voronoi_texture.inputs[2].default_value = 5.0
            #Detail
            voronoi_texture.inputs[3].default_value = 0.0
            #Roughness
            voronoi_texture.inputs[4].default_value = 1.0
            #Lacunarity
            voronoi_texture.inputs[5].default_value = 0.0
            #Smoothness
            voronoi_texture.inputs[6].default_value = 0.8154506683349609
            #Randomness
            voronoi_texture.inputs[8].default_value = 1.0

            #node Color Ramp
            color_ramp = wood.nodes.new("ShaderNodeValToRGB")
            color_ramp.label = "suky velikost"
            color_ramp.name = "Color Ramp"
            color_ramp.color_ramp.color_mode = 'RGB'
            color_ramp.color_ramp.hue_interpolation = 'NEAR'
            color_ramp.color_ramp.interpolation = 'EASE'

            #initialize color ramp elements
            color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
            color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
            color_ramp_cre_0.position = 0.009523809887468815
            color_ramp_cre_0.alpha = 1.0
            color_ramp_cre_0.color = (1.0, 1.0, 1.0, 1.0)

            color_ramp_cre_1 = color_ramp.color_ramp.elements.new(0.2928570508956909)
            color_ramp_cre_1.alpha = 1.0
            color_ramp_cre_1.color = (0.0, 0.0, 0.0, 1.0)


            #node Mix
            mix = wood.nodes.new("ShaderNodeMix")
            mix.name = "Mix"
            mix.blend_type = 'DIFFERENCE'
            mix.clamp_factor = False
            mix.clamp_result = False
            mix.data_type = 'RGBA'
            mix.factor_mode = 'UNIFORM'
            #Factor_Float
            mix.inputs[0].default_value = 0.5027624368667603

            #node Mapping.001
            mapping_001 = wood.nodes.new("ShaderNodeMapping")
            mapping_001.name = "Mapping.001"
            mapping_001.vector_type = 'POINT'
            #Location
            mapping_001.inputs[1].default_value = (0.0, 0.0, 0.0)
            #Rotation
            mapping_001.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Scale
            mapping_001.inputs[3].default_value = (2.5, 1.0, 1.0)

            #node Noise Texture
            noise_texture = wood.nodes.new("ShaderNodeTexNoise")
            noise_texture.name = "Noise Texture"
            noise_texture.noise_dimensions = '3D'
            noise_texture.noise_type = 'FBM'
            noise_texture.normalize = True
            #Scale
            noise_texture.inputs[2].default_value = 10.0
            #Detail
            noise_texture.inputs[3].default_value = 2.1000003814697266
            #Roughness
            noise_texture.inputs[4].default_value = 0.5027624368667603
            #Lacunarity
            noise_texture.inputs[5].default_value = 0.0
            #Distortion
            noise_texture.inputs[8].default_value = 0.0

            #node Mix.001
            mix_001 = wood.nodes.new("ShaderNodeMix")
            mix_001.name = "Mix.001"
            mix_001.blend_type = 'LINEAR_LIGHT'
            mix_001.clamp_factor = False
            mix_001.clamp_result = False
            mix_001.data_type = 'RGBA'
            mix_001.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_001.inputs[0].default_value = 0.019999999552965164

            #node Color Ramp.001
            color_ramp_001 = wood.nodes.new("ShaderNodeValToRGB")
            color_ramp_001.label = "suky okoli"
            color_ramp_001.name = "Color Ramp.001"
            color_ramp_001.color_ramp.color_mode = 'RGB'
            color_ramp_001.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_001.color_ramp.interpolation = 'B_SPLINE'

            #initialize color ramp elements
            color_ramp_001.color_ramp.elements.remove(color_ramp_001.color_ramp.elements[0])
            color_ramp_001_cre_0 = color_ramp_001.color_ramp.elements[0]
            color_ramp_001_cre_0.position = 0.007177033461630344
            color_ramp_001_cre_0.alpha = 1.0
            color_ramp_001_cre_0.color = (1.0, 1.0, 1.0, 1.0)

            color_ramp_001_cre_1 = color_ramp_001.color_ramp.elements.new(0.35167399048805237)
            color_ramp_001_cre_1.alpha = 1.0
            color_ramp_001_cre_1.color = (0.0, 0.0, 0.0, 1.0)


            #node Mix.002
            mix_002 = wood.nodes.new("ShaderNodeMix")
            mix_002.name = "Mix.002"
            mix_002.blend_type = 'SCREEN'
            mix_002.clamp_factor = False
            mix_002.clamp_result = False
            mix_002.data_type = 'RGBA'
            mix_002.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_002.inputs[0].default_value = 0.5027624368667603

            #node Noise Texture.001
            noise_texture_001 = wood.nodes.new("ShaderNodeTexNoise")
            noise_texture_001.label = "noise grain "
            noise_texture_001.name = "Noise Texture.001"
            noise_texture_001.noise_dimensions = '3D'
            noise_texture_001.noise_type = 'FBM'
            noise_texture_001.normalize = False
            #Scale
            noise_texture_001.inputs[2].default_value = 7.0
            #Detail
            noise_texture_001.inputs[3].default_value = 15.0
            #Roughness
            noise_texture_001.inputs[4].default_value = 1.0
            #Lacunarity
            noise_texture_001.inputs[5].default_value = 2.0
            #Distortion
            noise_texture_001.inputs[8].default_value = 0.0

            #node Mix.003
            mix_003 = wood.nodes.new("ShaderNodeMix")
            mix_003.name = "Mix.003"
            mix_003.blend_type = 'LINEAR_LIGHT'
            mix_003.clamp_factor = False
            mix_003.clamp_result = False
            mix_003.data_type = 'RGBA'
            mix_003.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_003.inputs[0].default_value = 0.19337013363838196

            #node Vector Math
            vector_math = wood.nodes.new("ShaderNodeVectorMath")
            vector_math.name = "Vector Math"
            vector_math.operation = 'SCALE'
            #Scale
            vector_math.inputs[3].default_value = 3.5999999046325684

            #node Color Ramp.002
            color_ramp_002 = wood.nodes.new("ShaderNodeValToRGB")
            color_ramp_002.name = "Color Ramp.002"
            color_ramp_002.color_ramp.color_mode = 'RGB'
            color_ramp_002.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_002.color_ramp.interpolation = 'B_SPLINE'

            #initialize color ramp elements
            color_ramp_002.color_ramp.elements.remove(color_ramp_002.color_ramp.elements[0])
            color_ramp_002_cre_0 = color_ramp_002.color_ramp.elements[0]
            color_ramp_002_cre_0.position = 0.0
            color_ramp_002_cre_0.alpha = 1.0
            color_ramp_002_cre_0.color = (0.06359744817018509, 0.02283223159611225, 0.007914616726338863, 1.0)

            color_ramp_002_cre_1 = color_ramp_002.color_ramp.elements.new(0.04999983310699463)
            color_ramp_002_cre_1.alpha = 1.0
            color_ramp_002_cre_1.color = (0.03516138717532158, 0.013487035408616066, 0.004768589045852423, 1.0)

            color_ramp_002_cre_2 = color_ramp_002.color_ramp.elements.new(0.1332324743270874)
            color_ramp_002_cre_2.alpha = 0.9999999403953552
            color_ramp_002_cre_2.color = (0.03373882174491882, 0.013520472683012486, 0.00593321630731225, 0.9999999403953552)

            color_ramp_002_cre_3 = color_ramp_002.color_ramp.elements.new(0.20438051223754883)
            color_ramp_002_cre_3.alpha = 1.0
            color_ramp_002_cre_3.color = (0.10224024951457977, 0.05448126792907715, 0.036889687180519104, 1.0)

            color_ramp_002_cre_4 = color_ramp_002.color_ramp.elements.new(0.22583067417144775)
            color_ramp_002_cre_4.alpha = 1.0
            color_ramp_002_cre_4.color = (0.16914035379886627, 0.10056924819946289, 0.07382279634475708, 1.0)

            color_ramp_002_cre_5 = color_ramp_002.color_ramp.elements.new(0.251661479473114)
            color_ramp_002_cre_5.alpha = 1.0
            color_ramp_002_cre_5.color = (0.1334930956363678, 0.07270897179841995, 0.050058428198099136, 1.0)

            color_ramp_002_cre_6 = color_ramp_002.color_ramp.elements.new(0.2986403703689575)
            color_ramp_002_cre_6.alpha = 0.9999999403953552
            color_ramp_002_cre_6.color = (0.12198614329099655, 0.06598677486181259, 0.04448072612285614, 0.9999999403953552)

            color_ramp_002_cre_7 = color_ramp_002.color_ramp.elements.new(0.31782472133636475)
            color_ramp_002_cre_7.alpha = 1.0
            color_ramp_002_cre_7.color = (0.1720440685749054, 0.10268684476613998, 0.0755835622549057, 1.0)

            color_ramp_002_cre_8 = color_ramp_002.color_ramp.elements.new(0.3999999165534973)
            color_ramp_002_cre_8.alpha = 0.9999999403953552
            color_ramp_002_cre_8.color = (0.06642726808786392, 0.03243388235569, 0.018180442973971367, 0.9999999403953552)

            color_ramp_002_cre_9 = color_ramp_002.color_ramp.elements.new(0.44999992847442627)
            color_ramp_002_cre_9.alpha = 1.0
            color_ramp_002_cre_9.color = (0.05885970965027809, 0.02757597714662552, 0.014686644077301025, 1.0)

            color_ramp_002_cre_10 = color_ramp_002.color_ramp.elements.new(0.4999999403953552)
            color_ramp_002_cre_10.alpha = 1.0
            color_ramp_002_cre_10.color = (0.08181366324424744, 0.04462255537509918, 0.024806376546621323, 1.0)

            color_ramp_002_cre_11 = color_ramp_002.color_ramp.elements.new(0.5499999523162842)
            color_ramp_002_cre_11.alpha = 1.0
            color_ramp_002_cre_11.color = (0.07234131544828415, 0.03793197497725487, 0.021009618416428566, 1.0)

            color_ramp_002_cre_12 = color_ramp_002.color_ramp.elements.new(0.5939578413963318)
            color_ramp_002_cre_12.alpha = 0.9999999403953552
            color_ramp_002_cre_12.color = (0.05208875983953476, 0.01941620744764805, 0.006534874439239502, 0.9999999403953552)

            color_ramp_002_cre_13 = color_ramp_002.color_ramp.elements.new(0.6651061773300171)
            color_ramp_002_cre_13.alpha = 1.0
            color_ramp_002_cre_13.color = (0.09530539810657501, 0.038204096257686615, 0.01298315729945898, 1.0)

            color_ramp_002_cre_14 = color_ramp_002.color_ramp.elements.new(0.7244716882705688)
            color_ramp_002_cre_14.alpha = 1.0
            color_ramp_002_cre_14.color = (0.2501578629016876, 0.11953994631767273, 0.046664685010910034, 1.0)

            color_ramp_002_cre_15 = color_ramp_002.color_ramp.elements.new(0.7664653062820435)
            color_ramp_002_cre_15.alpha = 1.0
            color_ramp_002_cre_15.color = (0.3049945533275604, 0.17143777012825012, 0.08649884164333344, 1.0)

            color_ramp_002_cre_16 = color_ramp_002.color_ramp.elements.new(0.7741692066192627)
            color_ramp_002_cre_16.alpha = 1.0
            color_ramp_002_cre_16.color = (0.3049945533275604, 0.17143777012825012, 0.08649884164333344, 1.0)

            color_ramp_002_cre_17 = color_ramp_002.color_ramp.elements.new(0.8288523554801941)
            color_ramp_002_cre_17.alpha = 1.0
            color_ramp_002_cre_17.color = (0.2501578629016876, 0.11953994631767273, 0.046664685010910034, 1.0)

            color_ramp_002_cre_18 = color_ramp_002.color_ramp.elements.new(0.8999999761581421)
            color_ramp_002_cre_18.alpha = 1.0
            color_ramp_002_cre_18.color = (0.561125636100769, 0.32072126865386963, 0.16050945222377777, 1.0)

            color_ramp_002_cre_19 = color_ramp_002.color_ramp.elements.new(0.949999988079071)
            color_ramp_002_cre_19.alpha = 1.0
            color_ramp_002_cre_19.color = (0.5562188625335693, 0.3191166818141937, 0.1598706990480423, 1.0)

            color_ramp_002_cre_20 = color_ramp_002.color_ramp.elements.new(1.0)
            color_ramp_002_cre_20.alpha = 1.0
            color_ramp_002_cre_20.color = (0.4160168766975403, 0.21876303851604462, 0.0929582267999649, 1.0)


            #node Noise Texture.002
            noise_texture_002 = wood.nodes.new("ShaderNodeTexNoise")
            noise_texture_002.label = "noise grain 2"
            noise_texture_002.name = "Noise Texture.002"
            noise_texture_002.noise_dimensions = '3D'
            noise_texture_002.noise_type = 'FBM'
            noise_texture_002.normalize = False
            #Scale
            noise_texture_002.inputs[2].default_value = 5.000000476837158
            #Detail
            noise_texture_002.inputs[3].default_value = 15.0
            #Roughness
            noise_texture_002.inputs[4].default_value = 1.0
            #Lacunarity
            noise_texture_002.inputs[5].default_value = 2.0
            #Distortion
            noise_texture_002.inputs[8].default_value = 0.0

            #node Mix.004
            mix_004 = wood.nodes.new("ShaderNodeMix")
            mix_004.name = "Mix.004"
            mix_004.blend_type = 'OVERLAY'
            mix_004.clamp_factor = True
            mix_004.clamp_result = False
            mix_004.data_type = 'RGBA'
            mix_004.factor_mode = 'UNIFORM'
            #B_Color
            mix_004.inputs[7].default_value = (0.058781109750270844, 0.061614274978637695, 0.06346990913152695, 1.0)

            #node Mix.005
            mix_005 = wood.nodes.new("ShaderNodeMix")
            mix_005.name = "Mix.005"
            mix_005.blend_type = 'OVERLAY'
            mix_005.clamp_factor = True
            mix_005.clamp_result = False
            mix_005.data_type = 'RGBA'
            mix_005.factor_mode = 'UNIFORM'
            #B_Color
            mix_005.inputs[7].default_value = (0.0511200949549675, 0.02993899956345558, 0.02620472013950348, 1.0)

            #node Math
            math = wood.nodes.new("ShaderNodeMath")
            math.name = "Math"
            math.operation = 'MULTIPLY'
            math.use_clamp = False
            #Value_001
            math.inputs[1].default_value = 3.0

            #node Color Ramp.003
            color_ramp_003 = wood.nodes.new("ShaderNodeValToRGB")
            color_ramp_003.label = "Kraje suku"
            color_ramp_003.name = "Color Ramp.003"
            color_ramp_003.color_ramp.color_mode = 'RGB'
            color_ramp_003.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_003.color_ramp.interpolation = 'LINEAR'

            #initialize color ramp elements
            color_ramp_003.color_ramp.elements.remove(color_ramp_003.color_ramp.elements[0])
            color_ramp_003_cre_0 = color_ramp_003.color_ramp.elements[0]
            color_ramp_003_cre_0.position = 0.18457941710948944
            color_ramp_003_cre_0.alpha = 1.0
            color_ramp_003_cre_0.color = (1.0, 1.0, 1.0, 1.0)

            color_ramp_003_cre_1 = color_ramp_003.color_ramp.elements.new(0.22175072133541107)
            color_ramp_003_cre_1.alpha = 1.0
            color_ramp_003_cre_1.color = (0.08297871053218842, 0.08297871053218842, 0.08297871053218842, 1.0)

            color_ramp_003_cre_2 = color_ramp_003.color_ramp.elements.new(0.26635581254959106)
            color_ramp_003_cre_2.alpha = 1.0
            color_ramp_003_cre_2.color = (0.5, 0.5, 0.5, 1.0)


            #node Mix.006
            mix_006 = wood.nodes.new("ShaderNodeMix")
            mix_006.name = "Mix.006"
            mix_006.blend_type = 'MULTIPLY'
            mix_006.clamp_factor = False
            mix_006.clamp_result = False
            mix_006.data_type = 'RGBA'
            mix_006.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_006.inputs[0].default_value = 0.699999988079071

            #node Voronoi Texture.001
            voronoi_texture_001 = wood.nodes.new("ShaderNodeTexVoronoi")
            voronoi_texture_001.label = "Voronoi Sukove hvezdy"
            voronoi_texture_001.name = "Voronoi Texture.001"
            voronoi_texture_001.distance = 'MINKOWSKI'
            voronoi_texture_001.feature = 'SMOOTH_F1'
            voronoi_texture_001.normalize = False
            voronoi_texture_001.voronoi_dimensions = '3D'
            #Scale
            voronoi_texture_001.inputs[2].default_value = 5.0
            #Detail
            voronoi_texture_001.inputs[3].default_value = 0.0
            #Roughness
            voronoi_texture_001.inputs[4].default_value = 1.0
            #Lacunarity
            voronoi_texture_001.inputs[5].default_value = 0.0
            #Smoothness
            voronoi_texture_001.inputs[6].default_value = 1.0
            #Exponent
            voronoi_texture_001.inputs[7].default_value = 0.5
            #Randomness
            voronoi_texture_001.inputs[8].default_value = 1.0

            #node Color Ramp.004
            color_ramp_004 = wood.nodes.new("ShaderNodeValToRGB")
            color_ramp_004.label = "sukove hvezdy"
            color_ramp_004.name = "Color Ramp.004"
            color_ramp_004.color_ramp.color_mode = 'RGB'
            color_ramp_004.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_004.color_ramp.interpolation = 'LINEAR'

            #initialize color ramp elements
            color_ramp_004.color_ramp.elements.remove(color_ramp_004.color_ramp.elements[0])
            color_ramp_004_cre_0 = color_ramp_004.color_ramp.elements[0]
            color_ramp_004_cre_0.position = 0.18266980350017548
            color_ramp_004_cre_0.alpha = 1.0
            color_ramp_004_cre_0.color = (0.0, 0.0, 0.0, 1.0)

            color_ramp_004_cre_1 = color_ramp_004.color_ramp.elements.new(0.4613582193851471)
            color_ramp_004_cre_1.alpha = 1.0
            color_ramp_004_cre_1.color = (0.5, 0.5, 0.5, 1.0)


            #node Noise Texture.003
            noise_texture_003 = wood.nodes.new("ShaderNodeTexNoise")
            noise_texture_003.name = "Noise Texture.003"
            noise_texture_003.noise_dimensions = '3D'
            noise_texture_003.noise_type = 'FBM'
            noise_texture_003.normalize = True
            #Scale
            noise_texture_003.inputs[2].default_value = 26.299999237060547
            #Detail
            noise_texture_003.inputs[3].default_value = 0.6999999284744263
            #Roughness
            noise_texture_003.inputs[4].default_value = 1.0
            #Lacunarity
            noise_texture_003.inputs[5].default_value = 0.0
            #Distortion
            noise_texture_003.inputs[8].default_value = 0.0

            #node Mix.007
            mix_007 = wood.nodes.new("ShaderNodeMix")
            mix_007.name = "Mix.007"
            mix_007.blend_type = 'LINEAR_LIGHT'
            mix_007.clamp_factor = False
            mix_007.clamp_result = False
            mix_007.data_type = 'RGBA'
            mix_007.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_007.inputs[0].default_value = 0.019999999552965164

            #node Mix.008
            mix_008 = wood.nodes.new("ShaderNodeMix")
            mix_008.label = "multiply - okraje+hvezdy"
            mix_008.name = "Mix.008"
            mix_008.blend_type = 'MULTIPLY'
            mix_008.clamp_factor = False
            mix_008.clamp_result = False
            mix_008.data_type = 'RGBA'
            mix_008.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_008.inputs[0].default_value = 1.0

            #node Voronoi Texture.002
            voronoi_texture_002 = wood.nodes.new("ShaderNodeTexVoronoi")
            voronoi_texture_002.name = "Voronoi Texture.002"
            voronoi_texture_002.distance = 'MINKOWSKI'
            voronoi_texture_002.feature = 'SMOOTH_F1'
            voronoi_texture_002.normalize = False
            voronoi_texture_002.voronoi_dimensions = '3D'
            #Scale
            voronoi_texture_002.inputs[2].default_value = 15.0
            #Detail
            voronoi_texture_002.inputs[3].default_value = 0.0
            #Roughness
            voronoi_texture_002.inputs[4].default_value = 1.0
            #Lacunarity
            voronoi_texture_002.inputs[5].default_value = 0.0
            #Smoothness
            voronoi_texture_002.inputs[6].default_value = 1.0
            #Exponent
            voronoi_texture_002.inputs[7].default_value = 0.5
            #Randomness
            voronoi_texture_002.inputs[8].default_value = 1.0

            #node Color Ramp.005
            color_ramp_005 = wood.nodes.new("ShaderNodeValToRGB")
            color_ramp_005.label = "wood cracks"
            color_ramp_005.name = "Color Ramp.005"
            color_ramp_005.color_ramp.color_mode = 'RGB'
            color_ramp_005.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_005.color_ramp.interpolation = 'LINEAR'

            #initialize color ramp elements
            color_ramp_005.color_ramp.elements.remove(color_ramp_005.color_ramp.elements[0])
            color_ramp_005_cre_0 = color_ramp_005.color_ramp.elements[0]
            color_ramp_005_cre_0.position = 0.7489808201789856
            color_ramp_005_cre_0.alpha = 1.0
            color_ramp_005_cre_0.color = (0.0, 0.0, 0.0, 1.0)

            color_ramp_005_cre_1 = color_ramp_005.color_ramp.elements.new(1.0)
            color_ramp_005_cre_1.alpha = 1.0
            color_ramp_005_cre_1.color = (0.5, 0.5, 0.5, 1.0)


            #node Mapping.002
            mapping_002 = wood.nodes.new("ShaderNodeMapping")
            mapping_002.name = "Mapping.002"
            mapping_002.vector_type = 'POINT'
            #Location
            mapping_002.inputs[1].default_value = (0.0, 0.0, 0.0)
            #Rotation
            mapping_002.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Scale
            mapping_002.inputs[3].default_value = (5.0, 0.20000000298023224, 1.0)

            #node Mix.009
            mix_009 = wood.nodes.new("ShaderNodeMix")
            mix_009.name = "Mix.009"
            mix_009.blend_type = 'MULTIPLY'
            mix_009.clamp_factor = False
            mix_009.clamp_result = False
            mix_009.data_type = 'RGBA'
            mix_009.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_009.inputs[0].default_value = 1.0

            #node Gamma
            gamma = wood.nodes.new("ShaderNodeGamma")
            gamma.name = "Gamma"
            #Gamma
            gamma.inputs[1].default_value = 0.9009999632835388

            #node Bump
            bump = wood.nodes.new("ShaderNodeBump")
            bump.name = "Bump"
            bump.invert = False
            #Strength
            bump.inputs[0].default_value = 1.0
            #Distance
            bump.inputs[1].default_value = 1.0
            #Normal
            bump.inputs[3].default_value = (0.0, 0.0, 0.0)

            #node Math.001
            math_001 = wood.nodes.new("ShaderNodeMath")
            math_001.name = "Math.001"
            math_001.operation = 'DIVIDE'
            math_001.use_clamp = False
            #Value_001
            math_001.inputs[1].default_value = 600.0

            #node Mix.010
            mix_010 = wood.nodes.new("ShaderNodeMix")
            mix_010.name = "Mix.010"
            mix_010.blend_type = 'ADD'
            mix_010.clamp_factor = False
            mix_010.clamp_result = False
            mix_010.data_type = 'RGBA'
            mix_010.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_010.inputs[0].default_value = 1.0
            #B_Color
            mix_010.inputs[7].default_value = (0.019933436065912247, 0.018479496240615845, 0.019796274602413177, 1.0)

            #node Mix.011
            mix_011 = wood.nodes.new("ShaderNodeMix")
            mix_011.name = "Mix.011"
            mix_011.blend_type = 'MULTIPLY'
            mix_011.clamp_factor = False
            mix_011.clamp_result = False
            mix_011.data_type = 'RGBA'
            mix_011.factor_mode = 'UNIFORM'
            #B_Color
            mix_011.inputs[7].default_value = (0.6099916696548462, 0.6099916696548462, 0.6099916696548462, 1.0)

            #node Mix.012
            mix_012 = wood.nodes.new("ShaderNodeMix")
            mix_012.name = "Mix.012"
            mix_012.blend_type = 'MULTIPLY'
            mix_012.clamp_factor = False
            mix_012.clamp_result = False
            mix_012.data_type = 'RGBA'
            mix_012.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_012.inputs[0].default_value = 0.7734806537628174

            #node Mix.013
            mix_013 = wood.nodes.new("ShaderNodeMix")
            mix_013.name = "Mix.013"
            mix_013.blend_type = 'MULTIPLY'
            mix_013.clamp_factor = False
            mix_013.clamp_result = False
            mix_013.data_type = 'RGBA'
            mix_013.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_013.inputs[0].default_value = 1.0

            #node Noise Texture.004
            noise_texture_004 = wood.nodes.new("ShaderNodeTexNoise")
            noise_texture_004.name = "Noise Texture.004"
            noise_texture_004.noise_dimensions = '3D'
            noise_texture_004.noise_type = 'MULTIFRACTAL'
            noise_texture_004.normalize = False
            #Scale
            noise_texture_004.inputs[2].default_value = 5.0
            #Detail
            noise_texture_004.inputs[3].default_value = 15.0
            #Roughness
            noise_texture_004.inputs[4].default_value = 1.0
            #Lacunarity
            noise_texture_004.inputs[5].default_value = 2.0
            #Distortion
            noise_texture_004.inputs[8].default_value = 0.0

            #node Brightness/Contrast
            brightness_contrast = wood.nodes.new("ShaderNodeBrightContrast")
            brightness_contrast.name = "Brightness/Contrast"
            #Bright
            brightness_contrast.inputs[1].default_value = 0.4000000059604645
            #Contrast
            brightness_contrast.inputs[2].default_value = -0.7999999523162842

            #node Mix.014
            mix_014 = wood.nodes.new("ShaderNodeMix")
            mix_014.name = "Mix.014"
            mix_014.blend_type = 'DIFFERENCE'
            mix_014.clamp_factor = False
            mix_014.clamp_result = False
            mix_014.data_type = 'RGBA'
            mix_014.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_014.inputs[0].default_value = 1.0

            #node Mix.015
            mix_015 = wood.nodes.new("ShaderNodeMix")
            mix_015.name = "Mix.015"
            mix_015.blend_type = 'ADD'
            mix_015.clamp_factor = False
            mix_015.clamp_result = False
            mix_015.data_type = 'RGBA'
            mix_015.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_015.inputs[0].default_value = 1.0

            #node Invert Color
            invert_color = wood.nodes.new("ShaderNodeInvert")
            invert_color.name = "Invert Color"
            #Fac
            invert_color.inputs[0].default_value = 0.6399999856948853

            #node Invert Color.001
            invert_color_001 = wood.nodes.new("ShaderNodeInvert")
            invert_color_001.name = "Invert Color.001"
            #Fac
            invert_color_001.inputs[0].default_value = 0.7866666316986084

            #node Mix.016
            mix_016 = wood.nodes.new("ShaderNodeMix")
            mix_016.name = "Mix.016"
            mix_016.blend_type = 'ADD'
            mix_016.clamp_factor = False
            mix_016.clamp_result = False
            mix_016.data_type = 'RGBA'
            mix_016.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_016.inputs[0].default_value = 1.0

            #node Color Ramp.006
            color_ramp_006 = wood.nodes.new("ShaderNodeValToRGB")
            color_ramp_006.name = "Color Ramp.006"
            color_ramp_006.color_ramp.color_mode = 'RGB'
            color_ramp_006.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_006.color_ramp.interpolation = 'LINEAR'

            #initialize color ramp elements
            color_ramp_006.color_ramp.elements.remove(color_ramp_006.color_ramp.elements[0])
            color_ramp_006_cre_0 = color_ramp_006.color_ramp.elements[0]
            color_ramp_006_cre_0.position = 0.0
            color_ramp_006_cre_0.alpha = 1.0
            color_ramp_006_cre_0.color = (0.5000001192092896, 0.5000001192092896, 0.5000001192092896, 1.0)

            color_ramp_006_cre_1 = color_ramp_006.color_ramp.elements.new(0.5454539060592651)
            color_ramp_006_cre_1.alpha = 1.0
            color_ramp_006_cre_1.color = (0.0, 0.0, 0.0, 1.0)

            color_ramp_006_cre_2 = color_ramp_006.color_ramp.elements.new(1.0)
            color_ramp_006_cre_2.alpha = 1.0
            color_ramp_006_cre_2.color = (1.0, 1.0, 1.0, 1.0)


            #node Color Ramp.007
            color_ramp_007 = wood.nodes.new("ShaderNodeValToRGB")
            color_ramp_007.name = "Color Ramp.007"
            color_ramp_007.color_ramp.color_mode = 'RGB'
            color_ramp_007.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_007.color_ramp.interpolation = 'LINEAR'

            #initialize color ramp elements
            color_ramp_007.color_ramp.elements.remove(color_ramp_007.color_ramp.elements[0])
            color_ramp_007_cre_0 = color_ramp_007.color_ramp.elements[0]
            color_ramp_007_cre_0.position = 0.0
            color_ramp_007_cre_0.alpha = 1.0
            color_ramp_007_cre_0.color = (0.5000001192092896, 0.5000001192092896, 0.5000001192092896, 1.0)

            color_ramp_007_cre_1 = color_ramp_007.color_ramp.elements.new(0.5018177032470703)
            color_ramp_007_cre_1.alpha = 1.0
            color_ramp_007_cre_1.color = (0.0, 0.0, 0.0, 1.0)

            color_ramp_007_cre_2 = color_ramp_007.color_ramp.elements.new(0.9818180799484253)
            color_ramp_007_cre_2.alpha = 1.0
            color_ramp_007_cre_2.color = (1.0, 1.0, 1.0, 1.0)



            #Set locations
            material_output.location = (2456.336669921875, -550.7155151367188)
            principled_bsdf.location = (2051.70654296875, -643.2135009765625)
            texture_coordinate.location = (-3234.3359375, -345.439453125)
            mapping.location = (-1444.2926025390625, 260.2301940917969)
            wave_texture.location = (-741.9728393554688, 622.425537109375)
            voronoi_texture.location = (-1783.5367431640625, -249.1887664794922)
            color_ramp.location = (-1489.83984375, -156.14317321777344)
            mix.location = (-919.63525390625, 293.97235107421875)
            mapping_001.location = (-2241.975830078125, -330.02398681640625)
            noise_texture.location = (-2248.154541015625, -684.8854370117188)
            mix_001.location = (-1956.1177978515625, -413.551513671875)
            color_ramp_001.location = (-1484.8590087890625, -373.571533203125)
            mix_002.location = (-1120.6488037109375, 57.182373046875)
            noise_texture_001.location = (-588.4653930664062, 418.638427734375)
            mix_003.location = (-246.73069763183594, 595.43603515625)
            vector_math.location = (-2793.447998046875, -349.2250671386719)
            color_ramp_002.location = (-56.7828369140625, 614.4411010742188)
            noise_texture_002.location = (-416.5155944824219, 316.6727600097656)
            mix_004.location = (262.2077331542969, 558.3805541992188)
            mix_005.location = (577.8464965820312, 418.7426452636719)
            math.location = (299.6708068847656, 194.6556854248047)
            color_ramp_003.location = (-1473.43603515625, -595.0355834960938)
            mix_006.location = (781.7316284179688, 323.9478454589844)
            voronoi_texture_001.location = (-1762.0748291015625, -823.5791625976562)
            color_ramp_004.location = (-1472.6278076171875, -851.7120971679688)
            noise_texture_003.location = (-2229.92041015625, -977.623779296875)
            mix_007.location = (-1978.7904052734375, -962.27294921875)
            mix_008.location = (-1047.357177734375, -590.3084106445312)
            voronoi_texture_002.location = (-482.9537658691406, -957.099609375)
            color_ramp_005.location = (-258.83758544921875, -1025.315673828125)
            mapping_002.location = (-676.5466918945312, -932.6240234375)
            mix_009.location = (967.0702514648438, 250.3735809326172)
            gamma.location = (1168.5523681640625, 96.78485870361328)
            bump.location = (1378.600830078125, -1412.9813232421875)
            math_001.location = (523.3140258789062, -1407.2628173828125)
            mix_010.location = (697.5431518554688, -1440.12548828125)
            mix_011.location = (870.8359375, -1241.6561279296875)
            mix_012.location = (539.7094116210938, -1660.913818359375)
            mix_013.location = (1182.9586181640625, -1424.6776123046875)
            noise_texture_004.location = (824.2804565429688, -268.1585388183594)
            brightness_contrast.location = (1047.637939453125, -259.95819091796875)
            mix_014.location = (1269.6572265625, -327.18524169921875)
            mix_015.location = (1327.435791015625, -583.0286254882812)
            invert_color.location = (612.8121337890625, -607.8773193359375)
            invert_color_001.location = (605.5543823242188, -722.9135131835938)
            mix_016.location = (1496.8240966796875, -373.812744140625)
            color_ramp_006.location = (831.4382934570312, -524.4039306640625)
            color_ramp_007.location = (823.2218017578125, -734.976806640625)

            #Set dimensions
            material_output.width, material_output.height = 140.0, 100.0
            principled_bsdf.width, principled_bsdf.height = 148.72543334960938, 100.0
            texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
            mapping.width, mapping.height = 140.0, 100.0
            wave_texture.width, wave_texture.height = 150.0, 100.0
            voronoi_texture.width, voronoi_texture.height = 175.0479278564453, 100.0
            color_ramp.width, color_ramp.height = 299.446044921875, 100.0
            mix.width, mix.height = 140.0, 100.0
            mapping_001.width, mapping_001.height = 140.0, 100.0
            noise_texture.width, noise_texture.height = 140.0, 100.0
            mix_001.width, mix_001.height = 140.0, 100.0
            color_ramp_001.width, color_ramp_001.height = 298.2803649902344, 100.0
            mix_002.width, mix_002.height = 140.0, 100.0
            noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
            mix_003.width, mix_003.height = 140.0, 100.0
            vector_math.width, vector_math.height = 140.0, 100.0
            color_ramp_002.width, color_ramp_002.height = 240.0, 100.0
            noise_texture_002.width, noise_texture_002.height = 140.0, 100.0
            mix_004.width, mix_004.height = 140.0, 100.0
            mix_005.width, mix_005.height = 140.0, 100.0
            math.width, math.height = 140.0, 100.0
            color_ramp_003.width, color_ramp_003.height = 305.2740783691406, 100.0
            mix_006.width, mix_006.height = 140.0, 100.0
            voronoi_texture_001.width, voronoi_texture_001.height = 175.0479278564453, 100.0
            color_ramp_004.width, color_ramp_004.height = 304.1102600097656, 100.0
            noise_texture_003.width, noise_texture_003.height = 140.0, 100.0
            mix_007.width, mix_007.height = 140.0, 100.0
            mix_008.width, mix_008.height = 184.71189880371094, 100.0
            voronoi_texture_002.width, voronoi_texture_002.height = 175.0479278564453, 100.0
            color_ramp_005.width, color_ramp_005.height = 240.0, 100.0
            mapping_002.width, mapping_002.height = 140.0, 100.0
            mix_009.width, mix_009.height = 140.0, 100.0
            gamma.width, gamma.height = 140.0, 100.0
            bump.width, bump.height = 140.0, 100.0
            math_001.width, math_001.height = 140.0, 100.0
            mix_010.width, mix_010.height = 140.0, 100.0
            mix_011.width, mix_011.height = 140.0, 100.0
            mix_012.width, mix_012.height = 140.0, 100.0
            mix_013.width, mix_013.height = 140.0, 100.0
            noise_texture_004.width, noise_texture_004.height = 140.0, 100.0
            brightness_contrast.width, brightness_contrast.height = 140.0, 100.0
            mix_014.width, mix_014.height = 140.0, 100.0
            mix_015.width, mix_015.height = 140.0, 100.0
            invert_color.width, invert_color.height = 140.0, 100.0
            invert_color_001.width, invert_color_001.height = 140.0, 100.0
            mix_016.width, mix_016.height = 140.0, 100.0
            color_ramp_006.width, color_ramp_006.height = 240.0, 100.0
            color_ramp_007.width, color_ramp_007.height = 240.0, 100.0

            #initialize wood links
            #vector_math.Vector -> mapping.Vector
            wood.links.new(vector_math.outputs[0], mapping.inputs[0])
            #voronoi_texture.Distance -> color_ramp.Fac
            wood.links.new(voronoi_texture.outputs[0], color_ramp.inputs[0])
            #mapping_001.Vector -> mix_001.A
            wood.links.new(mapping_001.outputs[0], mix_001.inputs[6])
            #noise_texture.Color -> mix_001.B
            wood.links.new(noise_texture.outputs[1], mix_001.inputs[7])
            #voronoi_texture.Distance -> color_ramp_001.Fac
            wood.links.new(voronoi_texture.outputs[0], color_ramp_001.inputs[0])
            #mix_002.Result -> mix.B
            wood.links.new(mix_002.outputs[2], mix.inputs[7])
            #mapping.Vector -> mix.A
            wood.links.new(mapping.outputs[0], mix.inputs[6])
            #mix.Result -> wave_texture.Vector
            wood.links.new(mix.outputs[2], wave_texture.inputs[0])
            #mix.Result -> noise_texture_001.Vector
            wood.links.new(mix.outputs[2], noise_texture_001.inputs[0])
            #wave_texture.Color -> mix_003.A
            wood.links.new(wave_texture.outputs[0], mix_003.inputs[6])
            #vector_math.Vector -> mapping_001.Vector
            wood.links.new(vector_math.outputs[0], mapping_001.inputs[0])
            #vector_math.Vector -> noise_texture.Vector
            wood.links.new(vector_math.outputs[0], noise_texture.inputs[0])
            #mix_003.Result -> color_ramp_002.Fac
            wood.links.new(mix_003.outputs[2], color_ramp_002.inputs[0])
            #mix.Result -> noise_texture_002.Vector
            wood.links.new(mix.outputs[2], noise_texture_002.inputs[0])
            #color_ramp_002.Color -> mix_004.A
            wood.links.new(color_ramp_002.outputs[0], mix_004.inputs[6])
            #gamma.Color -> principled_bsdf.Base Color
            wood.links.new(gamma.outputs[0], principled_bsdf.inputs[0])
            #noise_texture_002.Fac -> mix_004.Factor
            wood.links.new(noise_texture_002.outputs[0], mix_004.inputs[0])
            #mix_004.Result -> mix_005.A
            wood.links.new(mix_004.outputs[2], mix_005.inputs[6])
            #math.Value -> mix_005.Factor
            wood.links.new(math.outputs[0], mix_005.inputs[0])
            #color_ramp.Color -> math.Value
            wood.links.new(color_ramp.outputs[0], math.inputs[0])
            #voronoi_texture.Distance -> color_ramp_003.Fac
            wood.links.new(voronoi_texture.outputs[0], color_ramp_003.inputs[0])
            #mix_005.Result -> mix_006.A
            wood.links.new(mix_005.outputs[2], mix_006.inputs[6])
            #voronoi_texture_001.Distance -> color_ramp_004.Fac
            wood.links.new(voronoi_texture_001.outputs[0], color_ramp_004.inputs[0])
            #noise_texture_003.Color -> mix_007.B
            wood.links.new(noise_texture_003.outputs[1], mix_007.inputs[7])
            #mapping_001.Vector -> mix_007.A
            wood.links.new(mapping_001.outputs[0], mix_007.inputs[6])
            #vector_math.Vector -> noise_texture_003.Vector
            wood.links.new(vector_math.outputs[0], noise_texture_003.inputs[0])
            #mix_007.Result -> voronoi_texture_001.Vector
            wood.links.new(mix_007.outputs[2], voronoi_texture_001.inputs[0])
            #mix_008.Result -> mix_006.B
            wood.links.new(mix_008.outputs[2], mix_006.inputs[7])
            #voronoi_texture_002.Distance -> color_ramp_005.Fac
            wood.links.new(voronoi_texture_002.outputs[0], color_ramp_005.inputs[0])
            #mapping_002.Vector -> voronoi_texture_002.Vector
            wood.links.new(mapping_002.outputs[0], voronoi_texture_002.inputs[0])
            #mix.Result -> mapping_002.Vector
            wood.links.new(mix.outputs[2], mapping_002.inputs[0])
            #mix_006.Result -> mix_009.A
            wood.links.new(mix_006.outputs[2], mix_009.inputs[6])
            #color_ramp_005.Color -> mix_009.B
            wood.links.new(color_ramp_005.outputs[0], mix_009.inputs[7])
            #mix_009.Result -> gamma.Color
            wood.links.new(mix_009.outputs[2], gamma.inputs[0])
            #mix_013.Result -> bump.Height
            wood.links.new(mix_013.outputs[2], bump.inputs[2])
            #wave_texture.Color -> math_001.Value
            wood.links.new(wave_texture.outputs[0], math_001.inputs[0])
            #math_001.Value -> mix_010.A
            wood.links.new(math_001.outputs[0], mix_010.inputs[6])
            #mix_010.Result -> mix_011.A
            wood.links.new(mix_010.outputs[2], mix_011.inputs[6])
            #math.Value -> mix_011.Factor
            wood.links.new(math.outputs[0], mix_011.inputs[0])
            #color_ramp_005.Color -> mix_012.A
            wood.links.new(color_ramp_005.outputs[0], mix_012.inputs[6])
            #color_ramp_004.Color -> mix_012.B
            wood.links.new(color_ramp_004.outputs[0], mix_012.inputs[7])
            #mix_011.Result -> mix_013.A
            wood.links.new(mix_011.outputs[2], mix_013.inputs[6])
            #mix_012.Result -> mix_013.B
            wood.links.new(mix_012.outputs[2], mix_013.inputs[7])
            #mix.Result -> noise_texture_004.Vector
            wood.links.new(mix.outputs[2], noise_texture_004.inputs[0])
            #noise_texture_004.Fac -> brightness_contrast.Color
            wood.links.new(noise_texture_004.outputs[0], brightness_contrast.inputs[0])
            #brightness_contrast.Color -> mix_014.A
            wood.links.new(brightness_contrast.outputs[0], mix_014.inputs[6])
            #color_ramp_005.Color -> invert_color.Color
            wood.links.new(color_ramp_005.outputs[0], invert_color.inputs[1])
            #color_ramp_004.Color -> invert_color_001.Color
            wood.links.new(color_ramp_004.outputs[0], invert_color_001.inputs[1])
            #mix_001.Result -> voronoi_texture.Vector
            wood.links.new(mix_001.outputs[2], voronoi_texture.inputs[0])
            #color_ramp.Color -> mix_002.A
            wood.links.new(color_ramp.outputs[0], mix_002.inputs[6])
            #color_ramp_001.Color -> mix_002.B
            wood.links.new(color_ramp_001.outputs[0], mix_002.inputs[7])
            #noise_texture_001.Fac -> mix_003.B
            wood.links.new(noise_texture_001.outputs[0], mix_003.inputs[7])
            #color_ramp_003.Color -> mix_008.A
            wood.links.new(color_ramp_003.outputs[0], mix_008.inputs[6])
            #color_ramp_004.Color -> mix_008.B
            wood.links.new(color_ramp_004.outputs[0], mix_008.inputs[7])
            #mix_015.Result -> mix_016.B
            wood.links.new(mix_015.outputs[2], mix_016.inputs[7])
            #mix_014.Result -> mix_016.A
            wood.links.new(mix_014.outputs[2], mix_016.inputs[6])
            #bump.Normal -> principled_bsdf.Normal
            wood.links.new(bump.outputs[0], principled_bsdf.inputs[5])
            #texture_coordinate.UV -> vector_math.Vector
            wood.links.new(texture_coordinate.outputs[2], vector_math.inputs[0])
            #mix_016.Result -> principled_bsdf.Roughness
            wood.links.new(mix_016.outputs[2], principled_bsdf.inputs[2])
            #noise_texture.Fac -> mix_014.B
            wood.links.new(noise_texture.outputs[0], mix_014.inputs[7])
            #color_ramp_007.Color -> mix_015.B
            wood.links.new(color_ramp_007.outputs[0], mix_015.inputs[7])
            #invert_color.Color -> color_ramp_006.Fac
            wood.links.new(invert_color.outputs[0], color_ramp_006.inputs[0])
            #color_ramp_006.Color -> mix_015.A
            wood.links.new(color_ramp_006.outputs[0], mix_015.inputs[6])
            #invert_color_001.Color -> color_ramp_007.Fac
            wood.links.new(invert_color_001.outputs[0], color_ramp_007.inputs[0])
            #principled_bsdf.BSDF -> material_output.Surface
            wood.links.new(principled_bsdf.outputs[0], material_output.inputs[0])
            return wood

        set_render_engine()
        wood = wood_node_group()

        return {'FINISHED'}
def menu_func(self, context):
    self.layout.operator(Wood.bl_idname)

def register():
    bpy.utils.register_class(Wood)
    bpy.types.NODE_MT_add.append(menu_func)

def unregister():
    bpy.utils.unregister_class(Wood)
    bpy.types.NODE_MT_add.remove(menu_func)

if __name__ == "__main__":
    register()
