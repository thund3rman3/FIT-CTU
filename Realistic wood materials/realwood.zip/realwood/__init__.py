bl_info = {
    "name" : "RealWoodGenerator",
    "description" : "Addon for procedural realistic wood materials. Made for bachelor's thesis on FIT CTU Prague 2025.",
    "author" : "Josef Jech with help of Node To Python",
    "version" : (1, 0, 0),
    "blender" : (4, 3, 2),
    "location" : "Node",
    "category" : "Node",
}

import bpy
import mathutils
import os

class RealWood(bpy.types.Operator):
    bl_idname = "node.realwood"
    bl_label = "RealWood"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        mat = bpy.data.materials.new(name = "RealWood")
        mat.use_nodes = True
        #initialize RealWood node group
        def realwood_node_group():

            realwood = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "RealWood")

            realwood.color_tag = 'NONE'
            realwood.description = ""
            realwood.default_group_node_width = 141
            

            #realwood interface
            #Socket Color
            color_socket = realwood.interface.new_socket(name = "Color", in_out='OUTPUT', socket_type = 'NodeSocketColor')
            color_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
            color_socket.attribute_domain = 'POINT'

            #Socket Roughness
            roughness_socket = realwood.interface.new_socket(name = "Roughness", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
            roughness_socket.default_value = 0.0
            roughness_socket.min_value = -3.4028234663852886e+38
            roughness_socket.max_value = 3.4028234663852886e+38
            roughness_socket.subtype = 'NONE'
            roughness_socket.attribute_domain = 'POINT'

            #Socket Normal
            normal_socket = realwood.interface.new_socket(name = "Normal", in_out='OUTPUT', socket_type = 'NodeSocketVector')
            normal_socket.default_value = (0.0, 0.0, 0.0)
            normal_socket.min_value = -3.4028234663852886e+38
            normal_socket.max_value = 3.4028234663852886e+38
            normal_socket.subtype = 'NONE'
            normal_socket.attribute_domain = 'POINT'

            #Socket Specularity
            specularity_socket = realwood.interface.new_socket(name = "Specularity", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
            specularity_socket.default_value = 0.0
            specularity_socket.min_value = -3.4028234663852886e+38
            specularity_socket.max_value = 3.4028234663852886e+38
            specularity_socket.subtype = 'NONE'
            specularity_socket.attribute_domain = 'POINT'

            #Socket Knots Mask
            knots_mask_socket = realwood.interface.new_socket(name = "Knots Mask", in_out='OUTPUT', socket_type = 'NodeSocketColor')
            knots_mask_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
            knots_mask_socket.attribute_domain = 'POINT'

            #Socket Coordinates
            coordinates_socket = realwood.interface.new_socket(name = "Coordinates", in_out='INPUT', socket_type = 'NodeSocketVector')
            coordinates_socket.default_value = (0.0, 0.0, 0.0)
            coordinates_socket.min_value = -10000.0
            coordinates_socket.max_value = 10000.0
            coordinates_socket.subtype = 'NONE'
            coordinates_socket.attribute_domain = 'POINT'

            #Socket Center Location
            center_location_socket = realwood.interface.new_socket(name = "Center Location", in_out='INPUT', socket_type = 'NodeSocketVector')
            center_location_socket.default_value = (0.0, 0.0, 0.0)
            center_location_socket.min_value = -3.4028234663852886e+38
            center_location_socket.max_value = 3.4028234663852886e+38
            center_location_socket.subtype = 'NONE'
            center_location_socket.attribute_domain = 'POINT'

            #Socket Rotation
            rotation_socket = realwood.interface.new_socket(name = "Rotation", in_out='INPUT', socket_type = 'NodeSocketVector')
            rotation_socket.default_value = (0.0, 0.0, 0.0)
            rotation_socket.min_value = -3.4028234663852886e+38
            rotation_socket.max_value = 3.4028234663852886e+38
            rotation_socket.subtype = 'NONE'
            rotation_socket.attribute_domain = 'POINT'

            #Socket Scale
            scale_socket = realwood.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
            scale_socket.default_value = (0.10000000149011612, 0.10000000149011612, 0.10000000149011612)
            scale_socket.min_value = -3.4028234663852886e+38
            scale_socket.max_value = 3.4028234663852886e+38
            scale_socket.subtype = 'NONE'
            scale_socket.attribute_domain = 'POINT'

            #Socket Noise Scale
            noise_scale_socket = realwood.interface.new_socket(name = "Noise Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
            noise_scale_socket.default_value = 1.5
            noise_scale_socket.min_value = 0.0
            noise_scale_socket.max_value = 1000.0
            noise_scale_socket.subtype = 'NONE'
            noise_scale_socket.attribute_domain = 'POINT'

            #Socket Noise Variation
            noise_variation_socket = realwood.interface.new_socket(name = "Noise Variation", in_out='INPUT', socket_type = 'NodeSocketFloat')
            noise_variation_socket.default_value = 1.7000000476837158
            noise_variation_socket.min_value = 0.0
            noise_variation_socket.max_value = 1000.0
            noise_variation_socket.subtype = 'NONE'
            noise_variation_socket.attribute_domain = 'POINT'

            #Socket Rings Scale
            rings_scale_socket = realwood.interface.new_socket(name = "Rings Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
            rings_scale_socket.default_value = 3.4000000953674316
            rings_scale_socket.min_value = 0.0
            rings_scale_socket.max_value = 1000.0
            rings_scale_socket.subtype = 'NONE'
            rings_scale_socket.attribute_domain = 'POINT'

            #Socket Latewood Width
            latewood_width_socket = realwood.interface.new_socket(name = "Latewood Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
            latewood_width_socket.default_value = 0.10000000149011612
            latewood_width_socket.min_value = 0.0
            latewood_width_socket.max_value = 1.0
            latewood_width_socket.subtype = 'NONE'
            latewood_width_socket.attribute_domain = 'POINT'

            #Socket Rings Offset
            rings_offset_socket = realwood.interface.new_socket(name = "Rings Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
            rings_offset_socket.default_value = 48.79999923706055
            rings_offset_socket.min_value = 0.0
            rings_offset_socket.max_value = 100.0
            rings_offset_socket.subtype = 'NONE'
            rings_offset_socket.attribute_domain = 'POINT'

            #Socket Rings Distortion
            rings_distortion_socket = realwood.interface.new_socket(name = "Rings Distortion", in_out='INPUT', socket_type = 'NodeSocketFloat')
            rings_distortion_socket.default_value = 1.5
            rings_distortion_socket.min_value = 0.0
            rings_distortion_socket.max_value = 100.0
            rings_distortion_socket.subtype = 'NONE'
            rings_distortion_socket.attribute_domain = 'POINT'
            rings_distortion_socket.description = "Affects detail"

            #Socket Rings Detail Scale
            rings_detail_scale_socket = realwood.interface.new_socket(name = "Rings Detail Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
            rings_detail_scale_socket.default_value = 13.300000190734863
            rings_detail_scale_socket.min_value = 0.0
            rings_detail_scale_socket.max_value = 100.0
            rings_detail_scale_socket.subtype = 'NONE'
            rings_detail_scale_socket.attribute_domain = 'POINT'
            rings_detail_scale_socket.description = "Depends on distorsion"

            #Socket Rings Noise Factor
            rings_noise_factor_socket = realwood.interface.new_socket(name = "Rings Noise Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
            rings_noise_factor_socket.default_value = 0.6000000238418579
            rings_noise_factor_socket.min_value = 0.0
            rings_noise_factor_socket.max_value = 1.0
            rings_noise_factor_socket.subtype = 'FACTOR'
            rings_noise_factor_socket.attribute_domain = 'POINT'

            #Socket Rings Noise Scale
            rings_noise_scale_socket = realwood.interface.new_socket(name = "Rings Noise Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
            rings_noise_scale_socket.default_value = 2.0
            rings_noise_scale_socket.min_value = 0.0
            rings_noise_scale_socket.max_value = 100.0
            rings_noise_scale_socket.subtype = 'NONE'
            rings_noise_scale_socket.attribute_domain = 'POINT'

            #Socket Earlywood Color
            earlywood_color_socket = realwood.interface.new_socket(name = "Earlywood Color", in_out='INPUT', socket_type = 'NodeSocketColor')
            earlywood_color_socket.default_value = (0.5149077773094177, 0.266356885433197, 0.1499614715576172, 1.0)
            earlywood_color_socket.attribute_domain = 'POINT'
            earlywood_color_socket.description = "Lighter rings"

            #Socket Latewood Color
            latewood_color_socket = realwood.interface.new_socket(name = "Latewood Color", in_out='INPUT', socket_type = 'NodeSocketColor')
            latewood_color_socket.default_value = (0.04518597573041916, 0.012983039952814579, 0.009134063497185707, 1.0)
            latewood_color_socket.attribute_domain = 'POINT'
            latewood_color_socket.description = "Color of darker rings"

            #Socket Knots Scale
            knots_scale_socket = realwood.interface.new_socket(name = "Knots Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
            knots_scale_socket.default_value = 2.729999303817749
            knots_scale_socket.min_value = 0.09999999403953552
            knots_scale_socket.max_value = 100.0
            knots_scale_socket.subtype = 'NONE'
            knots_scale_socket.attribute_domain = 'POINT'

            #Socket Knots Variation
            knots_variation_socket = realwood.interface.new_socket(name = "Knots Variation", in_out='INPUT', socket_type = 'NodeSocketFloat')
            knots_variation_socket.default_value = 28.799964904785156
            knots_variation_socket.min_value = 0.0
            knots_variation_socket.max_value = 1000.0
            knots_variation_socket.subtype = 'NONE'
            knots_variation_socket.attribute_domain = 'POINT'

            #Socket Knots Coverage
            knots_coverage_socket = realwood.interface.new_socket(name = "Knots Coverage", in_out='INPUT', socket_type = 'NodeSocketFloat')
            knots_coverage_socket.default_value = 0.8999999761581421
            knots_coverage_socket.min_value = 0.0
            knots_coverage_socket.max_value = 1.0
            knots_coverage_socket.subtype = 'NONE'
            knots_coverage_socket.attribute_domain = 'POINT'
            knots_coverage_socket.description = "How much of the knot area is covered by knot color"

            #Socket Knots Tightness
            knots_tightness_socket = realwood.interface.new_socket(name = "Knots Tightness", in_out='INPUT', socket_type = 'NodeSocketFloat')
            knots_tightness_socket.default_value = 2.0999999046325684
            knots_tightness_socket.min_value = 0.0
            knots_tightness_socket.max_value = 100.0
            knots_tightness_socket.subtype = 'NONE'
            knots_tightness_socket.attribute_domain = 'POINT'

            #Socket Knots Height
            knots_height_socket = realwood.interface.new_socket(name = "Knots Height", in_out='INPUT', socket_type = 'NodeSocketFloat')
            knots_height_socket.default_value = 3.0
            knots_height_socket.min_value = 0.0
            knots_height_socket.max_value = 100.0
            knots_height_socket.subtype = 'NONE'
            knots_height_socket.attribute_domain = 'POINT'

            #Socket Knots Border
            knots_border_socket = realwood.interface.new_socket(name = "Knots Border", in_out='INPUT', socket_type = 'NodeSocketFloat')
            knots_border_socket.default_value = 1.0
            knots_border_socket.min_value = 0.0
            knots_border_socket.max_value = 1.0
            knots_border_socket.subtype = 'FACTOR'
            knots_border_socket.attribute_domain = 'POINT'

            #Socket Knot Roughness
            knot_roughness_socket = realwood.interface.new_socket(name = "Knot Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat')
            knot_roughness_socket.default_value = 0.0
            knot_roughness_socket.min_value = 0.0
            knot_roughness_socket.max_value = 1.0
            knot_roughness_socket.subtype = 'FACTOR'
            knot_roughness_socket.attribute_domain = 'POINT'

            #Socket Knot Angle Seed
            knot_angle_seed_socket = realwood.interface.new_socket(name = "Knot Angle Seed", in_out='INPUT', socket_type = 'NodeSocketFloat')
            knot_angle_seed_socket.default_value = 15.899999618530273
            knot_angle_seed_socket.min_value = -10000.0
            knot_angle_seed_socket.max_value = 10000.0
            knot_angle_seed_socket.subtype = 'NONE'
            knot_angle_seed_socket.attribute_domain = 'POINT'
            knot_angle_seed_socket.description = "Changes knot inclination based on seed and its variation changes within mask"

            #Socket Knots Color
            knots_color_socket = realwood.interface.new_socket(name = "Knots Color", in_out='INPUT', socket_type = 'NodeSocketColor')
            knots_color_socket.default_value = (0.015348337590694427, 0.006751388311386108, 0.003456177655607462, 1.0)
            knots_color_socket.attribute_domain = 'POINT'

            #Socket Heartwood Radius
            heartwood_radius_socket = realwood.interface.new_socket(name = "Heartwood Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
            heartwood_radius_socket.default_value = 2.5
            heartwood_radius_socket.min_value = 0.0
            heartwood_radius_socket.max_value = 100.0
            heartwood_radius_socket.subtype = 'NONE'
            heartwood_radius_socket.attribute_domain = 'POINT'
            heartwood_radius_socket.description = "Area covered by darker dying area of wood"

            #Socket Heartwood Color
            heartwood_color_socket = realwood.interface.new_socket(name = "Heartwood Color", in_out='INPUT', socket_type = 'NodeSocketColor')
            heartwood_color_socket.default_value = (0.0, 0.0, 0.0, 1.0)
            heartwood_color_socket.attribute_domain = 'POINT'

            #Socket Pores Scale
            pores_scale_socket = realwood.interface.new_socket(name = "Pores Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
            pores_scale_socket.default_value = 250.0
            pores_scale_socket.min_value = 0.0
            pores_scale_socket.max_value = 1000.0
            pores_scale_socket.subtype = 'NONE'
            pores_scale_socket.attribute_domain = 'POINT'

            #Socket Pores Noise Scale
            pores_noise_scale_socket = realwood.interface.new_socket(name = "Pores Noise Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
            pores_noise_scale_socket.default_value = 3.0
            pores_noise_scale_socket.min_value = 0.0
            pores_noise_scale_socket.max_value = 1000.0
            pores_noise_scale_socket.subtype = 'NONE'
            pores_noise_scale_socket.attribute_domain = 'POINT'

            #Socket Pores Width
            pores_width_socket = realwood.interface.new_socket(name = "Pores Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
            pores_width_socket.default_value = 0.17000000178813934
            pores_width_socket.min_value = 0.0
            pores_width_socket.max_value = 1.0
            pores_width_socket.subtype = 'NONE'
            pores_width_socket.attribute_domain = 'POINT'

            #Socket Pores Roughness
            pores_roughness_socket = realwood.interface.new_socket(name = "Pores Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat')
            pores_roughness_socket.default_value = 0.0
            pores_roughness_socket.min_value = 0.0
            pores_roughness_socket.max_value = 1.0
            pores_roughness_socket.subtype = 'FACTOR'
            pores_roughness_socket.attribute_domain = 'POINT'

            #Socket Pores Color
            pores_color_socket = realwood.interface.new_socket(name = "Pores Color", in_out='INPUT', socket_type = 'NodeSocketColor')
            pores_color_socket.default_value = (0.17464381456375122, 0.09989693760871887, 0.04373428598046303, 1.0)
            pores_color_socket.attribute_domain = 'POINT'

            #Socket Rays Scale
            rays_scale_socket = realwood.interface.new_socket(name = "Rays Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
            rays_scale_socket.default_value = 250.0
            rays_scale_socket.min_value = 0.0
            rays_scale_socket.max_value = 1000.0
            rays_scale_socket.subtype = 'NONE'
            rays_scale_socket.attribute_domain = 'POINT'

            #Socket Rays Tightness
            rays_tightness_socket = realwood.interface.new_socket(name = "Rays Tightness", in_out='INPUT', socket_type = 'NodeSocketFloat')
            rays_tightness_socket.default_value = 2.700000047683716
            rays_tightness_socket.min_value = 0.0
            rays_tightness_socket.max_value = 1000.0
            rays_tightness_socket.subtype = 'NONE'
            rays_tightness_socket.attribute_domain = 'POINT'

            #Socket Rays Height
            rays_height_socket = realwood.interface.new_socket(name = "Rays Height", in_out='INPUT', socket_type = 'NodeSocketFloat')
            rays_height_socket.default_value = 2.0
            rays_height_socket.min_value = 0.0
            rays_height_socket.max_value = 1000.0
            rays_height_socket.subtype = 'NONE'
            rays_height_socket.attribute_domain = 'POINT'

            #Socket Rays Roughness
            rays_roughness_socket = realwood.interface.new_socket(name = "Rays Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat')
            rays_roughness_socket.default_value = 0.292817622423172
            rays_roughness_socket.min_value = 0.0
            rays_roughness_socket.max_value = 1.0
            rays_roughness_socket.subtype = 'FACTOR'
            rays_roughness_socket.attribute_domain = 'POINT'

            #Socket Rays Color
            rays_color_socket = realwood.interface.new_socket(name = "Rays Color", in_out='INPUT', socket_type = 'NodeSocketColor')
            rays_color_socket.default_value = (0.40723687410354614, 0.24227915704250336, 0.19806824624538422, 1.0)
            rays_color_socket.attribute_domain = 'POINT'

            #Socket Flecks Scale
            flecks_scale_socket = realwood.interface.new_socket(name = "Flecks Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
            flecks_scale_socket.default_value = 80.19999694824219
            flecks_scale_socket.min_value = 0.0
            flecks_scale_socket.max_value = 1000.0
            flecks_scale_socket.subtype = 'NONE'
            flecks_scale_socket.attribute_domain = 'POINT'

            #Socket Flecks Variation
            flecks_variation_socket = realwood.interface.new_socket(name = "Flecks Variation", in_out='INPUT', socket_type = 'NodeSocketFloat')
            flecks_variation_socket.default_value = 80.19999694824219
            flecks_variation_socket.min_value = 0.0
            flecks_variation_socket.max_value = 1000.0
            flecks_variation_socket.subtype = 'NONE'
            flecks_variation_socket.attribute_domain = 'POINT'

            #Socket Flecks Roughness
            flecks_roughness_socket = realwood.interface.new_socket(name = "Flecks Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat')
            flecks_roughness_socket.default_value = 0.4000000059604645
            flecks_roughness_socket.min_value = 0.0
            flecks_roughness_socket.max_value = 1.0
            flecks_roughness_socket.subtype = 'NONE'
            flecks_roughness_socket.attribute_domain = 'POINT'

            #Socket Flecks Color
            flecks_color_socket = realwood.interface.new_socket(name = "Flecks Color", in_out='INPUT', socket_type = 'NodeSocketColor')
            flecks_color_socket.default_value = (0.035601768642663956, 0.022174019366502762, 0.010330025106668472, 1.0)
            flecks_color_socket.attribute_domain = 'POINT'

            #Socket Bump Strength
            bump_strength_socket = realwood.interface.new_socket(name = "Bump Strength", in_out='INPUT', socket_type = 'NodeSocketFloat')
            bump_strength_socket.default_value = 0.5
            bump_strength_socket.min_value = 0.0
            bump_strength_socket.max_value = 1.0
            bump_strength_socket.subtype = 'FACTOR'
            bump_strength_socket.attribute_domain = 'POINT'

            #Socket Bump Pores Strength
            bump_pores_strength_socket = realwood.interface.new_socket(name = "Bump Pores Strength", in_out='INPUT', socket_type = 'NodeSocketFloat')
            bump_pores_strength_socket.default_value = 0.20000000298023224
            bump_pores_strength_socket.min_value = 0.0
            bump_pores_strength_socket.max_value = 1.0
            bump_pores_strength_socket.subtype = 'NONE'
            bump_pores_strength_socket.attribute_domain = 'POINT'

            #Socket Reflection Strength
            reflection_strength_socket = realwood.interface.new_socket(name = "Reflection Strength", in_out='INPUT', socket_type = 'NodeSocketFloat')
            reflection_strength_socket.default_value = 0.5
            reflection_strength_socket.min_value = 0.0
            reflection_strength_socket.max_value = 1.0
            reflection_strength_socket.subtype = 'NONE'
            reflection_strength_socket.attribute_domain = 'POINT'

            #Socket Reflection Ray Strength
            reflection_ray_strength_socket = realwood.interface.new_socket(name = "Reflection Ray Strength", in_out='INPUT', socket_type = 'NodeSocketFloat')
            reflection_ray_strength_socket.default_value = 1.0
            reflection_ray_strength_socket.min_value = 0.0
            reflection_ray_strength_socket.max_value = 1.0
            reflection_ray_strength_socket.subtype = 'NONE'
            reflection_ray_strength_socket.attribute_domain = 'POINT'

            #Socket Roughness
            roughness_socket_1 = realwood.interface.new_socket(name = "Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat')
            roughness_socket_1.default_value = 0.5
            roughness_socket_1.min_value = 0.0
            roughness_socket_1.max_value = 1.0
            roughness_socket_1.subtype = 'NONE'
            roughness_socket_1.attribute_domain = 'POINT'


            #initialize realwood nodes
            #node Mapping
            mapping = realwood.nodes.new("ShaderNodeMapping")
            mapping.name = "Mapping"
            mapping.vector_type = 'POINT'

            #node Noise Texture.010
            noise_texture_010 = realwood.nodes.new("ShaderNodeTexNoise")
            noise_texture_010.name = "Noise Texture.010"
            noise_texture_010.noise_dimensions = '4D'
            noise_texture_010.noise_type = 'FBM'
            noise_texture_010.normalize = True
            #Detail
            noise_texture_010.inputs[3].default_value = 15.0
            #Roughness
            noise_texture_010.inputs[4].default_value = 0.0
            #Lacunarity
            noise_texture_010.inputs[5].default_value = 2.0
            #Distortion
            noise_texture_010.inputs[8].default_value = 0.0

            #node Mix.012
            mix_012 = realwood.nodes.new("ShaderNodeMix")
            mix_012.name = "Mix.012"
            mix_012.blend_type = 'LINEAR_LIGHT'
            mix_012.clamp_factor = True
            mix_012.clamp_result = False
            mix_012.data_type = 'RGBA'
            mix_012.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_012.inputs[0].default_value = 0.14088404178619385

            #node Frame.003
            frame_003 = realwood.nodes.new("NodeFrame")
            frame_003.label = "Annual rings"
            frame_003.name = "Frame.003"
            frame_003.label_size = 20
            frame_003.shrink = True

            #node Vector Math.003
            vector_math_003 = realwood.nodes.new("ShaderNodeVectorMath")
            vector_math_003.name = "Vector Math.003"
            vector_math_003.operation = 'LENGTH'

            #node Vector Math.006
            vector_math_006 = realwood.nodes.new("ShaderNodeVectorMath")
            vector_math_006.name = "Vector Math.006"
            vector_math_006.operation = 'MULTIPLY'
            #Vector_001
            vector_math_006.inputs[1].default_value = (1.0, 1.0, 0.0)

            #node Separate XYZ
            separate_xyz = realwood.nodes.new("ShaderNodeSeparateXYZ")
            separate_xyz.name = "Separate XYZ"

            #node Math.005
            math_005 = realwood.nodes.new("ShaderNodeMath")
            math_005.name = "Math.005"
            math_005.operation = 'ARCTAN2'
            math_005.use_clamp = False

            #node Combine XYZ
            combine_xyz = realwood.nodes.new("ShaderNodeCombineXYZ")
            combine_xyz.name = "Combine XYZ"

            #node Combine XYZ.001
            combine_xyz_001 = realwood.nodes.new("ShaderNodeCombineXYZ")
            combine_xyz_001.name = "Combine XYZ.001"
            #Z
            combine_xyz_001.inputs[2].default_value = 0.0

            #node Vector Math.007
            vector_math_007 = realwood.nodes.new("ShaderNodeVectorMath")
            vector_math_007.name = "Vector Math.007"
            vector_math_007.operation = 'LENGTH'

            #node Mapping.003
            mapping_003 = realwood.nodes.new("ShaderNodeMapping")
            mapping_003.name = "Mapping.003"
            mapping_003.vector_type = 'POINT'
            #Location
            mapping_003.inputs[1].default_value = (0.0, 0.0, 0.0)
            #Rotation
            mapping_003.inputs[2].default_value = (0.0, 0.0, 0.0)

            #node Voronoi Texture.005
            voronoi_texture_005 = realwood.nodes.new("ShaderNodeTexVoronoi")
            voronoi_texture_005.name = "Voronoi Texture.005"
            voronoi_texture_005.distance = 'EUCLIDEAN'
            voronoi_texture_005.feature = 'SMOOTH_F1'
            voronoi_texture_005.normalize = False
            voronoi_texture_005.voronoi_dimensions = '4D'
            #Detail
            voronoi_texture_005.inputs[3].default_value = 15.0
            #Lacunarity
            voronoi_texture_005.inputs[5].default_value = 2.0
            #Smoothness
            voronoi_texture_005.inputs[6].default_value = 1.0
            #Randomness
            voronoi_texture_005.inputs[8].default_value = 1.0

            #node Color Ramp
            color_ramp = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp.name = "Color Ramp"
            color_ramp.color_ramp.color_mode = 'RGB'
            color_ramp.color_ramp.hue_interpolation = 'NEAR'
            color_ramp.color_ramp.interpolation = 'EASE'

            #initialize color ramp elements
            color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
            color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
            color_ramp_cre_0.position = 0.0
            color_ramp_cre_0.alpha = 1.0
            color_ramp_cre_0.color = (1.0, 1.0, 1.0, 1.0)

            color_ramp_cre_1 = color_ramp.color_ramp.elements.new(0.052858516573905945)
            color_ramp_cre_1.alpha = 1.0
            color_ramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

            color_ramp_cre_2 = color_ramp.color_ramp.elements.new(0.17894643545150757)
            color_ramp_cre_2.alpha = 1.0
            color_ramp_cre_2.color = (0.0, 0.0, 0.0, 1.0)


            #node Frame.006
            frame_006 = realwood.nodes.new("NodeFrame")
            frame_006.label = "KNOTS"
            frame_006.name = "Frame.006"
            frame_006.mute = True
            frame_006.label_size = 20
            frame_006.shrink = True

            #node Mix.013
            mix_013 = realwood.nodes.new("ShaderNodeMix")
            mix_013.name = "Mix.013"
            mix_013.blend_type = 'MIX'
            mix_013.clamp_factor = True
            mix_013.clamp_result = False
            mix_013.data_type = 'RGBA'
            mix_013.factor_mode = 'UNIFORM'

            #node Vector Rotate
            vector_rotate = realwood.nodes.new("ShaderNodeVectorRotate")
            vector_rotate.name = "Vector Rotate"
            vector_rotate.invert = False
            vector_rotate.rotation_type = 'EULER_XYZ'
            #Center
            vector_rotate.inputs[1].default_value = (0.0, 0.0, 1.0)

            #node White Noise Texture
            white_noise_texture = realwood.nodes.new("ShaderNodeTexWhiteNoise")
            white_noise_texture.name = "White Noise Texture"
            white_noise_texture.noise_dimensions = '1D'

            #node Vector Math.027
            vector_math_027 = realwood.nodes.new("ShaderNodeVectorMath")
            vector_math_027.name = "Vector Math.027"
            vector_math_027.operation = 'NORMALIZE'

            #node Voronoi Texture.006
            voronoi_texture_006 = realwood.nodes.new("ShaderNodeTexVoronoi")
            voronoi_texture_006.name = "Voronoi Texture.006"
            voronoi_texture_006.distance = 'EUCLIDEAN'
            voronoi_texture_006.feature = 'SMOOTH_F1'
            voronoi_texture_006.normalize = False
            voronoi_texture_006.voronoi_dimensions = '3D'
            #Scale
            voronoi_texture_006.inputs[2].default_value = 2.1000001430511475
            #Detail
            voronoi_texture_006.inputs[3].default_value = 0.0
            #Roughness
            voronoi_texture_006.inputs[4].default_value = 0.0
            #Lacunarity
            voronoi_texture_006.inputs[5].default_value = 2.0
            #Smoothness
            voronoi_texture_006.inputs[6].default_value = 1.0
            #Randomness
            voronoi_texture_006.inputs[8].default_value = 1.0

            #node Combine XYZ.003
            combine_xyz_003 = realwood.nodes.new("ShaderNodeCombineXYZ")
            combine_xyz_003.name = "Combine XYZ.003"
            #Y
            combine_xyz_003.inputs[1].default_value = 0.0
            #Z
            combine_xyz_003.inputs[2].default_value = 0.0

            #node Math.011
            math_011 = realwood.nodes.new("ShaderNodeMath")
            math_011.name = "Math.011"
            math_011.operation = 'RADIANS'
            math_011.use_clamp = False

            #node Map Range.001
            map_range_001 = realwood.nodes.new("ShaderNodeMapRange")
            map_range_001.name = "Map Range.001"
            map_range_001.clamp = True
            map_range_001.data_type = 'FLOAT'
            map_range_001.interpolation_type = 'LINEAR'
            #From Min
            map_range_001.inputs[1].default_value = 0.0
            #From Max
            map_range_001.inputs[2].default_value = 1.0
            #To Min
            map_range_001.inputs[3].default_value = -15.399998664855957
            #To Max
            map_range_001.inputs[4].default_value = 0.0

            #node Vector Rotate.001
            vector_rotate_001 = realwood.nodes.new("ShaderNodeVectorRotate")
            vector_rotate_001.name = "Vector Rotate.001"
            vector_rotate_001.invert = False
            vector_rotate_001.rotation_type = 'EULER_XYZ'
            #Center
            vector_rotate_001.inputs[1].default_value = (0.0, 0.0, 1.0)

            #node Combine XYZ.004
            combine_xyz_004 = realwood.nodes.new("ShaderNodeCombineXYZ")
            combine_xyz_004.name = "Combine XYZ.004"
            #Y
            combine_xyz_004.inputs[1].default_value = 0.0
            #Z
            combine_xyz_004.inputs[2].default_value = 0.0

            #node Math.012
            math_012 = realwood.nodes.new("ShaderNodeMath")
            math_012.name = "Math.012"
            math_012.operation = 'RADIANS'
            math_012.use_clamp = False

            #node Map Range.002
            map_range_002 = realwood.nodes.new("ShaderNodeMapRange")
            map_range_002.name = "Map Range.002"
            map_range_002.clamp = True
            map_range_002.data_type = 'FLOAT'
            map_range_002.interpolation_type = 'LINEAR'
            #From Min
            map_range_002.inputs[1].default_value = 0.0
            #From Max
            map_range_002.inputs[2].default_value = 1.0
            #To Min
            map_range_002.inputs[3].default_value = -13.0
            #To Max
            map_range_002.inputs[4].default_value = 0.0

            #node Mix.014
            mix_014 = realwood.nodes.new("ShaderNodeMix")
            mix_014.name = "Mix.014"
            mix_014.blend_type = 'MIX'
            mix_014.clamp_factor = True
            mix_014.clamp_result = False
            mix_014.data_type = 'VECTOR'
            mix_014.factor_mode = 'UNIFORM'

            #node White Noise Texture.002
            white_noise_texture_002 = realwood.nodes.new("ShaderNodeTexWhiteNoise")
            white_noise_texture_002.name = "White Noise Texture.002"
            white_noise_texture_002.noise_dimensions = '1D'

            #node Frame.007
            frame_007 = realwood.nodes.new("NodeFrame")
            frame_007.label = "Random Knot Mask rotation"
            frame_007.name = "Frame.007"
            frame_007.label_size = 20
            frame_007.shrink = True

            #node Math.014
            math_014 = realwood.nodes.new("ShaderNodeMath")
            math_014.name = "Math.014"
            math_014.operation = 'SUBTRACT'
            math_014.use_clamp = False

            #node Math.019
            math_019 = realwood.nodes.new("ShaderNodeMath")
            math_019.name = "Math.019"
            math_019.operation = 'LOGARITHM'
            math_019.use_clamp = False
            #Value_001
            math_019.inputs[1].default_value = 2.700000047683716

            #node Color Ramp.011
            color_ramp_011 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_011.name = "Color Ramp.011"
            color_ramp_011.color_ramp.color_mode = 'RGB'
            color_ramp_011.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_011.color_ramp.interpolation = 'B_SPLINE'

            #initialize color ramp elements
            color_ramp_011.color_ramp.elements.remove(color_ramp_011.color_ramp.elements[0])
            color_ramp_011_cre_0 = color_ramp_011.color_ramp.elements[0]
            color_ramp_011_cre_0.position = 0.009063445031642914
            color_ramp_011_cre_0.alpha = 1.0
            color_ramp_011_cre_0.color = (1.0, 1.0, 1.0, 1.0)

            color_ramp_011_cre_1 = color_ramp_011.color_ramp.elements.new(0.09127712994813919)
            color_ramp_011_cre_1.alpha = 1.0
            color_ramp_011_cre_1.color = (0.09171319752931595, 0.09171319752931595, 0.09171319752931595, 1.0)

            color_ramp_011_cre_2 = color_ramp_011.color_ramp.elements.new(0.2170076221227646)
            color_ramp_011_cre_2.alpha = 1.0
            color_ramp_011_cre_2.color = (0.0, 0.0, 0.0, 1.0)


            #node Mix.019
            mix_019 = realwood.nodes.new("ShaderNodeMix")
            mix_019.name = "Mix.019"
            mix_019.blend_type = 'SCREEN'
            mix_019.clamp_factor = False
            mix_019.clamp_result = False
            mix_019.data_type = 'RGBA'
            mix_019.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_019.inputs[0].default_value = 1.0

            #node Invert Color.002
            invert_color_002 = realwood.nodes.new("ShaderNodeInvert")
            invert_color_002.name = "Invert Color.002"

            #node Voronoi Texture.008
            voronoi_texture_008 = realwood.nodes.new("ShaderNodeTexVoronoi")
            voronoi_texture_008.name = "Voronoi Texture.008"
            voronoi_texture_008.distance = 'EUCLIDEAN'
            voronoi_texture_008.feature = 'F1'
            voronoi_texture_008.normalize = True
            voronoi_texture_008.voronoi_dimensions = '3D'
            #Detail
            voronoi_texture_008.inputs[3].default_value = 15.0
            #Lacunarity
            voronoi_texture_008.inputs[5].default_value = 2.0
            #Randomness
            voronoi_texture_008.inputs[8].default_value = 1.0

            #node Vector Math.013
            vector_math_013 = realwood.nodes.new("ShaderNodeVectorMath")
            vector_math_013.name = "Vector Math.013"
            vector_math_013.operation = 'MULTIPLY'

            #node Color Ramp.008
            color_ramp_008 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_008.name = "Color Ramp.008"
            color_ramp_008.color_ramp.color_mode = 'RGB'
            color_ramp_008.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_008.color_ramp.interpolation = 'EASE'

            #initialize color ramp elements
            color_ramp_008.color_ramp.elements.remove(color_ramp_008.color_ramp.elements[0])
            color_ramp_008_cre_0 = color_ramp_008.color_ramp.elements[0]
            color_ramp_008_cre_0.position = 0.163503035902977
            color_ramp_008_cre_0.alpha = 1.0
            color_ramp_008_cre_0.color = (1.0, 1.0, 1.0, 1.0)

            color_ramp_008_cre_1 = color_ramp_008.color_ramp.elements.new(0.1675504446029663)
            color_ramp_008_cre_1.alpha = 1.0
            color_ramp_008_cre_1.color = (0.0, 0.0, 0.0, 1.0)

            color_ramp_008_cre_2 = color_ramp_008.color_ramp.elements.new(0.17301036417484283)
            color_ramp_008_cre_2.alpha = 1.0
            color_ramp_008_cre_2.color = (1.0, 1.0, 1.0, 1.0)

            color_ramp_008_cre_3 = color_ramp_008.color_ramp.elements.new(0.18250256776809692)
            color_ramp_008_cre_3.alpha = 1.0
            color_ramp_008_cre_3.color = (1.0, 1.0, 1.0, 1.0)


            #node Vector Math.015
            vector_math_015 = realwood.nodes.new("ShaderNodeVectorMath")
            vector_math_015.name = "Vector Math.015"
            vector_math_015.operation = 'LENGTH'

            #node Mix.015
            mix_015 = realwood.nodes.new("ShaderNodeMix")
            mix_015.name = "Mix.015"
            mix_015.blend_type = 'SCREEN'
            mix_015.clamp_factor = False
            mix_015.clamp_result = False
            mix_015.data_type = 'RGBA'
            mix_015.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_015.inputs[0].default_value = 1.0

            #node Color Ramp.012
            color_ramp_012 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_012.name = "Color Ramp.012"
            color_ramp_012.color_ramp.color_mode = 'RGB'
            color_ramp_012.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_012.color_ramp.interpolation = 'B_SPLINE'

            #initialize color ramp elements
            color_ramp_012.color_ramp.elements.remove(color_ramp_012.color_ramp.elements[0])
            color_ramp_012_cre_0 = color_ramp_012.color_ramp.elements[0]
            color_ramp_012_cre_0.position = 0.04842104762792587
            color_ramp_012_cre_0.alpha = 1.0
            color_ramp_012_cre_0.color = (1.0, 1.0, 1.0, 1.0)

            color_ramp_012_cre_1 = color_ramp_012.color_ramp.elements.new(0.07578941434621811)
            color_ramp_012_cre_1.alpha = 1.0
            color_ramp_012_cre_1.color = (0.0, 0.0, 0.0, 1.0)

            color_ramp_012_cre_2 = color_ramp_012.color_ramp.elements.new(0.1410527378320694)
            color_ramp_012_cre_2.alpha = 1.0
            color_ramp_012_cre_2.color = (0.0, 0.0, 0.0, 1.0)


            #node Vector Math.026
            vector_math_026 = realwood.nodes.new("ShaderNodeVectorMath")
            vector_math_026.name = "Vector Math.026"
            vector_math_026.operation = 'SCALE'
            #Scale
            vector_math_026.inputs[3].default_value = 0.10000002384185791

            #node Mix.017
            mix_017 = realwood.nodes.new("ShaderNodeMix")
            mix_017.name = "Mix.017"
            mix_017.blend_type = 'MULTIPLY'
            mix_017.clamp_factor = True
            mix_017.clamp_result = True
            mix_017.data_type = 'RGBA'
            mix_017.factor_mode = 'UNIFORM'

            #node Noise Texture.004
            noise_texture_004 = realwood.nodes.new("ShaderNodeTexNoise")
            noise_texture_004.name = "Noise Texture.004"
            noise_texture_004.noise_dimensions = '3D'
            noise_texture_004.noise_type = 'FBM'
            noise_texture_004.normalize = True
            #Detail
            noise_texture_004.inputs[3].default_value = 15.0
            #Roughness
            noise_texture_004.inputs[4].default_value = 0.0
            #Lacunarity
            noise_texture_004.inputs[5].default_value = 2.0
            #Distortion
            noise_texture_004.inputs[8].default_value = 0.0

            #node Frame.009
            frame_009 = realwood.nodes.new("NodeFrame")
            frame_009.label = "Pores"
            frame_009.name = "Frame.009"
            frame_009.label_size = 20
            frame_009.shrink = True

            #node Noise Texture.005
            noise_texture_005 = realwood.nodes.new("ShaderNodeTexNoise")
            noise_texture_005.name = "Noise Texture.005"
            noise_texture_005.noise_dimensions = '4D'
            noise_texture_005.noise_type = 'RIDGED_MULTIFRACTAL'
            noise_texture_005.normalize = False
            #Detail
            noise_texture_005.inputs[3].default_value = 7.200000286102295
            #Lacunarity
            noise_texture_005.inputs[5].default_value = 2.0
            #Offset
            noise_texture_005.inputs[6].default_value = 1.4000000953674316
            #Gain
            noise_texture_005.inputs[7].default_value = 22.69999885559082
            #Distortion
            noise_texture_005.inputs[8].default_value = 0.0

            #node Color Ramp.013
            color_ramp_013 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_013.name = "Color Ramp.013"
            color_ramp_013.color_ramp.color_mode = 'RGB'
            color_ramp_013.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_013.color_ramp.interpolation = 'EASE'

            #initialize color ramp elements
            color_ramp_013.color_ramp.elements.remove(color_ramp_013.color_ramp.elements[0])
            color_ramp_013_cre_0 = color_ramp_013.color_ramp.elements[0]
            color_ramp_013_cre_0.position = 0.003021148033440113
            color_ramp_013_cre_0.alpha = 1.0
            color_ramp_013_cre_0.color = (1.0, 1.0, 1.0, 1.0)

            color_ramp_013_cre_1 = color_ramp_013.color_ramp.elements.new(0.9879148006439209)
            color_ramp_013_cre_1.alpha = 1.0
            color_ramp_013_cre_1.color = (0.0, 0.0, 0.0, 1.0)


            #node Mapping.005
            mapping_005 = realwood.nodes.new("ShaderNodeMapping")
            mapping_005.name = "Mapping.005"
            mapping_005.vector_type = 'POINT'
            #Location
            mapping_005.inputs[1].default_value = (0.0, 0.0, 0.0)
            #Rotation
            mapping_005.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Scale
            mapping_005.inputs[3].default_value = (2.299999952316284, 2.299999952316284, 2.6999998092651367)

            #node Frame.010
            frame_010 = realwood.nodes.new("NodeFrame")
            frame_010.label = "Pith Flecks"
            frame_010.name = "Frame.010"
            frame_010.label_size = 20
            frame_010.shrink = True

            #node Wave Texture.002
            wave_texture_002 = realwood.nodes.new("ShaderNodeTexWave")
            wave_texture_002.name = "Wave Texture.002"
            wave_texture_002.bands_direction = 'Z'
            wave_texture_002.rings_direction = 'X'
            wave_texture_002.wave_profile = 'SIN'
            wave_texture_002.wave_type = 'BANDS'
            #Scale
            wave_texture_002.inputs[1].default_value = 0.30000025033950806
            #Distortion
            wave_texture_002.inputs[2].default_value = 2.1999998092651367
            #Detail
            wave_texture_002.inputs[3].default_value = 15.0
            #Detail Scale
            wave_texture_002.inputs[4].default_value = 0.20000004768371582
            #Detail Roughness
            wave_texture_002.inputs[5].default_value = 0.0
            #Phase Offset
            wave_texture_002.inputs[6].default_value = 0.0

            #node Color Ramp.014
            color_ramp_014 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_014.name = "Color Ramp.014"
            color_ramp_014.color_ramp.color_mode = 'RGB'
            color_ramp_014.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_014.color_ramp.interpolation = 'B_SPLINE'

            #initialize color ramp elements
            color_ramp_014.color_ramp.elements.remove(color_ramp_014.color_ramp.elements[0])
            color_ramp_014_cre_0 = color_ramp_014.color_ramp.elements[0]
            color_ramp_014_cre_0.position = 0.0
            color_ramp_014_cre_0.alpha = 1.0
            color_ramp_014_cre_0.color = (0.0, 0.0, 0.0, 1.0)

            color_ramp_014_cre_1 = color_ramp_014.color_ramp.elements.new(0.2507552206516266)
            color_ramp_014_cre_1.alpha = 1.0
            color_ramp_014_cre_1.color = (1.0, 1.0, 1.0, 1.0)


            #node Mix.016
            mix_016 = realwood.nodes.new("ShaderNodeMix")
            mix_016.name = "Mix.016"
            mix_016.blend_type = 'MIX'
            mix_016.clamp_factor = False
            mix_016.clamp_result = False
            mix_016.data_type = 'RGBA'
            mix_016.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_016.inputs[0].default_value = 0.49171265959739685

            #node Wave Texture.003
            wave_texture_003 = realwood.nodes.new("ShaderNodeTexWave")
            wave_texture_003.name = "Wave Texture.003"
            wave_texture_003.bands_direction = 'Y'
            wave_texture_003.rings_direction = 'Z'
            wave_texture_003.wave_profile = 'SAW'
            wave_texture_003.wave_type = 'RINGS'
            #Detail
            wave_texture_003.inputs[3].default_value = 15.0
            #Detail Roughness
            wave_texture_003.inputs[5].default_value = 1.0

            #node Mix.021
            mix_021 = realwood.nodes.new("ShaderNodeMix")
            mix_021.name = "Mix.021"
            mix_021.blend_type = 'MULTIPLY'
            mix_021.clamp_factor = True
            mix_021.clamp_result = True
            mix_021.data_type = 'RGBA'
            mix_021.factor_mode = 'UNIFORM'

            #node Invert Color.003
            invert_color_003 = realwood.nodes.new("ShaderNodeInvert")
            invert_color_003.name = "Invert Color.003"
            #Fac
            invert_color_003.inputs[0].default_value = 1.0

            #node Mix.020
            mix_020 = realwood.nodes.new("ShaderNodeMix")
            mix_020.name = "Mix.020"
            mix_020.blend_type = 'MIX'
            mix_020.clamp_factor = True
            mix_020.clamp_result = True
            mix_020.data_type = 'RGBA'
            mix_020.factor_mode = 'UNIFORM'

            #node Mix.022
            mix_022 = realwood.nodes.new("ShaderNodeMix")
            mix_022.name = "Mix.022"
            mix_022.blend_type = 'MULTIPLY'
            mix_022.clamp_factor = False
            mix_022.clamp_result = False
            mix_022.data_type = 'RGBA'
            mix_022.factor_mode = 'UNIFORM'

            #node Invert Color.004
            invert_color_004 = realwood.nodes.new("ShaderNodeInvert")
            invert_color_004.name = "Invert Color.004"
            #Fac
            invert_color_004.inputs[0].default_value = 1.0

            #node Color Ramp.016
            color_ramp_016 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_016.name = "Color Ramp.016"
            color_ramp_016.color_ramp.color_mode = 'RGB'
            color_ramp_016.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_016.color_ramp.interpolation = 'B_SPLINE'

            #initialize color ramp elements
            color_ramp_016.color_ramp.elements.remove(color_ramp_016.color_ramp.elements[0])
            color_ramp_016_cre_0 = color_ramp_016.color_ramp.elements[0]
            color_ramp_016_cre_0.position = 0.0
            color_ramp_016_cre_0.alpha = 1.0
            color_ramp_016_cre_0.color = (0.7671716213226318, 0.7671716213226318, 0.7671716213226318, 1.0)

            color_ramp_016_cre_1 = color_ramp_016.color_ramp.elements.new(0.11782451719045639)
            color_ramp_016_cre_1.alpha = 1.0
            color_ramp_016_cre_1.color = (0.0, 0.0, 0.0, 1.0)


            #node Mix.023
            mix_023 = realwood.nodes.new("ShaderNodeMix")
            mix_023.name = "Mix.023"
            mix_023.blend_type = 'DARKEN'
            mix_023.clamp_factor = False
            mix_023.clamp_result = False
            mix_023.data_type = 'RGBA'
            mix_023.factor_mode = 'UNIFORM'

            #node Math.007
            math_007 = realwood.nodes.new("ShaderNodeMath")
            math_007.name = "Math.007"
            math_007.operation = 'GREATER_THAN'
            math_007.use_clamp = False

            #node Frame.012
            frame_012 = realwood.nodes.new("NodeFrame")
            frame_012.label = "Cylinder offset"
            frame_012.name = "Frame.012"
            frame_012.label_size = 20
            frame_012.shrink = True

            #node Mix.025
            mix_025 = realwood.nodes.new("ShaderNodeMix")
            mix_025.name = "Mix.025"
            mix_025.blend_type = 'MIX'
            mix_025.clamp_factor = True
            mix_025.clamp_result = False
            mix_025.data_type = 'RGBA'
            mix_025.factor_mode = 'UNIFORM'

            #node Mix.026
            mix_026 = realwood.nodes.new("ShaderNodeMix")
            mix_026.name = "Mix.026"
            mix_026.blend_type = 'SUBTRACT'
            mix_026.clamp_factor = True
            mix_026.clamp_result = True
            mix_026.data_type = 'RGBA'
            mix_026.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_026.inputs[0].default_value = 1.0

            #node Mix.024
            mix_024 = realwood.nodes.new("ShaderNodeMix")
            mix_024.name = "Mix.024"
            mix_024.blend_type = 'SUBTRACT'
            mix_024.clamp_factor = True
            mix_024.clamp_result = True
            mix_024.data_type = 'RGBA'
            mix_024.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_024.inputs[0].default_value = 1.0

            #node Color Ramp.018
            color_ramp_018 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_018.name = "Color Ramp.018"
            color_ramp_018.color_ramp.color_mode = 'RGB'
            color_ramp_018.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_018.color_ramp.interpolation = 'LINEAR'

            #initialize color ramp elements
            color_ramp_018.color_ramp.elements.remove(color_ramp_018.color_ramp.elements[0])
            color_ramp_018_cre_0 = color_ramp_018.color_ramp.elements[0]
            color_ramp_018_cre_0.position = 0.5679758191108704
            color_ramp_018_cre_0.alpha = 1.0
            color_ramp_018_cre_0.color = (0.0, 0.0, 0.0, 1.0)

            color_ramp_018_cre_1 = color_ramp_018.color_ramp.elements.new(0.963746190071106)
            color_ramp_018_cre_1.alpha = 1.0
            color_ramp_018_cre_1.color = (1.0, 1.0, 1.0, 1.0)


            #node Mix.027
            mix_027 = realwood.nodes.new("ShaderNodeMix")
            mix_027.name = "Mix.027"
            mix_027.blend_type = 'MIX'
            mix_027.clamp_factor = True
            mix_027.clamp_result = True
            mix_027.data_type = 'RGBA'
            mix_027.factor_mode = 'UNIFORM'

            #node Color Ramp.019
            color_ramp_019 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_019.name = "Color Ramp.019"
            color_ramp_019.color_ramp.color_mode = 'RGB'
            color_ramp_019.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_019.color_ramp.interpolation = 'CONSTANT'

            #initialize color ramp elements
            color_ramp_019.color_ramp.elements.remove(color_ramp_019.color_ramp.elements[0])
            color_ramp_019_cre_0 = color_ramp_019.color_ramp.elements[0]
            color_ramp_019_cre_0.position = 0.0
            color_ramp_019_cre_0.alpha = 1.0
            color_ramp_019_cre_0.color = (0.0, 0.0, 0.0, 1.0)

            color_ramp_019_cre_1 = color_ramp_019.color_ramp.elements.new(0.021147988736629486)
            color_ramp_019_cre_1.alpha = 1.0
            color_ramp_019_cre_1.color = (1.0, 1.0, 1.0, 1.0)


            #node Color Ramp.021
            color_ramp_021 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_021.name = "Color Ramp.021"
            color_ramp_021.color_ramp.color_mode = 'RGB'
            color_ramp_021.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_021.color_ramp.interpolation = 'EASE'

            #initialize color ramp elements
            color_ramp_021.color_ramp.elements.remove(color_ramp_021.color_ramp.elements[0])
            color_ramp_021_cre_0 = color_ramp_021.color_ramp.elements[0]
            color_ramp_021_cre_0.position = 0.0
            color_ramp_021_cre_0.alpha = 1.0
            color_ramp_021_cre_0.color = (0.0, 0.0, 0.0, 1.0)

            color_ramp_021_cre_1 = color_ramp_021.color_ramp.elements.new(1.0)
            color_ramp_021_cre_1.alpha = 1.0
            color_ramp_021_cre_1.color = (1.0, 1.0, 1.0, 1.0)


            #node Mix.028
            mix_028 = realwood.nodes.new("ShaderNodeMix")
            mix_028.name = "Mix.028"
            mix_028.blend_type = 'MIX'
            mix_028.clamp_factor = True
            mix_028.clamp_result = False
            mix_028.data_type = 'RGBA'
            mix_028.factor_mode = 'UNIFORM'
            #B_Color
            mix_028.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)

            #node Voronoi Texture.009
            voronoi_texture_009 = realwood.nodes.new("ShaderNodeTexVoronoi")
            voronoi_texture_009.name = "Voronoi Texture.009"
            voronoi_texture_009.distance = 'EUCLIDEAN'
            voronoi_texture_009.feature = 'F1'
            voronoi_texture_009.normalize = True
            voronoi_texture_009.voronoi_dimensions = '3D'
            #Detail
            voronoi_texture_009.inputs[3].default_value = 0.0
            #Roughness
            voronoi_texture_009.inputs[4].default_value = 0.0
            #Lacunarity
            voronoi_texture_009.inputs[5].default_value = 2.0
            #Randomness
            voronoi_texture_009.inputs[8].default_value = 0.7679557800292969

            #node Mix.029
            mix_029 = realwood.nodes.new("ShaderNodeMix")
            mix_029.name = "Mix.029"
            mix_029.blend_type = 'MIX'
            mix_029.clamp_factor = True
            mix_029.clamp_result = False
            mix_029.data_type = 'RGBA'
            mix_029.factor_mode = 'UNIFORM'
            #B_Color
            mix_029.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)

            #node Color Ramp.022
            color_ramp_022 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_022.name = "Color Ramp.022"
            color_ramp_022.color_ramp.color_mode = 'RGB'
            color_ramp_022.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_022.color_ramp.interpolation = 'CONSTANT'

            #initialize color ramp elements
            color_ramp_022.color_ramp.elements.remove(color_ramp_022.color_ramp.elements[0])
            color_ramp_022_cre_0 = color_ramp_022.color_ramp.elements[0]
            color_ramp_022_cre_0.position = 0.0
            color_ramp_022_cre_0.alpha = 1.0
            color_ramp_022_cre_0.color = (0.0, 0.0, 0.0, 1.0)

            color_ramp_022_cre_1 = color_ramp_022.color_ramp.elements.new(0.02526307851076126)
            color_ramp_022_cre_1.alpha = 1.0
            color_ramp_022_cre_1.color = (1.0, 1.0, 1.0, 1.0)


            #node Color Ramp.023
            color_ramp_023 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_023.name = "Color Ramp.023"
            color_ramp_023.color_ramp.color_mode = 'RGB'
            color_ramp_023.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_023.color_ramp.interpolation = 'LINEAR'

            #initialize color ramp elements
            color_ramp_023.color_ramp.elements.remove(color_ramp_023.color_ramp.elements[0])
            color_ramp_023_cre_0 = color_ramp_023.color_ramp.elements[0]
            color_ramp_023_cre_0.position = 0.39274904131889343
            color_ramp_023_cre_0.alpha = 1.0
            color_ramp_023_cre_0.color = (0.6066904067993164, 0.6066904067993164, 0.6066904067993164, 1.0)

            color_ramp_023_cre_1 = color_ramp_023.color_ramp.elements.new(1.0)
            color_ramp_023_cre_1.alpha = 1.0
            color_ramp_023_cre_1.color = (1.0, 1.0, 1.0, 1.0)


            #node Noise Texture.008
            noise_texture_008 = realwood.nodes.new("ShaderNodeTexNoise")
            noise_texture_008.name = "Noise Texture.008"
            noise_texture_008.noise_dimensions = '4D'
            noise_texture_008.noise_type = 'FBM'
            noise_texture_008.normalize = False
            #Vector
            noise_texture_008.inputs[0].default_value = (0.0, 0.0, 0.0)
            #Detail
            noise_texture_008.inputs[3].default_value = 15.0
            #Roughness
            noise_texture_008.inputs[4].default_value = 1.0
            #Lacunarity
            noise_texture_008.inputs[5].default_value = 2.0
            #Distortion
            noise_texture_008.inputs[8].default_value = 0.09999006986618042

            #node Color Ramp.026
            color_ramp_026 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_026.name = "Color Ramp.026"
            color_ramp_026.color_ramp.color_mode = 'RGB'
            color_ramp_026.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_026.color_ramp.interpolation = 'EASE'

            #initialize color ramp elements
            color_ramp_026.color_ramp.elements.remove(color_ramp_026.color_ramp.elements[0])
            color_ramp_026_cre_0 = color_ramp_026.color_ramp.elements[0]
            color_ramp_026_cre_0.position = 0.0
            color_ramp_026_cre_0.alpha = 1.0
            color_ramp_026_cre_0.color = (0.0, 0.0, 0.0, 1.0)

            color_ramp_026_cre_1 = color_ramp_026.color_ramp.elements.new(1.0)
            color_ramp_026_cre_1.alpha = 1.0
            color_ramp_026_cre_1.color = (1.0, 1.0, 1.0, 1.0)


            #node Mix.030
            mix_030 = realwood.nodes.new("ShaderNodeMix")
            mix_030.name = "Mix.030"
            mix_030.blend_type = 'MIX'
            mix_030.clamp_factor = True
            mix_030.clamp_result = False
            mix_030.data_type = 'RGBA'
            mix_030.factor_mode = 'UNIFORM'
            #B_Color
            mix_030.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)

            #node Invert Color.001
            invert_color_001 = realwood.nodes.new("ShaderNodeInvert")
            invert_color_001.name = "Invert Color.001"
            #Fac
            invert_color_001.inputs[0].default_value = 1.0

            #node Mix.031
            mix_031 = realwood.nodes.new("ShaderNodeMix")
            mix_031.name = "Mix.031"
            mix_031.blend_type = 'SUBTRACT'
            mix_031.clamp_factor = True
            mix_031.clamp_result = True
            mix_031.data_type = 'RGBA'
            mix_031.factor_mode = 'UNIFORM'

            #node Invert Color.005
            invert_color_005 = realwood.nodes.new("ShaderNodeInvert")
            invert_color_005.name = "Invert Color.005"
            #Fac
            invert_color_005.inputs[0].default_value = 1.0

            #node Color Ramp.015
            color_ramp_015 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_015.name = "Color Ramp.015"
            color_ramp_015.color_ramp.color_mode = 'RGB'
            color_ramp_015.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_015.color_ramp.interpolation = 'CONSTANT'

            #initialize color ramp elements
            color_ramp_015.color_ramp.elements.remove(color_ramp_015.color_ramp.elements[0])
            color_ramp_015_cre_0 = color_ramp_015.color_ramp.elements[0]
            color_ramp_015_cre_0.position = 0.0
            color_ramp_015_cre_0.alpha = 1.0
            color_ramp_015_cre_0.color = (1.0, 1.0, 1.0, 1.0)

            color_ramp_015_cre_1 = color_ramp_015.color_ramp.elements.new(1.0)
            color_ramp_015_cre_1.alpha = 1.0
            color_ramp_015_cre_1.color = (0.0, 0.0, 0.0, 1.0)


            #node Map Range.003
            map_range_003 = realwood.nodes.new("ShaderNodeMapRange")
            map_range_003.name = "Map Range.003"
            map_range_003.clamp = True
            map_range_003.data_type = 'FLOAT'
            map_range_003.interpolation_type = 'SMOOTHSTEP'
            #From Min
            map_range_003.inputs[1].default_value = 0.0
            #From Max
            map_range_003.inputs[2].default_value = 1.0
            #To Min
            map_range_003.inputs[3].default_value = 0.9999998807907104

            #node Math.008
            math_008 = realwood.nodes.new("ShaderNodeMath")
            math_008.name = "Math.008"
            math_008.operation = 'MULTIPLY'
            math_008.use_clamp = False
            #Value_001
            math_008.inputs[1].default_value = -1.0

            #node Combine XYZ.005
            combine_xyz_005 = realwood.nodes.new("ShaderNodeCombineXYZ")
            combine_xyz_005.name = "Combine XYZ.005"
            #X
            combine_xyz_005.inputs[0].default_value = 1.0
            #Y
            combine_xyz_005.inputs[1].default_value = 1.0

            #node Combine XYZ.006
            combine_xyz_006 = realwood.nodes.new("ShaderNodeCombineXYZ")
            combine_xyz_006.name = "Combine XYZ.006"
            #Y
            combine_xyz_006.inputs[1].default_value = 0.0

            #node Mapping.001
            mapping_001 = realwood.nodes.new("ShaderNodeMapping")
            mapping_001.name = "Mapping.001"
            mapping_001.vector_type = 'POINT'
            #Location
            mapping_001.inputs[1].default_value = (0.0, 0.0, 0.0)
            #Rotation
            mapping_001.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Scale
            mapping_001.inputs[3].default_value = (3.5199992656707764, 3.5199997425079346, 28.000001907348633)

            #node Separate XYZ.002
            separate_xyz_002 = realwood.nodes.new("ShaderNodeSeparateXYZ")
            separate_xyz_002.name = "Separate XYZ.002"

            #node Combine XYZ.007
            combine_xyz_007 = realwood.nodes.new("ShaderNodeCombineXYZ")
            combine_xyz_007.name = "Combine XYZ.007"
            #Y
            combine_xyz_007.inputs[1].default_value = 0.0

            #node Voronoi Texture.004
            voronoi_texture_004 = realwood.nodes.new("ShaderNodeTexVoronoi")
            voronoi_texture_004.name = "Voronoi Texture.004"
            voronoi_texture_004.distance = 'MINKOWSKI'
            voronoi_texture_004.feature = 'SMOOTH_F1'
            voronoi_texture_004.normalize = True
            voronoi_texture_004.voronoi_dimensions = '3D'
            #Detail
            voronoi_texture_004.inputs[3].default_value = 15.0
            #Lacunarity
            voronoi_texture_004.inputs[5].default_value = 1.9999998807907104
            #Smoothness
            voronoi_texture_004.inputs[6].default_value = 1.0
            #Exponent
            voronoi_texture_004.inputs[7].default_value = 32.0
            #Randomness
            voronoi_texture_004.inputs[8].default_value = 1.0

            #node Math.010
            math_010 = realwood.nodes.new("ShaderNodeMath")
            math_010.name = "Math.010"
            math_010.operation = 'ARCTAN2'
            math_010.use_clamp = False

            #node Mapping.006
            mapping_006 = realwood.nodes.new("ShaderNodeMapping")
            mapping_006.name = "Mapping.006"
            mapping_006.vector_type = 'POINT'
            #Location
            mapping_006.inputs[1].default_value = (0.0, 0.0, 0.0)
            #Rotation
            mapping_006.inputs[2].default_value = (0.0, 0.0, 0.0)

            #node Color Ramp.020
            color_ramp_020 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_020.name = "Color Ramp.020"
            color_ramp_020.color_ramp.color_mode = 'RGB'
            color_ramp_020.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_020.color_ramp.interpolation = 'EASE'

            #initialize color ramp elements
            color_ramp_020.color_ramp.elements.remove(color_ramp_020.color_ramp.elements[0])
            color_ramp_020_cre_0 = color_ramp_020.color_ramp.elements[0]
            color_ramp_020_cre_0.position = 0.0
            color_ramp_020_cre_0.alpha = 1.0
            color_ramp_020_cre_0.color = (1.0, 1.0, 1.0, 1.0)

            color_ramp_020_cre_1 = color_ramp_020.color_ramp.elements.new(0.26598379015922546)
            color_ramp_020_cre_1.alpha = 1.0
            color_ramp_020_cre_1.color = (0.0, 0.0, 0.0, 1.0)


            #node Frame.011
            frame_011 = realwood.nodes.new("NodeFrame")
            frame_011.label = "Medullary rays"
            frame_011.name = "Frame.011"
            frame_011.label_size = 20
            frame_011.shrink = True

            #node Mix.032
            mix_032 = realwood.nodes.new("ShaderNodeMix")
            mix_032.name = "Mix.032"
            mix_032.blend_type = 'MIX'
            mix_032.clamp_factor = True
            mix_032.clamp_result = False
            mix_032.data_type = 'RGBA'
            mix_032.factor_mode = 'UNIFORM'
            #B_Color
            mix_032.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)

            #node Mix.033
            mix_033 = realwood.nodes.new("ShaderNodeMix")
            mix_033.name = "Mix.033"
            mix_033.blend_type = 'MIX'
            mix_033.clamp_factor = True
            mix_033.clamp_result = True
            mix_033.data_type = 'RGBA'
            mix_033.factor_mode = 'UNIFORM'
            #B_Color
            mix_033.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)

            #node Mix.034
            mix_034 = realwood.nodes.new("ShaderNodeMix")
            mix_034.name = "Mix.034"
            mix_034.blend_type = 'MIX'
            mix_034.clamp_factor = True
            mix_034.clamp_result = True
            mix_034.data_type = 'RGBA'
            mix_034.factor_mode = 'UNIFORM'
            #B_Color
            mix_034.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)

            #node Mix.035
            mix_035 = realwood.nodes.new("ShaderNodeMix")
            mix_035.name = "Mix.035"
            mix_035.blend_type = 'MIX'
            mix_035.clamp_factor = True
            mix_035.clamp_result = True
            mix_035.data_type = 'RGBA'
            mix_035.factor_mode = 'UNIFORM'

            #node Combine XYZ.008
            combine_xyz_008 = realwood.nodes.new("ShaderNodeCombineXYZ")
            combine_xyz_008.name = "Combine XYZ.008"
            #Y
            combine_xyz_008.inputs[1].default_value = 0.0

            #node Map Range.004
            map_range_004 = realwood.nodes.new("ShaderNodeMapRange")
            map_range_004.name = "Map Range.004"
            map_range_004.clamp = True
            map_range_004.data_type = 'FLOAT'
            map_range_004.interpolation_type = 'LINEAR'
            #From Min
            map_range_004.inputs[1].default_value = 0.0
            #From Max
            map_range_004.inputs[2].default_value = 2.0
            #To Max
            map_range_004.inputs[4].default_value = -0.9999998807907104

            #node Math.009
            math_009 = realwood.nodes.new("ShaderNodeMath")
            math_009.name = "Math.009"
            math_009.operation = 'ADD'
            math_009.use_clamp = False
            #Value_001
            math_009.inputs[1].default_value = 0.4000000059604645

            #node Bump
            bump = realwood.nodes.new("ShaderNodeBump")
            bump.name = "Bump"
            bump.invert = True
            #Distance
            bump.inputs[1].default_value = 0.0010000000474974513
            #Normal
            bump.inputs[3].default_value = (0.0, 0.0, 0.0)

            #node Color Ramp.002
            color_ramp_002 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_002.name = "Color Ramp.002"
            color_ramp_002.color_ramp.color_mode = 'RGB'
            color_ramp_002.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_002.color_ramp.interpolation = 'EASE'

            #initialize color ramp elements
            color_ramp_002.color_ramp.elements.remove(color_ramp_002.color_ramp.elements[0])
            color_ramp_002_cre_0 = color_ramp_002.color_ramp.elements[0]
            color_ramp_002_cre_0.position = 0.9365557432174683
            color_ramp_002_cre_0.alpha = 1.0
            color_ramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

            color_ramp_002_cre_1 = color_ramp_002.color_ramp.elements.new(1.0)
            color_ramp_002_cre_1.alpha = 1.0
            color_ramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)


            #node Color Ramp.003
            color_ramp_003 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_003.name = "Color Ramp.003"
            color_ramp_003.color_ramp.color_mode = 'RGB'
            color_ramp_003.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_003.color_ramp.interpolation = 'EASE'

            #initialize color ramp elements
            color_ramp_003.color_ramp.elements.remove(color_ramp_003.color_ramp.elements[0])
            color_ramp_003_cre_0 = color_ramp_003.color_ramp.elements[0]
            color_ramp_003_cre_0.position = 0.0
            color_ramp_003_cre_0.alpha = 1.0
            color_ramp_003_cre_0.color = (1.0, 1.0, 1.0, 1.0)

            color_ramp_003_cre_1 = color_ramp_003.color_ramp.elements.new(0.7734139561653137)
            color_ramp_003_cre_1.alpha = 1.0
            color_ramp_003_cre_1.color = (0.0, 0.0, 0.0, 1.0)


            #node Mix
            mix = realwood.nodes.new("ShaderNodeMix")
            mix.name = "Mix"
            mix.blend_type = 'MIX'
            mix.clamp_factor = False
            mix.clamp_result = False
            mix.data_type = 'RGBA'
            mix.factor_mode = 'UNIFORM'
            #B_Color
            mix.inputs[7].default_value = (0.35601794719696045, 0.35601794719696045, 0.35601794719696045, 1.0)

            #node Invert Color.007
            invert_color_007 = realwood.nodes.new("ShaderNodeInvert")
            invert_color_007.name = "Invert Color.007"
            #Fac
            invert_color_007.inputs[0].default_value = 1.0

            #node Color Ramp.004
            color_ramp_004 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_004.name = "Color Ramp.004"
            color_ramp_004.color_ramp.color_mode = 'RGB'
            color_ramp_004.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_004.color_ramp.interpolation = 'EASE'

            #initialize color ramp elements
            color_ramp_004.color_ramp.elements.remove(color_ramp_004.color_ramp.elements[0])
            color_ramp_004_cre_0 = color_ramp_004.color_ramp.elements[0]
            color_ramp_004_cre_0.position = 0.0
            color_ramp_004_cre_0.alpha = 1.0
            color_ramp_004_cre_0.color = (0.015008009970188141, 0.015008009970188141, 0.015008009970188141, 1.0)

            color_ramp_004_cre_1 = color_ramp_004.color_ramp.elements.new(0.08157099783420563)
            color_ramp_004_cre_1.alpha = 1.0
            color_ramp_004_cre_1.color = (1.0, 1.0, 1.0, 1.0)


            #node Frame.001
            frame_001 = realwood.nodes.new("NodeFrame")
            frame_001.label = "Normal map"
            frame_001.name = "Frame.001"
            frame_001.label_size = 20
            frame_001.shrink = True

            #node Mix.003
            mix_003 = realwood.nodes.new("ShaderNodeMix")
            mix_003.name = "Mix.003"
            mix_003.blend_type = 'MIX'
            mix_003.clamp_factor = True
            mix_003.clamp_result = True
            mix_003.data_type = 'RGBA'
            mix_003.factor_mode = 'UNIFORM'

            #node Color Ramp.005
            color_ramp_005 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_005.name = "Color Ramp.005"
            color_ramp_005.color_ramp.color_mode = 'RGB'
            color_ramp_005.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_005.color_ramp.interpolation = 'EASE'

            #initialize color ramp elements
            color_ramp_005.color_ramp.elements.remove(color_ramp_005.color_ramp.elements[0])
            color_ramp_005_cre_0 = color_ramp_005.color_ramp.elements[0]
            color_ramp_005_cre_0.position = 0.005730733275413513
            color_ramp_005_cre_0.alpha = 1.0
            color_ramp_005_cre_0.color = (0.4194325804710388, 0.4194325804710388, 0.4194325804710388, 1.0)

            color_ramp_005_cre_1 = color_ramp_005.color_ramp.elements.new(0.6031518578529358)
            color_ramp_005_cre_1.alpha = 1.0
            color_ramp_005_cre_1.color = (0.6457458734512329, 0.6457458734512329, 0.6457458734512329, 1.0)

            color_ramp_005_cre_2 = color_ramp_005.color_ramp.elements.new(1.0)
            color_ramp_005_cre_2.alpha = 1.0
            color_ramp_005_cre_2.color = (1.0, 1.0, 1.0, 1.0)


            #node Color Ramp.007
            color_ramp_007 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_007.name = "Color Ramp.007"
            color_ramp_007.color_ramp.color_mode = 'RGB'
            color_ramp_007.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_007.color_ramp.interpolation = 'EASE'

            #initialize color ramp elements
            color_ramp_007.color_ramp.elements.remove(color_ramp_007.color_ramp.elements[0])
            color_ramp_007_cre_0 = color_ramp_007.color_ramp.elements[0]
            color_ramp_007_cre_0.position = 0.0
            color_ramp_007_cre_0.alpha = 1.0
            color_ramp_007_cre_0.color = (0.34097063541412354, 0.34097063541412354, 0.34097063541412354, 1.0)

            color_ramp_007_cre_1 = color_ramp_007.color_ramp.elements.new(0.14501509070396423)
            color_ramp_007_cre_1.alpha = 1.0
            color_ramp_007_cre_1.color = (0.3612447679042816, 0.3612447679042816, 0.3612447679042816, 1.0)

            color_ramp_007_cre_2 = color_ramp_007.color_ramp.elements.new(0.6842889785766602)
            color_ramp_007_cre_2.alpha = 1.0
            color_ramp_007_cre_2.color = (0.27948328852653503, 0.27948328852653503, 0.27948328852653503, 1.0)

            color_ramp_007_cre_3 = color_ramp_007.color_ramp.elements.new(1.0)
            color_ramp_007_cre_3.alpha = 1.0
            color_ramp_007_cre_3.color = (0.15406915545463562, 0.15406915545463562, 0.15406915545463562, 1.0)


            #node Mix.002
            mix_002 = realwood.nodes.new("ShaderNodeMix")
            mix_002.name = "Mix.002"
            mix_002.blend_type = 'MIX'
            mix_002.clamp_factor = True
            mix_002.clamp_result = True
            mix_002.data_type = 'RGBA'
            mix_002.factor_mode = 'UNIFORM'
            #A_Color
            mix_002.inputs[6].default_value = (0.5, 0.5, 0.5, 1.0)
            #B_Color
            mix_002.inputs[7].default_value = (1.0, 1.0, 1.0, 1.0)

            #node Frame.002
            frame_002 = realwood.nodes.new("NodeFrame")
            frame_002.label = "Specularity and Roughness map"
            frame_002.name = "Frame.002"
            frame_002.label_size = 20
            frame_002.shrink = True

            #node Frame.004
            frame_004 = realwood.nodes.new("NodeFrame")
            frame_004.label = "Final color mix"
            frame_004.name = "Frame.004"
            frame_004.label_size = 20
            frame_004.shrink = True

            #node Color Ramp.010
            color_ramp_010 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_010.name = "Color Ramp.010"
            color_ramp_010.color_ramp.color_mode = 'RGB'
            color_ramp_010.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_010.color_ramp.interpolation = 'B_SPLINE'

            #initialize color ramp elements
            color_ramp_010.color_ramp.elements.remove(color_ramp_010.color_ramp.elements[0])
            color_ramp_010_cre_0 = color_ramp_010.color_ramp.elements[0]
            color_ramp_010_cre_0.position = 0.2719033360481262
            color_ramp_010_cre_0.alpha = 1.0
            color_ramp_010_cre_0.color = (0.07603085041046143, 0.07603085041046143, 0.07603085041046143, 1.0)

            color_ramp_010_cre_1 = color_ramp_010.color_ramp.elements.new(0.5438064932823181)
            color_ramp_010_cre_1.alpha = 1.0
            color_ramp_010_cre_1.color = (0.27716273069381714, 0.27716273069381714, 0.27716273069381714, 1.0)

            color_ramp_010_cre_2 = color_ramp_010.color_ramp.elements.new(0.8610265254974365)
            color_ramp_010_cre_2.alpha = 1.0
            color_ramp_010_cre_2.color = (0.7268761396408081, 0.7268761396408081, 0.7268761396408081, 1.0)

            color_ramp_010_cre_3 = color_ramp_010.color_ramp.elements.new(1.0)
            color_ramp_010_cre_3.alpha = 1.0
            color_ramp_010_cre_3.color = (1.0, 1.0, 1.0, 1.0)


            #node Mix.006
            mix_006 = realwood.nodes.new("ShaderNodeMix")
            mix_006.name = "Mix.006"
            mix_006.blend_type = 'SUBTRACT'
            mix_006.clamp_factor = True
            mix_006.clamp_result = True
            mix_006.data_type = 'RGBA'
            mix_006.factor_mode = 'UNIFORM'
            #B_Color
            mix_006.inputs[7].default_value = (0.1660051792860031, 0.1660051792860031, 0.1660051792860031, 1.0)

            #node Color Ramp.024
            color_ramp_024 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_024.name = "Color Ramp.024"
            color_ramp_024.color_ramp.color_mode = 'RGB'
            color_ramp_024.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_024.color_ramp.interpolation = 'EASE'

            #initialize color ramp elements
            color_ramp_024.color_ramp.elements.remove(color_ramp_024.color_ramp.elements[0])
            color_ramp_024_cre_0 = color_ramp_024.color_ramp.elements[0]
            color_ramp_024_cre_0.position = 0.0
            color_ramp_024_cre_0.alpha = 1.0
            color_ramp_024_cre_0.color = (0.0, 0.0, 0.0, 1.0)

            color_ramp_024_cre_1 = color_ramp_024.color_ramp.elements.new(0.19770754873752594)
            color_ramp_024_cre_1.alpha = 1.0
            color_ramp_024_cre_1.color = (1.0, 1.0, 1.0, 1.0)


            #node Math.004
            math_004 = realwood.nodes.new("ShaderNodeMath")
            math_004.name = "Math.004"
            math_004.operation = 'DIVIDE'
            math_004.use_clamp = False
            #Value_001
            math_004.inputs[1].default_value = 4.0

            #node Vector Math
            vector_math = realwood.nodes.new("ShaderNodeVectorMath")
            vector_math.name = "Vector Math"
            vector_math.operation = 'NORMALIZE'

            #node Vector Math.001
            vector_math_001 = realwood.nodes.new("ShaderNodeVectorMath")
            vector_math_001.name = "Vector Math.001"
            vector_math_001.operation = 'ADD'

            #node Mix.001
            mix_001 = realwood.nodes.new("ShaderNodeMix")
            mix_001.name = "Mix.001"
            mix_001.blend_type = 'MIX'
            mix_001.clamp_factor = True
            mix_001.clamp_result = True
            mix_001.data_type = 'RGBA'
            mix_001.factor_mode = 'UNIFORM'

            #node Math
            math = realwood.nodes.new("ShaderNodeMath")
            math.name = "Math"
            math.operation = 'SUBTRACT'
            math.use_clamp = False
            #Value
            math.inputs[0].default_value = 1.0

            #node Mix.008
            mix_008 = realwood.nodes.new("ShaderNodeMix")
            mix_008.name = "Mix.008"
            mix_008.blend_type = 'MIX'
            mix_008.clamp_factor = True
            mix_008.clamp_result = False
            mix_008.data_type = 'RGBA'
            mix_008.factor_mode = 'UNIFORM'

            #node Mix.010
            mix_010 = realwood.nodes.new("ShaderNodeMix")
            mix_010.name = "Mix.010"
            mix_010.blend_type = 'LINEAR_LIGHT'
            mix_010.clamp_factor = True
            mix_010.clamp_result = True
            mix_010.data_type = 'RGBA'
            mix_010.factor_mode = 'UNIFORM'
            #B_Color
            mix_010.inputs[7].default_value = (0.4831109642982483, 0.4831109642982483, 0.4831109642982483, 1.0)

            #node Map Range
            map_range = realwood.nodes.new("ShaderNodeMapRange")
            map_range.name = "Map Range"
            map_range.clamp = True
            map_range.data_type = 'FLOAT'
            map_range.interpolation_type = 'LINEAR'
            #From Min
            map_range.inputs[1].default_value = 0.0
            #From Max
            map_range.inputs[2].default_value = 1.0
            #To Max
            map_range.inputs[4].default_value = 5.960464477539063e-08

            #node Map Range.005
            map_range_005 = realwood.nodes.new("ShaderNodeMapRange")
            map_range_005.name = "Map Range.005"
            map_range_005.clamp = True
            map_range_005.data_type = 'FLOAT'
            map_range_005.interpolation_type = 'LINEAR'
            #From Min
            map_range_005.inputs[1].default_value = 0.0
            #From Max
            map_range_005.inputs[2].default_value = 1.0
            #To Min
            map_range_005.inputs[3].default_value = -0.1899999976158142

            #node Mix.007
            mix_007 = realwood.nodes.new("ShaderNodeMix")
            mix_007.name = "Mix.007"
            mix_007.blend_type = 'DARKEN'
            mix_007.clamp_factor = False
            mix_007.clamp_result = False
            mix_007.data_type = 'RGBA'
            mix_007.factor_mode = 'UNIFORM'
            #B_Color
            mix_007.inputs[7].default_value = (0.10871119797229767, 0.10871119797229767, 0.10871119797229767, 1.0)

            #node Frame
            frame = realwood.nodes.new("NodeFrame")
            frame.name = "Frame"
            frame.label_size = 20
            frame.shrink = True

            #node Group Output
            group_output = realwood.nodes.new("NodeGroupOutput")
            group_output.name = "Group Output"
            group_output.is_active_output = True

            #node Group Input.001
            group_input_001 = realwood.nodes.new("NodeGroupInput")
            group_input_001.name = "Group Input.001"
            group_input_001.outputs[6].hide = True
            group_input_001.outputs[7].hide = True
            group_input_001.outputs[8].hide = True
            group_input_001.outputs[9].hide = True
            group_input_001.outputs[10].hide = True
            group_input_001.outputs[11].hide = True
            group_input_001.outputs[12].hide = True
            group_input_001.outputs[13].hide = True
            group_input_001.outputs[14].hide = True
            group_input_001.outputs[15].hide = True
            group_input_001.outputs[16].hide = True
            group_input_001.outputs[17].hide = True
            group_input_001.outputs[18].hide = True
            group_input_001.outputs[19].hide = True
            group_input_001.outputs[20].hide = True
            group_input_001.outputs[21].hide = True
            group_input_001.outputs[23].hide = True
            group_input_001.outputs[24].hide = True
            group_input_001.outputs[25].hide = True
            group_input_001.outputs[26].hide = True
            group_input_001.outputs[27].hide = True
            group_input_001.outputs[28].hide = True
            group_input_001.outputs[29].hide = True
            group_input_001.outputs[30].hide = True
            group_input_001.outputs[31].hide = True
            group_input_001.outputs[32].hide = True
            group_input_001.outputs[33].hide = True
            group_input_001.outputs[34].hide = True
            group_input_001.outputs[35].hide = True
            group_input_001.outputs[36].hide = True
            group_input_001.outputs[37].hide = True
            group_input_001.outputs[38].hide = True
            group_input_001.outputs[39].hide = True
            group_input_001.outputs[40].hide = True
            group_input_001.outputs[41].hide = True
            group_input_001.outputs[42].hide = True
            group_input_001.outputs[43].hide = True
            group_input_001.outputs[44].hide = True
            group_input_001.outputs[45].hide = True

            #node Reroute
            reroute = realwood.nodes.new("NodeReroute")
            reroute.name = "Reroute"
            reroute.socket_idname = "NodeSocketVector"
            #node Reroute.001
            reroute_001 = realwood.nodes.new("NodeReroute")
            reroute_001.name = "Reroute.001"
            reroute_001.socket_idname = "NodeSocketColor"
            #node Group Input.002
            group_input_002 = realwood.nodes.new("NodeGroupInput")
            group_input_002.name = "Group Input.002"
            group_input_002.outputs[0].hide = True
            group_input_002.outputs[1].hide = True
            group_input_002.outputs[2].hide = True
            group_input_002.outputs[3].hide = True
            group_input_002.outputs[4].hide = True
            group_input_002.outputs[5].hide = True
            group_input_002.outputs[13].hide = True
            group_input_002.outputs[14].hide = True
            group_input_002.outputs[15].hide = True
            group_input_002.outputs[16].hide = True
            group_input_002.outputs[17].hide = True
            group_input_002.outputs[18].hide = True
            group_input_002.outputs[19].hide = True
            group_input_002.outputs[20].hide = True
            group_input_002.outputs[21].hide = True
            group_input_002.outputs[22].hide = True
            group_input_002.outputs[23].hide = True
            group_input_002.outputs[25].hide = True
            group_input_002.outputs[26].hide = True
            group_input_002.outputs[27].hide = True
            group_input_002.outputs[28].hide = True
            group_input_002.outputs[29].hide = True
            group_input_002.outputs[30].hide = True
            group_input_002.outputs[31].hide = True
            group_input_002.outputs[32].hide = True
            group_input_002.outputs[33].hide = True
            group_input_002.outputs[34].hide = True
            group_input_002.outputs[35].hide = True
            group_input_002.outputs[36].hide = True
            group_input_002.outputs[37].hide = True
            group_input_002.outputs[38].hide = True
            group_input_002.outputs[39].hide = True
            group_input_002.outputs[40].hide = True
            group_input_002.outputs[41].hide = True
            group_input_002.outputs[42].hide = True
            group_input_002.outputs[43].hide = True
            group_input_002.outputs[44].hide = True
            group_input_002.outputs[45].hide = True

            #node Reroute.002
            reroute_002 = realwood.nodes.new("NodeReroute")
            reroute_002.name = "Reroute.002"
            reroute_002.socket_idname = "NodeSocketFloatFactor"
            #node Reroute.003
            reroute_003 = realwood.nodes.new("NodeReroute")
            reroute_003.name = "Reroute.003"
            reroute_003.socket_idname = "NodeSocketFloat"
            #node Reroute.004
            reroute_004 = realwood.nodes.new("NodeReroute")
            reroute_004.name = "Reroute.004"
            reroute_004.socket_idname = "NodeSocketColor"
            #node Reroute.005
            reroute_005 = realwood.nodes.new("NodeReroute")
            reroute_005.name = "Reroute.005"
            reroute_005.socket_idname = "NodeSocketColor"
            #node Reroute.006
            reroute_006 = realwood.nodes.new("NodeReroute")
            reroute_006.name = "Reroute.006"
            reroute_006.socket_idname = "NodeSocketVector"
            #node Group Input.003
            group_input_003 = realwood.nodes.new("NodeGroupInput")
            group_input_003.name = "Group Input.003"
            group_input_003.outputs[0].hide = True
            group_input_003.outputs[1].hide = True
            group_input_003.outputs[2].hide = True
            group_input_003.outputs[3].hide = True
            group_input_003.outputs[4].hide = True
            group_input_003.outputs[5].hide = True
            group_input_003.outputs[6].hide = True
            group_input_003.outputs[7].hide = True
            group_input_003.outputs[8].hide = True
            group_input_003.outputs[9].hide = True
            group_input_003.outputs[10].hide = True
            group_input_003.outputs[11].hide = True
            group_input_003.outputs[12].hide = True
            group_input_003.outputs[13].hide = True
            group_input_003.outputs[14].hide = True
            group_input_003.outputs[20].hide = True
            group_input_003.outputs[22].hide = True
            group_input_003.outputs[23].hide = True
            group_input_003.outputs[24].hide = True
            group_input_003.outputs[25].hide = True
            group_input_003.outputs[26].hide = True
            group_input_003.outputs[27].hide = True
            group_input_003.outputs[28].hide = True
            group_input_003.outputs[29].hide = True
            group_input_003.outputs[30].hide = True
            group_input_003.outputs[31].hide = True
            group_input_003.outputs[32].hide = True
            group_input_003.outputs[33].hide = True
            group_input_003.outputs[34].hide = True
            group_input_003.outputs[35].hide = True
            group_input_003.outputs[36].hide = True
            group_input_003.outputs[37].hide = True
            group_input_003.outputs[38].hide = True
            group_input_003.outputs[39].hide = True
            group_input_003.outputs[40].hide = True
            group_input_003.outputs[41].hide = True
            group_input_003.outputs[42].hide = True
            group_input_003.outputs[43].hide = True
            group_input_003.outputs[44].hide = True
            group_input_003.outputs[45].hide = True

            #node Reroute.007
            reroute_007 = realwood.nodes.new("NodeReroute")
            reroute_007.name = "Reroute.007"
            reroute_007.socket_idname = "NodeSocketFloat"
            #node Reroute.008
            reroute_008 = realwood.nodes.new("NodeReroute")
            reroute_008.name = "Reroute.008"
            reroute_008.socket_idname = "NodeSocketColor"
            #node Reroute.009
            reroute_009 = realwood.nodes.new("NodeReroute")
            reroute_009.name = "Reroute.009"
            reroute_009.socket_idname = "NodeSocketFloat"
            #node Group Input.004
            group_input_004 = realwood.nodes.new("NodeGroupInput")
            group_input_004.name = "Group Input.004"
            group_input_004.outputs[0].hide = True
            group_input_004.outputs[1].hide = True
            group_input_004.outputs[2].hide = True
            group_input_004.outputs[3].hide = True
            group_input_004.outputs[4].hide = True
            group_input_004.outputs[5].hide = True
            group_input_004.outputs[6].hide = True
            group_input_004.outputs[7].hide = True
            group_input_004.outputs[8].hide = True
            group_input_004.outputs[9].hide = True
            group_input_004.outputs[10].hide = True
            group_input_004.outputs[11].hide = True
            group_input_004.outputs[12].hide = True
            group_input_004.outputs[13].hide = True
            group_input_004.outputs[14].hide = True
            group_input_004.outputs[15].hide = True
            group_input_004.outputs[16].hide = True
            group_input_004.outputs[17].hide = True
            group_input_004.outputs[18].hide = True
            group_input_004.outputs[19].hide = True
            group_input_004.outputs[20].hide = True
            group_input_004.outputs[21].hide = True
            group_input_004.outputs[22].hide = True
            group_input_004.outputs[23].hide = True
            group_input_004.outputs[24].hide = True
            group_input_004.outputs[25].hide = True
            group_input_004.outputs[30].hide = True
            group_input_004.outputs[31].hide = True
            group_input_004.outputs[32].hide = True
            group_input_004.outputs[33].hide = True
            group_input_004.outputs[34].hide = True
            group_input_004.outputs[35].hide = True
            group_input_004.outputs[36].hide = True
            group_input_004.outputs[37].hide = True
            group_input_004.outputs[38].hide = True
            group_input_004.outputs[39].hide = True
            group_input_004.outputs[40].hide = True
            group_input_004.outputs[41].hide = True
            group_input_004.outputs[42].hide = True
            group_input_004.outputs[43].hide = True
            group_input_004.outputs[44].hide = True
            group_input_004.outputs[45].hide = True

            #node Group Input
            group_input = realwood.nodes.new("NodeGroupInput")
            group_input.name = "Group Input"
            group_input.outputs[0].hide = True
            group_input.outputs[1].hide = True
            group_input.outputs[2].hide = True
            group_input.outputs[3].hide = True
            group_input.outputs[4].hide = True
            group_input.outputs[5].hide = True
            group_input.outputs[6].hide = True
            group_input.outputs[7].hide = True
            group_input.outputs[8].hide = True
            group_input.outputs[9].hide = True
            group_input.outputs[10].hide = True
            group_input.outputs[11].hide = True
            group_input.outputs[12].hide = True
            group_input.outputs[13].hide = True
            group_input.outputs[14].hide = True
            group_input.outputs[15].hide = True
            group_input.outputs[16].hide = True
            group_input.outputs[17].hide = True
            group_input.outputs[18].hide = True
            group_input.outputs[19].hide = True
            group_input.outputs[20].hide = True
            group_input.outputs[21].hide = True
            group_input.outputs[22].hide = True
            group_input.outputs[23].hide = True
            group_input.outputs[24].hide = True
            group_input.outputs[25].hide = True
            group_input.outputs[26].hide = True
            group_input.outputs[27].hide = True
            group_input.outputs[28].hide = True
            group_input.outputs[29].hide = True
            group_input.outputs[30].hide = True
            group_input.outputs[35].hide = True
            group_input.outputs[39].hide = True
            group_input.outputs[40].hide = True
            group_input.outputs[41].hide = True
            group_input.outputs[42].hide = True
            group_input.outputs[43].hide = True
            group_input.outputs[44].hide = True
            group_input.outputs[45].hide = True

            #node Reroute.010
            reroute_010 = realwood.nodes.new("NodeReroute")
            reroute_010.name = "Reroute.010"
            reroute_010.socket_idname = "NodeSocketColor"
            #node Reroute.011
            reroute_011 = realwood.nodes.new("NodeReroute")
            reroute_011.name = "Reroute.011"
            reroute_011.socket_idname = "NodeSocketColor"
            #node Reroute.012
            reroute_012 = realwood.nodes.new("NodeReroute")
            reroute_012.name = "Reroute.012"
            reroute_012.socket_idname = "NodeSocketColor"
            #node Reroute.013
            reroute_013 = realwood.nodes.new("NodeReroute")
            reroute_013.name = "Reroute.013"
            reroute_013.socket_idname = "NodeSocketColor"
            #node Reroute.014
            reroute_014 = realwood.nodes.new("NodeReroute")
            reroute_014.name = "Reroute.014"
            reroute_014.socket_idname = "NodeSocketColor"
            #node Reroute.015
            reroute_015 = realwood.nodes.new("NodeReroute")
            reroute_015.name = "Reroute.015"
            reroute_015.socket_idname = "NodeSocketColor"
            #node Reroute.016
            reroute_016 = realwood.nodes.new("NodeReroute")
            reroute_016.name = "Reroute.016"
            reroute_016.hide = True
            reroute_016.socket_idname = "NodeSocketColor"
            #node Reroute.017
            reroute_017 = realwood.nodes.new("NodeReroute")
            reroute_017.name = "Reroute.017"
            reroute_017.socket_idname = "NodeSocketColor"
            #node Group Input.005
            group_input_005 = realwood.nodes.new("NodeGroupInput")
            group_input_005.name = "Group Input.005"
            group_input_005.outputs[0].hide = True
            group_input_005.outputs[1].hide = True
            group_input_005.outputs[2].hide = True
            group_input_005.outputs[3].hide = True
            group_input_005.outputs[4].hide = True
            group_input_005.outputs[5].hide = True
            group_input_005.outputs[6].hide = True
            group_input_005.outputs[7].hide = True
            group_input_005.outputs[8].hide = True
            group_input_005.outputs[9].hide = True
            group_input_005.outputs[10].hide = True
            group_input_005.outputs[11].hide = True
            group_input_005.outputs[12].hide = True
            group_input_005.outputs[15].hide = True
            group_input_005.outputs[16].hide = True
            group_input_005.outputs[17].hide = True
            group_input_005.outputs[18].hide = True
            group_input_005.outputs[19].hide = True
            group_input_005.outputs[21].hide = True
            group_input_005.outputs[22].hide = True
            group_input_005.outputs[24].hide = True
            group_input_005.outputs[26].hide = True
            group_input_005.outputs[27].hide = True
            group_input_005.outputs[28].hide = True
            group_input_005.outputs[29].hide = True
            group_input_005.outputs[31].hide = True
            group_input_005.outputs[32].hide = True
            group_input_005.outputs[33].hide = True
            group_input_005.outputs[34].hide = True
            group_input_005.outputs[36].hide = True
            group_input_005.outputs[37].hide = True
            group_input_005.outputs[38].hide = True
            group_input_005.outputs[40].hide = True
            group_input_005.outputs[41].hide = True
            group_input_005.outputs[42].hide = True
            group_input_005.outputs[43].hide = True
            group_input_005.outputs[44].hide = True
            group_input_005.outputs[45].hide = True

            #node Reroute.018
            reroute_018 = realwood.nodes.new("NodeReroute")
            reroute_018.name = "Reroute.018"
            reroute_018.socket_idname = "NodeSocketColor"
            #node Reroute.019
            reroute_019 = realwood.nodes.new("NodeReroute")
            reroute_019.name = "Reroute.019"
            reroute_019.socket_idname = "NodeSocketColor"
            #node Reroute.020
            reroute_020 = realwood.nodes.new("NodeReroute")
            reroute_020.name = "Reroute.020"
            reroute_020.socket_idname = "NodeSocketFloatFactor"
            #node Reroute.021
            reroute_021 = realwood.nodes.new("NodeReroute")
            reroute_021.name = "Reroute.021"
            reroute_021.socket_idname = "NodeSocketColor"
            #node Reroute.022
            reroute_022 = realwood.nodes.new("NodeReroute")
            reroute_022.name = "Reroute.022"
            reroute_022.socket_idname = "NodeSocketColor"
            #node Reroute.023
            reroute_023 = realwood.nodes.new("NodeReroute")
            reroute_023.name = "Reroute.023"
            reroute_023.socket_idname = "NodeSocketColor"
            #node Group Input.006
            group_input_006 = realwood.nodes.new("NodeGroupInput")
            group_input_006.name = "Group Input.006"
            group_input_006.outputs[0].hide = True
            group_input_006.outputs[1].hide = True
            group_input_006.outputs[2].hide = True
            group_input_006.outputs[3].hide = True
            group_input_006.outputs[4].hide = True
            group_input_006.outputs[5].hide = True
            group_input_006.outputs[6].hide = True
            group_input_006.outputs[7].hide = True
            group_input_006.outputs[8].hide = True
            group_input_006.outputs[9].hide = True
            group_input_006.outputs[10].hide = True
            group_input_006.outputs[11].hide = True
            group_input_006.outputs[12].hide = True
            group_input_006.outputs[13].hide = True
            group_input_006.outputs[14].hide = True
            group_input_006.outputs[15].hide = True
            group_input_006.outputs[16].hide = True
            group_input_006.outputs[17].hide = True
            group_input_006.outputs[18].hide = True
            group_input_006.outputs[19].hide = True
            group_input_006.outputs[20].hide = True
            group_input_006.outputs[21].hide = True
            group_input_006.outputs[22].hide = True
            group_input_006.outputs[23].hide = True
            group_input_006.outputs[24].hide = True
            group_input_006.outputs[25].hide = True
            group_input_006.outputs[26].hide = True
            group_input_006.outputs[27].hide = True
            group_input_006.outputs[28].hide = True
            group_input_006.outputs[29].hide = True
            group_input_006.outputs[30].hide = True
            group_input_006.outputs[31].hide = True
            group_input_006.outputs[32].hide = True
            group_input_006.outputs[33].hide = True
            group_input_006.outputs[34].hide = True
            group_input_006.outputs[35].hide = True
            group_input_006.outputs[36].hide = True
            group_input_006.outputs[37].hide = True
            group_input_006.outputs[38].hide = True
            group_input_006.outputs[39].hide = True
            group_input_006.outputs[42].hide = True
            group_input_006.outputs[43].hide = True
            group_input_006.outputs[44].hide = True
            group_input_006.outputs[45].hide = True

            #node Reroute.024
            reroute_024 = realwood.nodes.new("NodeReroute")
            reroute_024.name = "Reroute.024"
            reroute_024.socket_idname = "NodeSocketFloatFactor"
            #node Group Input.007
            group_input_007 = realwood.nodes.new("NodeGroupInput")
            group_input_007.name = "Group Input.007"
            group_input_007.outputs[0].hide = True
            group_input_007.outputs[1].hide = True
            group_input_007.outputs[2].hide = True
            group_input_007.outputs[3].hide = True
            group_input_007.outputs[4].hide = True
            group_input_007.outputs[5].hide = True
            group_input_007.outputs[6].hide = True
            group_input_007.outputs[7].hide = True
            group_input_007.outputs[8].hide = True
            group_input_007.outputs[9].hide = True
            group_input_007.outputs[10].hide = True
            group_input_007.outputs[11].hide = True
            group_input_007.outputs[12].hide = True
            group_input_007.outputs[13].hide = True
            group_input_007.outputs[14].hide = True
            group_input_007.outputs[15].hide = True
            group_input_007.outputs[16].hide = True
            group_input_007.outputs[17].hide = True
            group_input_007.outputs[18].hide = True
            group_input_007.outputs[19].hide = True
            group_input_007.outputs[20].hide = True
            group_input_007.outputs[21].hide = True
            group_input_007.outputs[22].hide = True
            group_input_007.outputs[23].hide = True
            group_input_007.outputs[24].hide = True
            group_input_007.outputs[25].hide = True
            group_input_007.outputs[26].hide = True
            group_input_007.outputs[27].hide = True
            group_input_007.outputs[28].hide = True
            group_input_007.outputs[29].hide = True
            group_input_007.outputs[30].hide = True
            group_input_007.outputs[31].hide = True
            group_input_007.outputs[32].hide = True
            group_input_007.outputs[33].hide = True
            group_input_007.outputs[34].hide = True
            group_input_007.outputs[35].hide = True
            group_input_007.outputs[36].hide = True
            group_input_007.outputs[37].hide = True
            group_input_007.outputs[38].hide = True
            group_input_007.outputs[39].hide = True
            group_input_007.outputs[40].hide = True
            group_input_007.outputs[41].hide = True
            group_input_007.outputs[45].hide = True

            #node Reroute.025
            reroute_025 = realwood.nodes.new("NodeReroute")
            reroute_025.name = "Reroute.025"
            reroute_025.socket_idname = "NodeSocketColor"
            #node Reroute.026
            reroute_026 = realwood.nodes.new("NodeReroute")
            reroute_026.name = "Reroute.026"
            reroute_026.socket_idname = "NodeSocketColor"
            #node Reroute.027
            reroute_027 = realwood.nodes.new("NodeReroute")
            reroute_027.name = "Reroute.027"
            reroute_027.socket_idname = "NodeSocketColor"
            #node Reroute.028
            reroute_028 = realwood.nodes.new("NodeReroute")
            reroute_028.name = "Reroute.028"
            reroute_028.socket_idname = "NodeSocketColor"
            #node Reroute.029
            reroute_029 = realwood.nodes.new("NodeReroute")
            reroute_029.name = "Reroute.029"
            reroute_029.socket_idname = "NodeSocketColor"
            #node Reroute.030
            reroute_030 = realwood.nodes.new("NodeReroute")
            reroute_030.name = "Reroute.030"
            reroute_030.socket_idname = "NodeSocketColor"
            #node Reroute.031
            reroute_031 = realwood.nodes.new("NodeReroute")
            reroute_031.name = "Reroute.031"
            reroute_031.socket_idname = "NodeSocketColor"
            #node Reroute.032
            reroute_032 = realwood.nodes.new("NodeReroute")
            reroute_032.name = "Reroute.032"
            reroute_032.socket_idname = "NodeSocketColor"
            #node Reroute.033
            reroute_033 = realwood.nodes.new("NodeReroute")
            reroute_033.name = "Reroute.033"
            reroute_033.socket_idname = "NodeSocketColor"
            #node Reroute.034
            reroute_034 = realwood.nodes.new("NodeReroute")
            reroute_034.name = "Reroute.034"
            reroute_034.socket_idname = "NodeSocketColor"
            #node Reroute.035
            reroute_035 = realwood.nodes.new("NodeReroute")
            reroute_035.name = "Reroute.035"
            reroute_035.socket_idname = "NodeSocketColor"
            #node Reroute.036
            reroute_036 = realwood.nodes.new("NodeReroute")
            reroute_036.name = "Reroute.036"
            reroute_036.socket_idname = "NodeSocketColor"
            #node Reroute.037
            reroute_037 = realwood.nodes.new("NodeReroute")
            reroute_037.name = "Reroute.037"
            reroute_037.socket_idname = "NodeSocketColor"
            #node Reroute.039
            reroute_039 = realwood.nodes.new("NodeReroute")
            reroute_039.name = "Reroute.039"
            reroute_039.socket_idname = "NodeSocketFloat"
            #node Reroute.040
            reroute_040 = realwood.nodes.new("NodeReroute")
            reroute_040.name = "Reroute.040"
            reroute_040.socket_idname = "NodeSocketFloat"
            #node Reroute.041
            reroute_041 = realwood.nodes.new("NodeReroute")
            reroute_041.name = "Reroute.041"
            reroute_041.socket_idname = "NodeSocketColor"
            #node Reroute.042
            reroute_042 = realwood.nodes.new("NodeReroute")
            reroute_042.name = "Reroute.042"
            reroute_042.socket_idname = "NodeSocketFloat"
            #node Color Ramp.001
            color_ramp_001 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_001.name = "Color Ramp.001"
            color_ramp_001.color_ramp.color_mode = 'RGB'
            color_ramp_001.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_001.color_ramp.interpolation = 'LINEAR'

            #initialize color ramp elements
            color_ramp_001.color_ramp.elements.remove(color_ramp_001.color_ramp.elements[0])
            color_ramp_001_cre_0 = color_ramp_001.color_ramp.elements[0]
            color_ramp_001_cre_0.position = 0.0
            color_ramp_001_cre_0.alpha = 1.0
            color_ramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

            color_ramp_001_cre_1 = color_ramp_001.color_ramp.elements.new(0.634441077709198)
            color_ramp_001_cre_1.alpha = 1.0
            color_ramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)


            #node Color Ramp.017
            color_ramp_017 = realwood.nodes.new("ShaderNodeValToRGB")
            color_ramp_017.name = "Color Ramp.017"
            color_ramp_017.color_ramp.color_mode = 'RGB'
            color_ramp_017.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_017.color_ramp.interpolation = 'LINEAR'

            #initialize color ramp elements
            color_ramp_017.color_ramp.elements.remove(color_ramp_017.color_ramp.elements[0])
            color_ramp_017_cre_0 = color_ramp_017.color_ramp.elements[0]
            color_ramp_017_cre_0.position = 0.0
            color_ramp_017_cre_0.alpha = 1.0
            color_ramp_017_cre_0.color = (0.0, 0.0, 0.0, 1.0)

            color_ramp_017_cre_1 = color_ramp_017.color_ramp.elements.new(0.13595233857631683)
            color_ramp_017_cre_1.alpha = 1.0
            color_ramp_017_cre_1.color = (1.0, 1.0, 1.0, 1.0)


            #node Reroute.043
            reroute_043 = realwood.nodes.new("NodeReroute")
            reroute_043.name = "Reroute.043"
            reroute_043.socket_idname = "NodeSocketColor"
            #node Mix.004
            mix_004 = realwood.nodes.new("ShaderNodeMix")
            mix_004.name = "Mix.004"
            mix_004.blend_type = 'MIX'
            mix_004.clamp_factor = True
            mix_004.clamp_result = True
            mix_004.data_type = 'RGBA'
            mix_004.factor_mode = 'UNIFORM'
            #Factor_Float
            mix_004.inputs[0].default_value = 0.15734803676605225

            #node Vector Math.002
            vector_math_002 = realwood.nodes.new("ShaderNodeVectorMath")
            vector_math_002.name = "Vector Math.002"
            vector_math_002.operation = 'ADD'
            #Vector
            vector_math_002.inputs[0].default_value = (0.0, 0.0, 0.0)

            #node Math.001
            math_001 = realwood.nodes.new("ShaderNodeMath")
            math_001.name = "Math.001"
            math_001.operation = 'LESS_THAN'
            math_001.use_clamp = False
            #Value_001
            math_001.inputs[1].default_value = 0.5000000596046448

            #Set parents
            vector_math_003.parent = frame_003
            vector_math_006.parent = frame_003
            separate_xyz.parent = frame
            math_005.parent = frame
            combine_xyz.parent = frame
            combine_xyz_001.parent = frame
            vector_math_007.parent = frame
            mapping_003.parent = frame_006
            voronoi_texture_005.parent = frame_006
            color_ramp.parent = frame_006
            mix_013.parent = frame_003
            vector_rotate.parent = frame_007
            white_noise_texture.parent = frame_007
            vector_math_027.parent = frame_007
            voronoi_texture_006.parent = frame_007
            combine_xyz_003.parent = frame_007
            math_011.parent = frame_007
            map_range_001.parent = frame_007
            vector_rotate_001.parent = frame_007
            combine_xyz_004.parent = frame_007
            math_012.parent = frame_007
            map_range_002.parent = frame_007
            mix_014.parent = frame_007
            white_noise_texture_002.parent = frame_007
            math_014.parent = frame_007
            math_019.parent = frame
            color_ramp_011.parent = frame_006
            mix_019.parent = frame_006
            invert_color_002.parent = frame_003
            voronoi_texture_008.parent = frame_009
            vector_math_013.parent = frame_009
            color_ramp_008.parent = frame_006
            vector_math_015.parent = frame_006
            mix_015.parent = frame_006
            color_ramp_012.parent = frame_006
            vector_math_026.parent = frame_006
            mix_017.parent = frame_004
            noise_texture_004.parent = frame_009
            noise_texture_005.parent = frame_010
            color_ramp_013.parent = frame_010
            mapping_005.parent = frame_010
            wave_texture_002.parent = frame_007
            color_ramp_014.parent = frame_007
            mix_016.parent = frame_007
            wave_texture_003.parent = frame_003
            mix_021.parent = frame_003
            invert_color_003.parent = frame_009
            mix_020.parent = frame_004
            mix_022.parent = frame_004
            invert_color_004.parent = frame_004
            color_ramp_016.parent = frame_006
            mix_023.parent = frame_004
            math_007.parent = frame_012
            mix_025.parent = frame_004
            mix_026.parent = frame_009
            mix_024.parent = frame_010
            color_ramp_018.parent = frame_010
            mix_027.parent = frame_004
            color_ramp_019.parent = frame_010
            color_ramp_021.parent = frame_004
            mix_028.parent = frame_012
            voronoi_texture_009.parent = frame_003
            mix_029.parent = frame_012
            color_ramp_022.parent = frame_006
            color_ramp_023.parent = frame_012
            noise_texture_008.parent = frame_003
            color_ramp_026.parent = frame_003
            mix_030.parent = frame_004
            invert_color_001.parent = frame_004
            mix_031.parent = frame_006
            invert_color_005.parent = frame_006
            color_ramp_015.parent = frame_006
            map_range_003.parent = frame_003
            math_008.parent = frame_003
            combine_xyz_005.parent = frame_009
            combine_xyz_006.parent = frame_006
            mapping_001.parent = frame_011
            separate_xyz_002.parent = frame_011
            combine_xyz_007.parent = frame_011
            voronoi_texture_004.parent = frame_011
            math_010.parent = frame_011
            mapping_006.parent = frame_011
            color_ramp_020.parent = frame_011
            mix_032.parent = frame_012
            mix_033.parent = frame_011
            mix_034.parent = frame_009
            mix_035.parent = frame_004
            combine_xyz_008.parent = frame_011
            map_range_004.parent = frame_009
            bump.parent = frame_001
            color_ramp_002.parent = frame_001
            color_ramp_003.parent = frame_001
            mix.parent = frame_001
            invert_color_007.parent = frame_001
            color_ramp_004.parent = frame_001
            mix_003.parent = frame_002
            color_ramp_005.parent = frame_002
            color_ramp_007.parent = frame_002
            mix_002.parent = frame_001
            color_ramp_010.parent = frame_002
            mix_006.parent = frame_002
            color_ramp_024.parent = frame_009
            vector_math.parent = frame_001
            vector_math_001.parent = frame_001
            mix_001.parent = frame_001
            mix_008.parent = frame_002
            mix_010.parent = frame_002
            map_range.parent = frame_002
            map_range_005.parent = frame_002
            mix_007.parent = frame_001
            reroute_001.parent = frame_003
            reroute_002.parent = frame_003
            reroute_003.parent = frame_003
            reroute_005.parent = frame_006
            reroute_007.parent = frame_006
            reroute_008.parent = frame_002
            reroute_009.parent = frame_003
            group_input_005.parent = frame_004
            reroute_019.parent = frame_004
            reroute_020.parent = frame_004
            reroute_021.parent = frame_004
            reroute_022.parent = frame_004
            reroute_023.parent = frame_004
            reroute_024.parent = frame_001
            group_input_007.parent = frame_002
            reroute_027.parent = frame_006
            reroute_039.parent = frame_006
            reroute_040.parent = frame_006
            reroute_043.parent = frame_002
            mix_004.parent = frame_001
            vector_math_002.parent = frame_006
            math_001.parent = frame_006

            #Set locations
            mapping.location = (-2678.443359375, -223.6182861328125)
            noise_texture_010.location = (-2403.630126953125, -536.7114868164062)
            mix_012.location = (-2220.739013671875, -321.4119873046875)
            frame_003.location = (71.69952392578125, 382.16400146484375)
            vector_math_003.location = (258.0068359375, -338.49072265625)
            vector_math_006.location = (28.68408203125, -322.71435546875)
            separate_xyz.location = (28.932373046875, -191.93896484375)
            math_005.location = (612.618408203125, -175.968994140625)
            combine_xyz.location = (1168.193115234375, -115.7178955078125)
            combine_xyz_001.location = (391.044677734375, -69.022705078125)
            vector_math_007.location = (637.698486328125, -29.74267578125)
            mapping_003.location = (-11.510482788085938, -578.3417358398438)
            voronoi_texture_005.location = (216.70298767089844, -658.8151245117188)
            color_ramp.location = (798.6432495117188, -544.5980834960938)
            frame_006.location = (131.6465301513672, -912.9393920898438)
            mix_013.location = (678.150634765625, -525.956298828125)
            vector_rotate.location = (1219.7626953125, -514.4083251953125)
            white_noise_texture.location = (302.7694091796875, -675.989990234375)
            vector_math_027.location = (187.57958984375, -309.1253662109375)
            voronoi_texture_006.location = (344.7763671875, -244.5948486328125)
            combine_xyz_003.location = (997.31201171875, -651.7515869140625)
            math_011.location = (830.24755859375, -658.6185302734375)
            map_range_001.location = (642.386962890625, -652.6328125)
            vector_rotate_001.location = (1220.62060546875, -269.0081787109375)
            combine_xyz_004.location = (995.22802734375, -517.3546142578125)
            math_012.location = (837.23291015625, -515.6912841796875)
            map_range_002.location = (642.083984375, -411.5394287109375)
            mix_014.location = (1395.151123046875, -114.97225952148438)
            white_noise_texture_002.location = (68.28955078125, -570.0535888671875)
            frame_007.location = (-1993.7352294921875, -423.0226135253906)
            math_014.location = (478.4031982421875, -560.3343505859375)
            math_019.location = (956.6590576171875, -2.96484375)
            color_ramp_011.location = (786.0802612304688, -775.6886596679688)
            mix_019.location = (1731.34619140625, -296.3948974609375)
            invert_color_002.location = (402.6978454589844, -490.69122314453125)
            voronoi_texture_008.location = (670.07275390625, -196.2685546875)
            vector_math_013.location = (478.14111328125, -233.64501953125)
            color_ramp_008.location = (741.67578125, -270.82440185546875)
            vector_math_015.location = (-165.61868286132812, -152.22406005859375)
            mix_015.location = (1713.511474609375, -41.3739013671875)
            color_ramp_012.location = (500.26806640625, -46.50030517578125)
            vector_math_026.location = (312.40240478515625, -191.36322021484375)
            mix_017.location = (997.39208984375, -344.1243896484375)
            noise_texture_004.location = (29.31591796875, -39.5576171875)
            frame_009.location = (1038.4288330078125, 2062.918212890625)
            noise_texture_005.location = (192.6064453125, -246.0185546875)
            color_ramp_013.location = (371.70166015625, -169.173828125)
            mapping_005.location = (29.3017578125, -39.275390625)
            frame_010.location = (2476.033447265625, 2869.394775390625)
            wave_texture_002.location = (28.83154296875, -51.1866455078125)
            color_ramp_014.location = (243.38818359375, -39.2113037109375)
            mix_016.location = (691.611328125, -126.9737548828125)
            wave_texture_003.location = (959.8988037109375, -562.3311767578125)
            mix_021.location = (2064.33984375, -519.2958374023438)
            invert_color_003.location = (895.841796875, -348.95654296875)
            mix_020.location = (594.60107421875, -279.565673828125)
            mix_022.location = (1164.62939453125, -370.98876953125)
            invert_color_004.location = (172.852783203125, -830.699462890625)
            color_ramp_016.location = (1321.4072265625, -614.9452514648438)
            mix_023.location = (1542.16015625, -279.926513671875)
            math_007.location = (29.2640380859375, -177.88427734375)
            frame_012.location = (1767.3016357421875, 1035.5748291015625)
            mix_025.location = (1741.556640625, -248.989990234375)
            mix_026.location = (1166.9931640625, -275.318359375)
            mix_024.location = (660.98876953125, -173.77734375)
            color_ramp_018.location = (378.02392578125, -373.325927734375)
            mix_027.location = (1980.67919921875, -39.57958984375)
            color_ramp_019.location = (819.96630859375, -63.38720703125)
            color_ramp_021.location = (381.6669921875, -679.301025390625)
            mix_028.location = (549.5614013671875, -143.833984375)
            voronoi_texture_009.location = (709.2899169921875, -172.92808532714844)
            mix_029.location = (746.6502685546875, -140.2890625)
            color_ramp_022.location = (1677.443115234375, -1083.6287841796875)
            color_ramp_023.location = (82.7462158203125, -350.00732421875)
            noise_texture_008.location = (1315.1776123046875, -328.9252014160156)
            color_ramp_026.location = (1496.177001953125, -405.7994384765625)
            mix_030.location = (681.693359375, -635.022216796875)
            invert_color_001.location = (453.53857421875, -912.337646484375)
            mix_031.location = (1905.40283203125, -706.2589111328125)
            invert_color_005.location = (1595.59375, -889.0433349609375)
            color_ramp_015.location = (1625.822509765625, -668.4168701171875)
            map_range_003.location = (1496.18603515625, -625.098876953125)
            math_008.location = (1324.7783203125, -791.505615234375)
            combine_xyz_005.location = (223.23828125, -196.89501953125)
            combine_xyz_006.location = (-207.73171997070312, -798.4038696289062)
            mapping_001.location = (-202.42315673828125, -157.704833984375)
            separate_xyz_002.location = (198.9423828125, -238.43603515625)
            combine_xyz_007.location = (594.64306640625, -185.337890625)
            voronoi_texture_004.location = (1147.632080078125, -37.083984375)
            math_010.location = (422.0693359375, -111.216796875)
            mapping_006.location = (786.97265625, -83.77783203125)
            color_ramp_020.location = (1318.9842529296875, -22.5498046875)
            frame_011.location = (441.366943359375, 3516.0615234375)
            mix_032.location = (948.7015380859375, -39.74755859375)
            mix_033.location = (1700.515625, -39.7041015625)
            mix_034.location = (1361.54150390625, -118.04541015625)
            mix_035.location = (2300.6826171875, -129.908203125)
            combine_xyz_008.location = (452.47216796875, -315.7978515625)
            map_range_004.location = (892.291015625, -75.90771484375)
            math_009.location = (1574.9117431640625, 1463.6578369140625)
            bump.location = (1460.2080078125, -285.755615234375)
            color_ramp_002.location = (821.45361328125, -47.96484375)
            color_ramp_003.location = (163.873046875, -257.26953125)
            mix.location = (826.62353515625, -451.278076171875)
            invert_color_007.location = (839.11083984375, -284.415771484375)
            color_ramp_004.location = (71.4951171875, -731.083984375)
            frame_001.location = (4107.0, 3456.833251953125)
            mix_003.location = (607.357666015625, -184.2078857421875)
            color_ramp_005.location = (281.67822265625, -486.3099365234375)
            color_ramp_007.location = (1275.323974609375, -84.30419921875)
            mix_002.location = (630.4287109375, -39.217041015625)
            frame_002.location = (3559.813232421875, -257.7757873535156)
            frame_004.location = (3905.0, 1458.83349609375)
            color_ramp_010.location = (1274.903076171875, -327.4798583984375)
            mix_006.location = (833.675537109375, -182.4412841796875)
            color_ramp_024.location = (1558.91650390625, -163.24365234375)
            math_004.location = (2142.852783203125, 2350.723388671875)
            vector_math.location = (1632.4794921875, -294.296630859375)
            vector_math_001.location = (1087.9521484375, -158.596435546875)
            mix_001.location = (524.615234375, -302.288818359375)
            math.location = (4405.1982421875, 3637.427001953125)
            mix_008.location = (351.447998046875, -220.7255859375)
            mix_010.location = (1010.110107421875, -184.3070068359375)
            map_range.location = (1633.320556640625, -99.66943359375)
            map_range_005.location = (1617.847900390625, -371.7802734375)
            mix_007.location = (534.62939453125, -655.2314453125)
            frame.location = (-2452.05712890625, -1417.1171875)
            group_output.location = (6976.51416015625, 1394.3992919921875)
            group_input_001.location = (-2980.634521484375, -615.8590087890625)
            reroute.location = (-72.98873138427734, 1303.2078857421875)
            reroute_001.location = (586.163818359375, -738.021728515625)
            group_input_002.location = (-225.5113067626953, -389.7282409667969)
            reroute_002.location = (1573.5147705078125, -971.2807006835938)
            reroute_003.location = (5.242156982421875, -264.20068359375)
            reroute_004.location = (1525.2427978515625, -853.029052734375)
            reroute_005.location = (1913.192138671875, -44.8333740234375)
            reroute_006.location = (-824.5811157226562, -1359.2298583984375)
            group_input_003.location = (-504.81536865234375, -2005.6220703125)
            reroute_007.location = (1757.657470703125, -1062.9739990234375)
            reroute_008.location = (762.460205078125, -592.3284912109375)
            reroute_009.location = (34.014617919921875, -241.8234405517578)
            group_input_004.location = (821.9016723632812, 1590.8724365234375)
            group_input.location = (522.5175170898438, 2892.403564453125)
            reroute_010.location = (3827.126220703125, 3054.331298828125)
            reroute_011.location = (1690.1214599609375, 1718.3382568359375)
            reroute_012.location = (993.0335083007812, 2477.072998046875)
            reroute_013.location = (696.2921752929688, 349.4176330566406)
            reroute_014.location = (3417.7529296875, -958.989990234375)
            reroute_015.location = (3730.188720703125, 112.6677474975586)
            reroute_016.location = (2485.183349609375, 393.4166564941406)
            reroute_017.location = (3534.908447265625, 1382.0072021484375)
            group_input_005.location = (28.9013671875, -1075.138427734375)
            reroute_018.location = (4508.24951171875, 359.4385681152344)
            reroute_019.location = (958.498046875, -1083.567138671875)
            reroute_020.location = (909.685546875, -1133.65185546875)
            reroute_021.location = (930.96142578125, -1177.109375)
            reroute_022.location = (963.2333984375, -1211.0439453125)
            reroute_023.location = (972.03759765625, -1257.7294921875)
            group_input_006.location = (4222.650390625, 3703.46875)
            reroute_024.location = (1344.94580078125, -53.068359375)
            group_input_007.location = (18.3642578125, -742.2313232421875)
            reroute_025.location = (6107.13916015625, 1535.082763671875)
            reroute_026.location = (3806.067626953125, 1433.1839599609375)
            reroute_027.location = (1218.3681640625, -860.3099365234375)
            reroute_028.location = (3554.989990234375, -197.9603729248047)
            reroute_029.location = (3412.402587890625, 438.0814514160156)
            reroute_030.location = (3457.764892578125, 393.534423828125)
            reroute_031.location = (6245.91650390625, 79.29325103759766)
            reroute_032.location = (3685.192626953125, 414.7626037597656)
            reroute_033.location = (3411.2607421875, 666.7603149414062)
            reroute_034.location = (3414.588134765625, 695.6953735351562)
            reroute_035.location = (3405.635498046875, 719.4674682617188)
            reroute_036.location = (3918.5556640625, 1514.8524169921875)
            reroute_037.location = (3540.497314453125, 1418.23486328125)
            reroute_039.location = (2154.314453125, 36.283935546875)
            reroute_040.location = (2111.818603515625, -1093.8321533203125)
            reroute_041.location = (2372.426025390625, 1657.3170166015625)
            reroute_042.location = (3449.844482421875, 348.4112243652344)
            color_ramp_001.location = (2951.8896484375, 1002.9633178710938)
            color_ramp_017.location = (3480.592529296875, 3182.990234375)
            reroute_043.location = (212.52490234375, -232.37744140625)
            mix_004.location = (1268.43212890625, -421.971435546875)
            vector_math_002.location = (406.0115966796875, -466.96148681640625)
            math_001.location = (96.08221435546875, -343.32391357421875)

            #Set dimensions
            mapping.width, mapping.height = 191.443359375, 100.0
            noise_texture_010.width, noise_texture_010.height = 140.0, 100.0
            mix_012.width, mix_012.height = 140.0, 100.0
            frame_003.width, frame_003.height = 2262.3916015625, 872.2833251953125
            vector_math_003.width, vector_math_003.height = 140.0, 100.0
            vector_math_006.width, vector_math_006.height = 140.0, 100.0
            separate_xyz.width, separate_xyz.height = 140.0, 100.0
            math_005.width, math_005.height = 140.0, 100.0
            combine_xyz.width, combine_xyz.height = 140.0, 100.0
            combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
            vector_math_007.width, vector_math_007.height = 140.0, 100.0
            mapping_003.width, mapping_003.height = 140.0, 100.0
            voronoi_texture_005.width, voronoi_texture_005.height = 140.0, 100.0
            color_ramp.width, color_ramp.height = 336.60400390625, 100.0
            frame_006.width, frame_006.height = 2425.294189453125, 1391.1778564453125
            mix_013.width, mix_013.height = 194.592041015625, 100.0
            vector_rotate.width, vector_rotate.height = 131.77734375, 100.0
            white_noise_texture.width, white_noise_texture.height = 140.0, 100.0
            vector_math_027.width, vector_math_027.height = 140.0, 100.0
            voronoi_texture_006.width, voronoi_texture_006.height = 140.0, 100.0
            combine_xyz_003.width, combine_xyz_003.height = 140.0, 100.0
            math_011.width, math_011.height = 140.0, 100.0
            map_range_001.width, map_range_001.height = 140.0, 100.0
            vector_rotate_001.width, vector_rotate_001.height = 140.0, 100.0
            combine_xyz_004.width, combine_xyz_004.height = 140.0, 100.0
            math_012.width, math_012.height = 140.0, 100.0
            map_range_002.width, map_range_002.height = 140.0, 100.0
            mix_014.width, mix_014.height = 140.0, 100.0
            white_noise_texture_002.width, white_noise_texture_002.height = 140.0, 100.0
            frame_007.width, frame_007.height = 1564.0, 910.5
            math_014.width, math_014.height = 140.0, 100.0
            math_019.width, math_019.height = 140.0, 100.0
            color_ramp_011.width, color_ramp_011.height = 348.62744140625, 100.0
            mix_019.width, mix_019.height = 140.0, 100.0
            invert_color_002.width, invert_color_002.height = 140.0, 100.0
            voronoi_texture_008.width, voronoi_texture_008.height = 140.0, 100.0
            vector_math_013.width, vector_math_013.height = 140.0, 100.0
            color_ramp_008.width, color_ramp_008.height = 429.79736328125, 100.0
            vector_math_015.width, vector_math_015.height = 140.0, 100.0
            mix_015.width, mix_015.height = 140.0, 100.0
            color_ramp_012.width, color_ramp_012.height = 336.60400390625, 100.0
            vector_math_026.width, vector_math_026.height = 140.0, 100.0
            mix_017.width, mix_017.height = 140.0, 100.0
            noise_texture_004.width, noise_texture_004.height = 140.0, 100.0
            frame_009.width, frame_009.height = 1839.5390625, 543.833251953125
            noise_texture_005.width, noise_texture_005.height = 140.0, 100.0
            color_ramp_013.width, color_ramp_013.height = 240.0, 100.0
            mapping_005.width, mapping_005.height = 140.0, 100.0
            frame_010.width, frame_010.height = 1088.666748046875, 600.5
            wave_texture_002.width, wave_texture_002.height = 150.0, 100.0
            color_ramp_014.width, color_ramp_014.height = 240.0, 100.0
            mix_016.width, mix_016.height = 140.0, 100.0
            wave_texture_003.width, wave_texture_003.height = 157.3142547607422, 100.0
            mix_021.width, mix_021.height = 140.0, 100.0
            invert_color_003.width, invert_color_003.height = 140.0, 100.0
            mix_020.width, mix_020.height = 140.0, 100.0
            mix_022.width, mix_022.height = 140.0, 100.0
            invert_color_004.width, invert_color_004.height = 140.0, 100.0
            color_ramp_016.width, color_ramp_016.height = 240.0, 100.0
            mix_023.width, mix_023.height = 140.0, 100.0
            math_007.width, math_007.height = 140.0, 100.0
            frame_012.width, frame_012.height = 1117.3333740234375, 577.1666259765625
            mix_025.width, mix_025.height = 140.0, 100.0
            mix_026.width, mix_026.height = 140.0, 100.0
            mix_024.width, mix_024.height = 140.0, 100.0
            color_ramp_018.width, color_ramp_018.height = 240.0, 100.0
            mix_027.width, mix_027.height = 140.0, 100.0
            color_ramp_019.width, color_ramp_019.height = 240.0, 100.0
            color_ramp_021.width, color_ramp_021.height = 240.0, 100.0
            mix_028.width, mix_028.height = 140.0, 100.0
            voronoi_texture_009.width, voronoi_texture_009.height = 140.0, 100.0
            mix_029.width, mix_029.height = 140.0, 100.0
            color_ramp_022.width, color_ramp_022.height = 336.60400390625, 100.0
            color_ramp_023.width, color_ramp_023.height = 240.0, 100.0
            noise_texture_008.width, noise_texture_008.height = 140.0, 100.0
            color_ramp_026.width, color_ramp_026.height = 240.0, 100.0
            mix_030.width, mix_030.height = 140.0, 100.0
            invert_color_001.width, invert_color_001.height = 140.0, 100.0
            mix_031.width, mix_031.height = 140.0, 100.0
            invert_color_005.width, invert_color_005.height = 140.0, 100.0
            color_ramp_015.width, color_ramp_015.height = 240.0, 100.0
            map_range_003.width, map_range_003.height = 140.0, 100.0
            math_008.width, math_008.height = 140.0, 100.0
            combine_xyz_005.width, combine_xyz_005.height = 140.0, 100.0
            combine_xyz_006.width, combine_xyz_006.height = 140.0, 100.0
            mapping_001.width, mapping_001.height = 140.0, 100.0
            separate_xyz_002.width, separate_xyz_002.height = 140.0, 100.0
            combine_xyz_007.width, combine_xyz_007.height = 140.0, 100.0
            voronoi_texture_004.width, voronoi_texture_004.height = 140.0, 100.0
            math_010.width, math_010.height = 140.0, 100.0
            mapping_006.width, mapping_006.height = 140.0, 100.0
            color_ramp_020.width, color_ramp_020.height = 280.618896484375, 100.0
            frame_011.width, frame_011.height = 2101.333251953125, 542.5
            mix_032.width, mix_032.height = 140.0, 100.0
            mix_033.width, mix_033.height = 140.0, 100.0
            mix_034.width, mix_034.height = 140.0, 100.0
            mix_035.width, mix_035.height = 140.0, 100.0
            combine_xyz_008.width, combine_xyz_008.height = 140.0, 100.0
            map_range_004.width, map_range_004.height = 140.0, 100.0
            math_009.width, math_009.height = 140.0, 100.0
            bump.width, bump.height = 140.0, 100.0
            color_ramp_002.width, color_ramp_002.height = 240.0, 100.0
            color_ramp_003.width, color_ramp_003.height = 240.0, 100.0
            mix.width, mix.height = 140.0, 100.0
            invert_color_007.width, invert_color_007.height = 140.0, 100.0
            color_ramp_004.width, color_ramp_004.height = 240.0, 100.0
            frame_001.width, frame_001.height = 1758.6669921875, 957.833251953125
            mix_003.width, mix_003.height = 140.0, 100.0
            color_ramp_005.width, color_ramp_005.height = 252.20556640625, 100.0
            color_ramp_007.width, color_ramp_007.height = 240.0, 100.0
            mix_002.width, mix_002.height = 140.0, 100.0
            frame_002.width, frame_002.height = 1813.33349609375, 817.1666259765625
            frame_004.width, frame_004.height = 2470.0, 1303.166748046875
            color_ramp_010.width, color_ramp_010.height = 240.0, 100.0
            mix_006.width, mix_006.height = 140.0, 100.0
            color_ramp_024.width, color_ramp_024.height = 252.20556640625, 100.0
            math_004.width, math_004.height = 140.0, 100.0
            vector_math.width, vector_math.height = 140.0, 100.0
            vector_math_001.width, vector_math_001.height = 140.0, 100.0
            mix_001.width, mix_001.height = 140.0, 100.0
            math.width, math.height = 140.0, 100.0
            mix_008.width, mix_008.height = 140.0, 100.0
            mix_010.width, mix_010.height = 140.0, 100.0
            map_range.width, map_range.height = 140.0, 100.0
            map_range_005.width, map_range_005.height = 140.0, 100.0
            mix_007.width, mix_007.height = 140.0, 100.0
            frame.width, frame.height = 1337.333251953125, 372.6666259765625
            group_output.width, group_output.height = 386.54620361328125, 100.0
            group_input_001.width, group_input_001.height = 129.0927734375, 100.0
            reroute.width, reroute.height = 16.0, 100.0
            reroute_001.width, reroute_001.height = 16.0, 100.0
            group_input_002.width, group_input_002.height = 158.3867950439453, 100.0
            reroute_002.width, reroute_002.height = 16.0, 100.0
            reroute_003.width, reroute_003.height = 16.0, 100.0
            reroute_004.width, reroute_004.height = 16.0, 100.0
            reroute_005.width, reroute_005.height = 16.0, 100.0
            reroute_006.width, reroute_006.height = 16.0, 100.0
            group_input_003.width, group_input_003.height = 191.396728515625, 100.0
            reroute_007.width, reroute_007.height = 16.0, 100.0
            reroute_008.width, reroute_008.height = 16.0, 100.0
            reroute_009.width, reroute_009.height = 16.0, 100.0
            group_input_004.width, group_input_004.height = 186.9952392578125, 100.0
            group_input.width, group_input.height = 303.2620849609375, 100.0
            reroute_010.width, reroute_010.height = 16.0, 100.0
            reroute_011.width, reroute_011.height = 16.0, 100.0
            reroute_012.width, reroute_012.height = 16.0, 100.0
            reroute_013.width, reroute_013.height = 16.0, 100.0
            reroute_014.width, reroute_014.height = 16.0, 100.0
            reroute_015.width, reroute_015.height = 16.0, 100.0
            reroute_016.width, reroute_016.height = 16.0, 100.0
            reroute_017.width, reroute_017.height = 16.0, 100.0
            group_input_005.width, group_input_005.height = 140.0, 100.0
            reroute_018.width, reroute_018.height = 16.0, 100.0
            reroute_019.width, reroute_019.height = 16.0, 100.0
            reroute_020.width, reroute_020.height = 16.0, 100.0
            reroute_021.width, reroute_021.height = 16.0, 100.0
            reroute_022.width, reroute_022.height = 16.0, 100.0
            reroute_023.width, reroute_023.height = 16.0, 100.0
            group_input_006.width, group_input_006.height = 140.0, 100.0
            reroute_024.width, reroute_024.height = 16.0, 100.0
            group_input_007.width, group_input_007.height = 140.0, 100.0
            reroute_025.width, reroute_025.height = 16.0, 100.0
            reroute_026.width, reroute_026.height = 16.0, 100.0
            reroute_027.width, reroute_027.height = 16.0, 100.0
            reroute_028.width, reroute_028.height = 16.0, 100.0
            reroute_029.width, reroute_029.height = 16.0, 100.0
            reroute_030.width, reroute_030.height = 16.0, 100.0
            reroute_031.width, reroute_031.height = 16.0, 100.0
            reroute_032.width, reroute_032.height = 16.0, 100.0
            reroute_033.width, reroute_033.height = 16.0, 100.0
            reroute_034.width, reroute_034.height = 16.0, 100.0
            reroute_035.width, reroute_035.height = 16.0, 100.0
            reroute_036.width, reroute_036.height = 16.0, 100.0
            reroute_037.width, reroute_037.height = 16.0, 100.0
            reroute_039.width, reroute_039.height = 16.0, 100.0
            reroute_040.width, reroute_040.height = 16.0, 100.0
            reroute_041.width, reroute_041.height = 16.0, 100.0
            reroute_042.width, reroute_042.height = 16.0, 100.0
            color_ramp_001.width, color_ramp_001.height = 240.0, 100.0
            color_ramp_017.width, color_ramp_017.height = 240.0, 100.0
            reroute_043.width, reroute_043.height = 16.0, 100.0
            mix_004.width, mix_004.height = 140.0, 100.0
            vector_math_002.width, vector_math_002.height = 140.0, 100.0
            math_001.width, math_001.height = 140.0, 100.0

            #initialize realwood links
            #mix_002.Result -> color_ramp_002.Fac
            realwood.links.new(mix_002.outputs[2], color_ramp_002.inputs[0])
            #map_range_004.Result -> mix_026.A
            realwood.links.new(map_range_004.outputs[0], mix_026.inputs[6])
            #separate_xyz_002.Y -> math_010.Value
            realwood.links.new(separate_xyz_002.outputs[1], math_010.inputs[1])
            #mix_022.Result -> mix_023.A
            realwood.links.new(mix_022.outputs[2], mix_023.inputs[6])
            #math_009.Value -> map_range_004.To Min
            realwood.links.new(math_009.outputs[0], map_range_004.inputs[3])
            #reroute_032.Output -> mix_007.Factor
            realwood.links.new(reroute_032.outputs[0], mix_007.inputs[0])
            #math_007.Value -> mix_028.Factor
            realwood.links.new(math_007.outputs[0], mix_028.inputs[0])
            #separate_xyz.X -> math_005.Value
            realwood.links.new(separate_xyz.outputs[0], math_005.inputs[0])
            #voronoi_texture_008.Distance -> map_range_004.Value
            realwood.links.new(voronoi_texture_008.outputs[0], map_range_004.inputs[0])
            #mix_017.Result -> mix_022.A
            realwood.links.new(mix_017.outputs[2], mix_022.inputs[6])
            #mix_020.Result -> mix_017.A
            realwood.links.new(mix_020.outputs[2], mix_017.inputs[6])
            #color_ramp_019.Color -> mix.Factor
            realwood.links.new(color_ramp_019.outputs[0], mix.inputs[0])
            #mix_034.Result -> color_ramp_024.Fac
            realwood.links.new(mix_034.outputs[2], color_ramp_024.inputs[0])
            #mapping_005.Vector -> noise_texture_005.Vector
            realwood.links.new(mapping_005.outputs[0], noise_texture_005.inputs[0])
            #vector_math_013.Vector -> mapping_005.Vector
            realwood.links.new(vector_math_013.outputs[0], mapping_005.inputs[0])
            #reroute_036.Output -> mix_027.Factor
            realwood.links.new(reroute_036.outputs[0], mix_027.inputs[0])
            #combine_xyz_008.Vector -> mapping_006.Scale
            realwood.links.new(combine_xyz_008.outputs[0], mapping_006.inputs[3])
            #reroute_008.Output -> mix_010.Factor
            realwood.links.new(reroute_008.outputs[0], mix_010.inputs[0])
            #mix_024.Result -> color_ramp_019.Fac
            realwood.links.new(mix_024.outputs[2], color_ramp_019.inputs[0])
            #reroute_025.Output -> mix_035.Factor
            realwood.links.new(reroute_025.outputs[0], mix_035.inputs[0])
            #mix_025.Result -> mix_027.A
            realwood.links.new(mix_025.outputs[2], mix_027.inputs[6])
            #mix_027.Result -> mix_035.A
            realwood.links.new(mix_027.outputs[2], mix_035.inputs[6])
            #invert_color_003.Color -> color_ramp_018.Fac
            realwood.links.new(invert_color_003.outputs[0], color_ramp_018.inputs[0])
            #color_ramp_020.Color -> mix_034.Factor
            realwood.links.new(color_ramp_020.outputs[0], mix_034.inputs[0])
            #color_ramp_018.Color -> mix_024.B
            realwood.links.new(color_ramp_018.outputs[0], mix_024.inputs[7])
            #mix_026.Result -> mix_034.A
            realwood.links.new(mix_026.outputs[2], mix_034.inputs[6])
            #color_ramp_013.Color -> mix_024.A
            realwood.links.new(color_ramp_013.outputs[0], mix_024.inputs[6])
            #reroute_012.Output -> mix_033.Factor
            realwood.links.new(reroute_012.outputs[0], mix_033.inputs[0])
            #color_ramp_020.Color -> mix_033.A
            realwood.links.new(color_ramp_020.outputs[0], mix_033.inputs[6])
            #mix_007.Result -> mix.A
            realwood.links.new(mix_007.outputs[2], mix.inputs[6])
            #reroute_034.Output -> mix_023.Factor
            realwood.links.new(reroute_034.outputs[0], mix_023.inputs[0])
            #reroute_041.Output -> mix_032.Factor
            realwood.links.new(reroute_041.outputs[0], mix_032.inputs[0])
            #mix_029.Result -> mix_032.A
            realwood.links.new(mix_029.outputs[2], mix_032.inputs[6])
            #mix_023.Result -> mix_025.A
            realwood.links.new(mix_023.outputs[2], mix_025.inputs[6])
            #invert_color_003.Color -> mix_026.B
            realwood.links.new(invert_color_003.outputs[0], mix_026.inputs[7])
            #color_ramp_016.Color -> invert_color_003.Color
            realwood.links.new(color_ramp_016.outputs[0], invert_color_003.inputs[1])
            #separate_xyz_002.Z -> combine_xyz_007.Z
            realwood.links.new(separate_xyz_002.outputs[2], combine_xyz_007.inputs[2])
            #combine_xyz_007.Vector -> mapping_006.Vector
            realwood.links.new(combine_xyz_007.outputs[0], mapping_006.inputs[0])
            #reroute_028.Output -> mix_006.Factor
            realwood.links.new(reroute_028.outputs[0], mix_006.inputs[0])
            #reroute_018.Output -> mix_020.A
            realwood.links.new(reroute_018.outputs[0], mix_020.inputs[6])
            #math_010.Value -> combine_xyz_007.X
            realwood.links.new(math_010.outputs[0], combine_xyz_007.inputs[0])
            #reroute_037.Output -> color_ramp_003.Fac
            realwood.links.new(reroute_037.outputs[0], color_ramp_003.inputs[0])
            #reroute_033.Output -> mix_017.B
            realwood.links.new(reroute_033.outputs[0], mix_017.inputs[7])
            #reroute_040.Output -> color_ramp_005.Fac
            realwood.links.new(reroute_040.outputs[0], color_ramp_005.inputs[0])
            #reroute_043.Output -> mix_008.Factor
            realwood.links.new(reroute_043.outputs[0], mix_008.inputs[0])
            #separate_xyz_002.X -> math_010.Value
            realwood.links.new(separate_xyz_002.outputs[0], math_010.inputs[0])
            #vector_math_003.Value -> invert_color_002.Color
            realwood.links.new(vector_math_003.outputs[1], invert_color_002.inputs[1])
            #vector_math_006.Vector -> vector_math_003.Vector
            realwood.links.new(vector_math_006.outputs[0], vector_math_003.inputs[0])
            #mix_014.Result -> mapping_003.Vector
            realwood.links.new(mix_014.outputs[1], mapping_003.inputs[0])
            #reroute_042.Output -> color_ramp_004.Fac
            realwood.links.new(reroute_042.outputs[0], color_ramp_004.inputs[0])
            #invert_color_007.Color -> vector_math_001.Vector
            realwood.links.new(invert_color_007.outputs[0], vector_math_001.inputs[1])
            #bump.Normal -> vector_math.Vector
            realwood.links.new(bump.outputs[0], vector_math.inputs[0])
            #mix_016.Result -> mix_014.Factor
            realwood.links.new(mix_016.outputs[2], mix_014.inputs[0])
            #voronoi_texture_006.Distance -> mix_016.B
            realwood.links.new(voronoi_texture_006.outputs[0], mix_016.inputs[7])
            #color_ramp_014.Color -> mix_016.A
            realwood.links.new(color_ramp_014.outputs[0], mix_016.inputs[6])
            #combine_xyz_006.Vector -> mapping_003.Scale
            realwood.links.new(combine_xyz_006.outputs[0], mapping_003.inputs[3])
            #wave_texture_002.Color -> color_ramp_014.Fac
            realwood.links.new(wave_texture_002.outputs[0], color_ramp_014.inputs[0])
            #reroute_001.Output -> mix_013.Factor
            realwood.links.new(reroute_001.outputs[0], mix_013.inputs[0])
            #vector_math_026.Vector -> color_ramp_012.Fac
            realwood.links.new(vector_math_026.outputs[0], color_ramp_012.inputs[0])
            #color_ramp_002.Color -> vector_math_001.Vector
            realwood.links.new(color_ramp_002.outputs[0], vector_math_001.inputs[0])
            #vector_math_015.Value -> vector_math_026.Vector
            realwood.links.new(vector_math_015.outputs[1], vector_math_026.inputs[0])
            #reroute.Output -> noise_texture_004.Vector
            realwood.links.new(reroute.outputs[0], noise_texture_004.inputs[0])
            #mix_001.Result -> invert_color_007.Color
            realwood.links.new(mix_001.outputs[2], invert_color_007.inputs[1])
            #color_ramp_008.Color -> mix_015.B
            realwood.links.new(color_ramp_008.outputs[0], mix_015.inputs[7])
            #noise_texture_004.Fac -> combine_xyz_005.Z
            realwood.links.new(noise_texture_004.outputs[0], combine_xyz_005.inputs[2])
            #vector_math_006.Vector -> vector_math_015.Vector
            realwood.links.new(vector_math_006.outputs[0], vector_math_015.inputs[0])
            #combine_xyz_005.Vector -> vector_math_013.Vector
            realwood.links.new(combine_xyz_005.outputs[0], vector_math_013.inputs[1])
            #vector_math_013.Vector -> voronoi_texture_008.Vector
            realwood.links.new(vector_math_013.outputs[0], voronoi_texture_008.inputs[0])
            #reroute_027.Output -> mix_019.A
            realwood.links.new(reroute_027.outputs[0], mix_019.inputs[6])
            #reroute.Output -> vector_math_013.Vector
            realwood.links.new(reroute.outputs[0], vector_math_013.inputs[0])
            #reroute_043.Output -> mix_003.Factor
            realwood.links.new(reroute_043.outputs[0], mix_003.inputs[0])
            #noise_texture_008.Fac -> color_ramp_026.Fac
            realwood.links.new(noise_texture_008.outputs[0], color_ramp_026.inputs[0])
            #mapping.Vector -> wave_texture_002.Vector
            realwood.links.new(mapping.outputs[0], wave_texture_002.inputs[0])
            #color_ramp_011.Color -> mix_019.B
            realwood.links.new(color_ramp_011.outputs[0], mix_019.inputs[7])
            #color_ramp_004.Color -> mix_007.A
            realwood.links.new(color_ramp_004.outputs[0], mix_007.inputs[6])
            #vector_math_007.Value -> math_019.Value
            realwood.links.new(vector_math_007.outputs[1], math_019.inputs[0])
            #white_noise_texture.Value -> math_014.Value
            realwood.links.new(white_noise_texture.outputs[0], math_014.inputs[1])
            #white_noise_texture_002.Value -> math_014.Value
            realwood.links.new(white_noise_texture_002.outputs[0], math_014.inputs[0])
            #math_014.Value -> map_range_002.Value
            realwood.links.new(math_014.outputs[0], map_range_002.inputs[0])
            #math_008.Value -> map_range_003.To Max
            realwood.links.new(math_008.outputs[0], map_range_003.inputs[4])
            #map_range_003.Result -> mix_021.A
            realwood.links.new(map_range_003.outputs[0], mix_021.inputs[6])
            #math_004.Value -> noise_texture_005.Roughness
            realwood.links.new(math_004.outputs[0], noise_texture_005.inputs[4])
            #wave_texture_003.Fac -> map_range_003.Value
            realwood.links.new(wave_texture_003.outputs[1], map_range_003.inputs[0])
            #mix_008.Result -> mix_003.B
            realwood.links.new(mix_008.outputs[2], mix_003.inputs[7])
            #map_range_001.Result -> math_011.Value
            realwood.links.new(map_range_001.outputs[0], math_011.inputs[0])
            #white_noise_texture_002.Value -> white_noise_texture.W
            realwood.links.new(white_noise_texture_002.outputs[0], white_noise_texture.inputs[1])
            #reroute_029.Output -> invert_color_004.Color
            realwood.links.new(reroute_029.outputs[0], invert_color_004.inputs[1])
            #math.Value -> mix_001.B
            realwood.links.new(math.outputs[0], mix_001.inputs[7])
            #vector_rotate_001.Vector -> mix_014.A
            realwood.links.new(vector_rotate_001.outputs[0], mix_014.inputs[4])
            #color_ramp_015.Color -> mix_031.Factor
            realwood.links.new(color_ramp_015.outputs[0], mix_031.inputs[0])
            #vector_rotate.Vector -> mix_014.B
            realwood.links.new(vector_rotate.outputs[0], mix_014.inputs[5])
            #color_ramp_016.Color -> color_ramp_015.Fac
            realwood.links.new(color_ramp_016.outputs[0], color_ramp_015.inputs[0])
            #reroute_006.Output -> vector_rotate_001.Vector
            realwood.links.new(reroute_006.outputs[0], vector_rotate_001.inputs[0])
            #invert_color_005.Color -> mix_031.A
            realwood.links.new(invert_color_005.outputs[0], mix_031.inputs[6])
            #noise_texture_005.Color -> color_ramp_013.Fac
            realwood.links.new(noise_texture_005.outputs[1], color_ramp_013.inputs[0])
            #reroute_027.Output -> invert_color_005.Color
            realwood.links.new(reroute_027.outputs[0], invert_color_005.inputs[1])
            #map_range_002.Result -> math_012.Value
            realwood.links.new(map_range_002.outputs[0], math_012.inputs[0])
            #invert_color_004.Color -> color_ramp_021.Fac
            realwood.links.new(invert_color_004.outputs[0], color_ramp_021.inputs[0])
            #combine_xyz_004.Vector -> vector_rotate_001.Rotation
            realwood.links.new(combine_xyz_004.outputs[0], vector_rotate_001.inputs[4])
            #reroute_027.Output -> color_ramp_016.Fac
            realwood.links.new(reroute_027.outputs[0], color_ramp_016.inputs[0])
            #color_ramp_003.Color -> mix_001.A
            realwood.links.new(color_ramp_003.outputs[0], mix_001.inputs[6])
            #white_noise_texture.Value -> map_range_001.Value
            realwood.links.new(white_noise_texture.outputs[0], map_range_001.inputs[0])
            #color_ramp_021.Color -> mix_030.A
            realwood.links.new(color_ramp_021.outputs[0], mix_030.inputs[6])
            #math_011.Value -> combine_xyz_003.X
            realwood.links.new(math_011.outputs[0], combine_xyz_003.inputs[0])
            #mix_030.Result -> mix_022.Factor
            realwood.links.new(mix_030.outputs[2], mix_022.inputs[0])
            #combine_xyz_003.Vector -> vector_rotate.Rotation
            realwood.links.new(combine_xyz_003.outputs[0], vector_rotate.inputs[4])
            #reroute_032.Output -> invert_color_001.Color
            realwood.links.new(reroute_032.outputs[0], invert_color_001.inputs[1])
            #vector_math_027.Vector -> voronoi_texture_006.Vector
            realwood.links.new(vector_math_027.outputs[0], voronoi_texture_006.inputs[0])
            #invert_color_001.Color -> mix_030.Factor
            realwood.links.new(invert_color_001.outputs[0], mix_030.inputs[0])
            #combine_xyz_001.Vector -> vector_math_027.Vector
            realwood.links.new(combine_xyz_001.outputs[0], vector_math_027.inputs[0])
            #reroute_006.Output -> vector_rotate.Vector
            realwood.links.new(reroute_006.outputs[0], vector_rotate.inputs[0])
            #reroute_017.Output -> mix_001.Factor
            realwood.links.new(reroute_017.outputs[0], mix_001.inputs[0])
            #color_ramp_005.Color -> mix_003.A
            realwood.links.new(color_ramp_005.outputs[0], mix_003.inputs[6])
            #separate_xyz.Z -> combine_xyz.Z
            realwood.links.new(separate_xyz.outputs[2], combine_xyz.inputs[2])
            #color_ramp_026.Color -> mix_021.B
            realwood.links.new(color_ramp_026.outputs[0], mix_021.inputs[7])
            #voronoi_texture_009.Distance -> color_ramp_023.Fac
            realwood.links.new(voronoi_texture_009.outputs[0], color_ramp_023.inputs[0])
            #mapping.Vector -> mix_012.A
            realwood.links.new(mapping.outputs[0], mix_012.inputs[6])
            #reroute_035.Output -> mix_020.Factor
            realwood.links.new(reroute_035.outputs[0], mix_020.inputs[0])
            #combine_xyz_001.Vector -> vector_math_007.Vector
            realwood.links.new(combine_xyz_001.outputs[0], vector_math_007.inputs[0])
            #math_012.Value -> combine_xyz_004.X
            realwood.links.new(math_012.outputs[0], combine_xyz_004.inputs[0])
            #separate_xyz.Y -> combine_xyz_001.Y
            realwood.links.new(separate_xyz.outputs[1], combine_xyz_001.inputs[1])
            #separate_xyz.X -> combine_xyz_001.X
            realwood.links.new(separate_xyz.outputs[0], combine_xyz_001.inputs[0])
            #math_005.Value -> combine_xyz.X
            realwood.links.new(math_005.outputs[0], combine_xyz.inputs[0])
            #mix_028.Result -> mix_029.A
            realwood.links.new(mix_028.outputs[2], mix_029.inputs[6])
            #separate_xyz.Y -> math_005.Value
            realwood.links.new(separate_xyz.outputs[1], math_005.inputs[1])
            #color_ramp_023.Color -> mix_028.A
            realwood.links.new(color_ramp_023.outputs[0], mix_028.inputs[6])
            #reroute_016.Output -> mix_029.Factor
            realwood.links.new(reroute_016.outputs[0], mix_029.inputs[0])
            #mix_012.Result -> vector_math_006.Vector
            realwood.links.new(mix_012.outputs[2], vector_math_006.inputs[0])
            #reroute_027.Output -> color_ramp_022.Fac
            realwood.links.new(reroute_027.outputs[0], color_ramp_022.inputs[0])
            #reroute_043.Output -> mix_008.A
            realwood.links.new(reroute_043.outputs[0], mix_008.inputs[6])
            #mapping.Vector -> noise_texture_010.Vector
            realwood.links.new(mapping.outputs[0], noise_texture_010.inputs[0])
            #vector_math_003.Value -> math_007.Value
            realwood.links.new(vector_math_003.outputs[1], math_007.inputs[0])
            #noise_texture_010.Color -> mix_012.B
            realwood.links.new(noise_texture_010.outputs[1], mix_012.inputs[7])
            #vector_math_003.Value -> voronoi_texture_009.Vector
            realwood.links.new(vector_math_003.outputs[1], voronoi_texture_009.inputs[0])
            #color_ramp_012.Color -> mix_015.A
            realwood.links.new(color_ramp_012.outputs[0], mix_015.inputs[6])
            #reroute_017.Output -> mix_025.Factor
            realwood.links.new(reroute_017.outputs[0], mix_025.inputs[0])
            #mix_035.Result -> group_output.Color
            realwood.links.new(mix_035.outputs[2], group_output.inputs[0])
            #map_range.Result -> group_output.Roughness
            realwood.links.new(map_range.outputs[0], group_output.inputs[1])
            #vector_math.Vector -> group_output.Normal
            realwood.links.new(vector_math.outputs[0], group_output.inputs[2])
            #map_range_005.Result -> group_output.Specularity
            realwood.links.new(map_range_005.outputs[0], group_output.inputs[3])
            #reroute_031.Output -> group_output.Knots Mask
            realwood.links.new(reroute_031.outputs[0], group_output.inputs[4])
            #group_input_001.Coordinates -> mapping.Vector
            realwood.links.new(group_input_001.outputs[0], mapping.inputs[0])
            #group_input_001.Center Location -> mapping.Location
            realwood.links.new(group_input_001.outputs[1], mapping.inputs[1])
            #group_input_001.Rotation -> mapping.Rotation
            realwood.links.new(group_input_001.outputs[2], mapping.inputs[2])
            #group_input_001.Noise Variation -> noise_texture_010.W
            realwood.links.new(group_input_001.outputs[5], noise_texture_010.inputs[1])
            #group_input_001.Noise Scale -> noise_texture_010.Scale
            realwood.links.new(group_input_001.outputs[4], noise_texture_010.inputs[2])
            #mapping.Vector -> reroute.Input
            realwood.links.new(mapping.outputs[0], reroute.inputs[0])
            #reroute_004.Output -> reroute_001.Input
            realwood.links.new(reroute_004.outputs[0], reroute_001.inputs[0])
            #reroute_003.Output -> voronoi_texture_009.Scale
            realwood.links.new(reroute_003.outputs[0], voronoi_texture_009.inputs[2])
            #group_input_002.Rings Scale -> wave_texture_003.Scale
            realwood.links.new(group_input_002.outputs[6], wave_texture_003.inputs[1])
            #group_input_002.Latewood Width -> math_008.Value
            realwood.links.new(group_input_002.outputs[7], math_008.inputs[0])
            #group_input_002.Rings Offset -> wave_texture_003.Phase Offset
            realwood.links.new(group_input_002.outputs[8], wave_texture_003.inputs[6])
            #group_input_002.Rings Distortion -> wave_texture_003.Distortion
            realwood.links.new(group_input_002.outputs[9], wave_texture_003.inputs[2])
            #group_input_002.Rings Detail Scale -> wave_texture_003.Detail Scale
            realwood.links.new(group_input_002.outputs[10], wave_texture_003.inputs[4])
            #reroute_002.Output -> mix_021.Factor
            realwood.links.new(reroute_002.outputs[0], mix_021.inputs[0])
            #group_input_002.Rings Noise Scale -> noise_texture_008.Scale
            realwood.links.new(group_input_002.outputs[12], noise_texture_008.inputs[2])
            #group_input_002.Rings Noise Factor -> reroute_002.Input
            realwood.links.new(group_input_002.outputs[11], reroute_002.inputs[0])
            #group_input_002.Rings Scale -> reroute_003.Input
            realwood.links.new(group_input_002.outputs[6], reroute_003.inputs[0])
            #reroute_005.Output -> reroute_004.Input
            realwood.links.new(reroute_005.outputs[0], reroute_004.inputs[0])
            #mix_019.Result -> reroute_005.Input
            realwood.links.new(mix_019.outputs[2], reroute_005.inputs[0])
            #combine_xyz.Vector -> reroute_006.Input
            realwood.links.new(combine_xyz.outputs[0], reroute_006.inputs[0])
            #group_input_003.Knots Scale -> voronoi_texture_005.Scale
            realwood.links.new(group_input_003.outputs[15], voronoi_texture_005.inputs[2])
            #group_input_003.Knots Variation -> voronoi_texture_005.W
            realwood.links.new(group_input_003.outputs[16], voronoi_texture_005.inputs[1])
            #reroute_007.Output -> mix_031.B
            realwood.links.new(reroute_007.outputs[0], mix_031.inputs[7])
            #group_input_003.Knots Tightness -> combine_xyz_006.X
            realwood.links.new(group_input_003.outputs[18], combine_xyz_006.inputs[0])
            #group_input_003.Knots Height -> combine_xyz_006.Z
            realwood.links.new(group_input_003.outputs[19], combine_xyz_006.inputs[2])
            #group_input_003.Knot Roughness -> voronoi_texture_005.Roughness
            realwood.links.new(group_input_003.outputs[21], voronoi_texture_005.inputs[4])
            #group_input_001.Knot Angle Seed -> white_noise_texture_002.W
            realwood.links.new(group_input_001.outputs[22], white_noise_texture_002.inputs[1])
            #group_input_003.Knots Coverage -> reroute_007.Input
            realwood.links.new(group_input_003.outputs[17], reroute_007.inputs[0])
            #reroute_014.Output -> reroute_008.Input
            realwood.links.new(reroute_014.outputs[0], reroute_008.inputs[0])
            #reroute_009.Output -> math_007.Value
            realwood.links.new(reroute_009.outputs[0], math_007.inputs[1])
            #group_input_002.Heartwood Radius -> reroute_009.Input
            realwood.links.new(group_input_002.outputs[24], reroute_009.inputs[0])
            #group_input_004.Pores Scale -> voronoi_texture_008.Scale
            realwood.links.new(group_input_004.outputs[26], voronoi_texture_008.inputs[2])
            #group_input_004.Pores Noise Scale -> noise_texture_004.Scale
            realwood.links.new(group_input_004.outputs[27], noise_texture_004.inputs[2])
            #group_input_004.Pores Width -> math_009.Value
            realwood.links.new(group_input_004.outputs[28], math_009.inputs[0])
            #group_input_004.Pores Roughness -> voronoi_texture_008.Roughness
            realwood.links.new(group_input_004.outputs[29], voronoi_texture_008.inputs[4])
            #group_input.Rays Scale -> voronoi_texture_004.Scale
            realwood.links.new(group_input.outputs[31], voronoi_texture_004.inputs[2])
            #group_input.Rays Tightness -> combine_xyz_008.X
            realwood.links.new(group_input.outputs[32], combine_xyz_008.inputs[0])
            #group_input.Rays Height -> combine_xyz_008.Z
            realwood.links.new(group_input.outputs[33], combine_xyz_008.inputs[2])
            #group_input.Rays Roughness -> voronoi_texture_004.Roughness
            realwood.links.new(group_input.outputs[34], voronoi_texture_004.inputs[4])
            #color_ramp_020.Color -> reroute_011.Input
            realwood.links.new(color_ramp_020.outputs[0], reroute_011.inputs[0])
            #reroute_013.Output -> reroute_012.Input
            realwood.links.new(reroute_013.outputs[0], reroute_012.inputs[0])
            #reroute_016.Output -> reroute_013.Input
            realwood.links.new(reroute_016.outputs[0], reroute_013.inputs[0])
            #color_ramp_022.Color -> reroute_014.Input
            realwood.links.new(color_ramp_022.outputs[0], reroute_014.inputs[0])
            #reroute_014.Output -> reroute_015.Input
            realwood.links.new(reroute_014.outputs[0], reroute_015.inputs[0])
            #color_ramp_022.Color -> reroute_016.Input
            realwood.links.new(color_ramp_022.outputs[0], reroute_016.inputs[0])
            #group_input.Flecks Variation -> noise_texture_005.W
            realwood.links.new(group_input.outputs[37], noise_texture_005.inputs[1])
            #group_input.Flecks Scale -> noise_texture_005.Scale
            realwood.links.new(group_input.outputs[36], noise_texture_005.inputs[2])
            #group_input.Flecks Roughness -> math_004.Value
            realwood.links.new(group_input.outputs[38], math_004.inputs[0])
            #color_ramp_024.Color -> reroute_017.Input
            realwood.links.new(color_ramp_024.outputs[0], reroute_017.inputs[0])
            #group_input_005.Latewood Color -> reroute_018.Input
            realwood.links.new(group_input_005.outputs[14], reroute_018.inputs[0])
            #group_input_005.Earlywood Color -> mix_020.B
            realwood.links.new(group_input_005.outputs[13], mix_020.inputs[7])
            #reroute_019.Output -> mix_022.B
            realwood.links.new(reroute_019.outputs[0], mix_022.inputs[7])
            #reroute_020.Output -> mix_017.Factor
            realwood.links.new(reroute_020.outputs[0], mix_017.inputs[0])
            #group_input_005.Knots Color -> reroute_019.Input
            realwood.links.new(group_input_005.outputs[23], reroute_019.inputs[0])
            #group_input_005.Knots Border -> reroute_020.Input
            realwood.links.new(group_input_005.outputs[20], reroute_020.inputs[0])
            #reroute_021.Output -> mix_025.B
            realwood.links.new(reroute_021.outputs[0], mix_025.inputs[7])
            #group_input_005.Pores Color -> reroute_021.Input
            realwood.links.new(group_input_005.outputs[30], reroute_021.inputs[0])
            #reroute_022.Output -> mix_027.B
            realwood.links.new(reroute_022.outputs[0], mix_027.inputs[7])
            #group_input_005.Flecks Color -> reroute_022.Input
            realwood.links.new(group_input_005.outputs[39], reroute_022.inputs[0])
            #reroute_023.Output -> mix_035.B
            realwood.links.new(reroute_023.outputs[0], mix_035.inputs[7])
            #group_input_005.Rays Color -> reroute_023.Input
            realwood.links.new(group_input_005.outputs[35], reroute_023.inputs[0])
            #reroute_024.Output -> bump.Strength
            realwood.links.new(reroute_024.outputs[0], bump.inputs[0])
            #group_input_006.Bump Pores Strength -> math.Value
            realwood.links.new(group_input_006.outputs[41], math.inputs[1])
            #group_input_006.Bump Strength -> reroute_024.Input
            realwood.links.new(group_input_006.outputs[40], reroute_024.inputs[0])
            #group_input_007.Reflection Ray Strength -> mix_008.B
            realwood.links.new(group_input_007.outputs[43], mix_008.inputs[7])
            #reroute_026.Output -> reroute_025.Input
            realwood.links.new(reroute_026.outputs[0], reroute_025.inputs[0])
            #reroute_010.Output -> reroute_026.Input
            realwood.links.new(reroute_010.outputs[0], reroute_026.inputs[0])
            #color_ramp.Color -> reroute_027.Input
            realwood.links.new(color_ramp.outputs[0], reroute_027.inputs[0])
            #reroute_017.Output -> reroute_028.Input
            realwood.links.new(reroute_017.outputs[0], reroute_028.inputs[0])
            #mix_031.Result -> reroute_029.Input
            realwood.links.new(mix_031.outputs[2], reroute_029.inputs[0])
            #mix_015.Result -> reroute_030.Input
            realwood.links.new(mix_015.outputs[2], reroute_030.inputs[0])
            #reroute_015.Output -> reroute_031.Input
            realwood.links.new(reroute_015.outputs[0], reroute_031.inputs[0])
            #reroute_015.Output -> reroute_032.Input
            realwood.links.new(reroute_015.outputs[0], reroute_032.inputs[0])
            #reroute_030.Output -> reroute_033.Input
            realwood.links.new(reroute_030.outputs[0], reroute_033.inputs[0])
            #mix_021.Result -> reroute_035.Input
            realwood.links.new(mix_021.outputs[2], reroute_035.inputs[0])
            #color_ramp_019.Color -> reroute_036.Input
            realwood.links.new(color_ramp_019.outputs[0], reroute_036.inputs[0])
            #mix_034.Result -> reroute_037.Input
            realwood.links.new(mix_034.outputs[2], reroute_037.inputs[0])
            #map_range_003.Result -> reroute_039.Input
            realwood.links.new(map_range_003.outputs[0], reroute_039.inputs[0])
            #reroute_039.Output -> reroute_040.Input
            realwood.links.new(reroute_039.outputs[0], reroute_040.inputs[0])
            #reroute_011.Output -> reroute_041.Input
            realwood.links.new(reroute_011.outputs[0], reroute_041.inputs[0])
            #map_range_003.Result -> reroute_042.Input
            realwood.links.new(map_range_003.outputs[0], reroute_042.inputs[0])
            #group_input_001.Scale -> mapping.Scale
            realwood.links.new(group_input_001.outputs[3], mapping.inputs[3])
            #group_input_007.Roughness -> map_range.To Min
            realwood.links.new(group_input_007.outputs[44], map_range.inputs[3])
            #group_input_005.Heartwood Color -> mix_023.B
            realwood.links.new(group_input_005.outputs[25], mix_023.inputs[7])
            #mix_032.Result -> color_ramp_001.Fac
            realwood.links.new(mix_032.outputs[2], color_ramp_001.inputs[0])
            #color_ramp_001.Color -> reroute_034.Input
            realwood.links.new(color_ramp_001.outputs[0], reroute_034.inputs[0])
            #mix_033.Result -> color_ramp_017.Fac
            realwood.links.new(mix_033.outputs[2], color_ramp_017.inputs[0])
            #color_ramp_017.Color -> reroute_010.Input
            realwood.links.new(color_ramp_017.outputs[0], reroute_010.inputs[0])
            #reroute_010.Output -> mix_002.Factor
            realwood.links.new(reroute_010.outputs[0], mix_002.inputs[0])
            #reroute_010.Output -> reroute_043.Input
            realwood.links.new(reroute_010.outputs[0], reroute_043.inputs[0])
            #wave_texture_003.Fac -> noise_texture_008.W
            realwood.links.new(wave_texture_003.outputs[1], noise_texture_008.inputs[1])
            #invert_color_002.Color -> mix_013.A
            realwood.links.new(invert_color_002.outputs[0], mix_013.inputs[6])
            #mix_003.Result -> mix_006.A
            realwood.links.new(mix_003.outputs[2], mix_006.inputs[6])
            #color_ramp_010.Color -> map_range_005.Value
            realwood.links.new(color_ramp_010.outputs[0], map_range_005.inputs[0])
            #mix_006.Result -> mix_010.A
            realwood.links.new(mix_006.outputs[2], mix_010.inputs[6])
            #mix_010.Result -> color_ramp_010.Fac
            realwood.links.new(mix_010.outputs[2], color_ramp_010.inputs[0])
            #color_ramp_007.Color -> map_range.Value
            realwood.links.new(color_ramp_007.outputs[0], map_range.inputs[0])
            #mix_010.Result -> color_ramp_007.Fac
            realwood.links.new(mix_010.outputs[2], color_ramp_007.inputs[0])
            #vector_math_001.Vector -> mix_004.A
            realwood.links.new(vector_math_001.outputs[0], mix_004.inputs[6])
            #mix.Result -> mix_004.B
            realwood.links.new(mix.outputs[2], mix_004.inputs[7])
            #mix_004.Result -> bump.Height
            realwood.links.new(mix_004.outputs[2], bump.inputs[2])
            #mapping_003.Vector -> voronoi_texture_005.Vector
            realwood.links.new(mapping_003.outputs[0], voronoi_texture_005.inputs[0])
            #voronoi_texture_005.Distance -> vector_math_002.Vector
            realwood.links.new(voronoi_texture_005.outputs[0], vector_math_002.inputs[1])
            #vector_math_002.Vector -> color_ramp.Fac
            realwood.links.new(vector_math_002.outputs[0], color_ramp.inputs[0])
            #vector_math_002.Vector -> color_ramp_008.Fac
            realwood.links.new(vector_math_002.outputs[0], color_ramp_008.inputs[0])
            #vector_math_002.Vector -> color_ramp_011.Fac
            realwood.links.new(vector_math_002.outputs[0], color_ramp_011.inputs[0])
            #color_ramp.Color -> invert_color_002.Fac
            realwood.links.new(color_ramp.outputs[0], invert_color_002.inputs[0])
            #mix_013.Result -> wave_texture_003.Vector
            realwood.links.new(mix_013.outputs[2], wave_texture_003.inputs[0])
            #reroute_001.Output -> mix_013.B
            realwood.links.new(reroute_001.outputs[0], mix_013.inputs[7])
            #group_input_007.Reflection Strength -> map_range_005.To Max
            realwood.links.new(group_input_007.outputs[42], map_range_005.inputs[4])
            #vector_math_015.Value -> math_001.Value
            realwood.links.new(vector_math_015.outputs[1], math_001.inputs[0])
            #voronoi_texture_004.Distance -> color_ramp_020.Fac
            realwood.links.new(voronoi_texture_004.outputs[0], color_ramp_020.inputs[0])
            #mapping_006.Vector -> voronoi_texture_004.Vector
            realwood.links.new(mapping_006.outputs[0], voronoi_texture_004.inputs[0])
            #mapping_001.Vector -> separate_xyz_002.Vector
            realwood.links.new(mapping_001.outputs[0], separate_xyz_002.inputs[0])
            #math_019.Value -> combine_xyz.Y
            realwood.links.new(math_019.outputs[0], combine_xyz.inputs[1])
            #mix_012.Result -> mapping_001.Vector
            realwood.links.new(mix_012.outputs[2], mapping_001.inputs[0])
            #mix_012.Result -> separate_xyz.Vector
            realwood.links.new(mix_012.outputs[2], separate_xyz.inputs[0])
            return realwood

        realwood = realwood_node_group()

        #initialize RealWood node group
        def realwood_1_node_group():

            realwood_1 = mat.node_tree
            #start with a clean node tree
            for node in realwood_1.nodes:
                realwood_1.nodes.remove(node)
            realwood_1.color_tag = 'NONE'
            realwood_1.description = ""
            realwood_1.default_group_node_width = 140
            

            #realwood_1 interface

            #initialize realwood_1 nodes
            #node Material Output
            material_output = realwood_1.nodes.new("ShaderNodeOutputMaterial")
            material_output.name = "Material Output"
            material_output.is_active_output = True
            material_output.target = 'ALL'
            #Displacement
            material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Thickness
            material_output.inputs[3].default_value = 0.0

            #node Principled BSDF
            principled_bsdf = realwood_1.nodes.new("ShaderNodeBsdfPrincipled")
            principled_bsdf.name = "Principled BSDF"
            principled_bsdf.distribution = 'MULTI_GGX'
            principled_bsdf.subsurface_method = 'RANDOM_WALK'
            #Metallic
            principled_bsdf.inputs[1].default_value = 0.0
            #IOR
            principled_bsdf.inputs[3].default_value = 1.5500000715255737
            #Alpha
            principled_bsdf.inputs[4].default_value = 1.0
            #Diffuse Roughness
            principled_bsdf.inputs[7].default_value = 0.0
            #Subsurface Weight
            principled_bsdf.inputs[8].default_value = 0.5
            #Subsurface Radius
            principled_bsdf.inputs[9].default_value = (1.468000054359436, 1.4744999408721924, 1.4805999994277954)
            #Subsurface Scale
            principled_bsdf.inputs[10].default_value = 0.0010000000474974513
            #Subsurface Anisotropy
            principled_bsdf.inputs[12].default_value = 0.5483383536338806
            #Specular Tint
            principled_bsdf.inputs[14].default_value = (1.0, 1.0, 1.0, 1.0)
            #Anisotropic Rotation
            principled_bsdf.inputs[16].default_value = 0.25
            #Transmission Weight
            principled_bsdf.inputs[18].default_value = 0.0
            #Coat Weight
            principled_bsdf.inputs[19].default_value = 0.0
            #Coat Roughness
            principled_bsdf.inputs[20].default_value = 0.0
            #Coat IOR
            principled_bsdf.inputs[21].default_value = 1.5
            #Coat Tint
            principled_bsdf.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
            #Coat Normal
            principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
            #Sheen Weight
            principled_bsdf.inputs[24].default_value = 0.0
            #Sheen Roughness
            principled_bsdf.inputs[25].default_value = 0.5
            #Sheen Tint
            principled_bsdf.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
            #Emission Color
            principled_bsdf.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
            #Emission Strength
            principled_bsdf.inputs[28].default_value = 0.0
            #Thin Film Thickness
            principled_bsdf.inputs[29].default_value = 0.0
            #Thin Film IOR
            principled_bsdf.inputs[30].default_value = 1.3300000429153442

            #node Texture Coordinate
            texture_coordinate = realwood_1.nodes.new("ShaderNodeTexCoord")
            texture_coordinate.name = "Texture Coordinate"
            texture_coordinate.from_instancer = False

            #node Tangent
            tangent = realwood_1.nodes.new("ShaderNodeTangent")
            tangent.name = "Tangent"
            tangent.axis = 'Z'
            tangent.direction_type = 'RADIAL'
            tangent.uv_map = ""

            #node Frame
            frame_1 = realwood_1.nodes.new("NodeFrame")
            frame_1.name = "Frame"
            frame_1.label_size = 20
            frame_1.shrink = True

            #node Value.002
            value_002 = realwood_1.nodes.new("ShaderNodeValue")
            value_002.label = "Anisotropic reflection amount"
            value_002.name = "Value.002"

            value_002.outputs[0].default_value = 0.49999991059303284
            #node Mix.004
            mix_004_1 = realwood_1.nodes.new("ShaderNodeMix")
            mix_004_1.name = "Mix.004"
            mix_004_1.blend_type = 'MIX'
            mix_004_1.clamp_factor = True
            mix_004_1.clamp_result = False
            mix_004_1.data_type = 'FLOAT'
            mix_004_1.factor_mode = 'UNIFORM'
            #B_Float
            mix_004_1.inputs[3].default_value = 0.0

            #node Group
            group = realwood_1.nodes.new("ShaderNodeGroup")
            group.name = "Group"
            group.node_tree = realwood
            #Socket_8
            group.inputs[1].default_value = (0.0, 0.0, 0.0)
            #Socket_9
            group.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Socket_10
            group.inputs[3].default_value = (2.799999952316284, 2.6000001430511475, 0.6000000238418579)
            #Socket_12
            group.inputs[4].default_value = 0.0
            #Socket_11
            group.inputs[5].default_value = 2.8999998569488525
            #Socket_13
            group.inputs[6].default_value = 3.0
            #Socket_14
            group.inputs[7].default_value = 0.3009999692440033
            #Socket_15
            group.inputs[8].default_value = 48.79999923706055
            #Socket_16
            group.inputs[9].default_value = 1.5
            #Socket_17
            group.inputs[10].default_value = 13.300000190734863
            #Socket_18
            group.inputs[11].default_value = 1.0
            #Socket_19
            group.inputs[12].default_value = 41.79999923706055
            #Socket_40
            group.inputs[13].default_value = (0.23073875904083252, 0.15592660009860992, 0.08228275179862976, 1.0)
            #Socket_39
            group.inputs[14].default_value = (0.05286034569144249, 0.04091523587703705, 0.028426049277186394, 1.0)
            #Socket_20
            group.inputs[15].default_value = 0.43199989199638367
            #Socket_21
            group.inputs[16].default_value = 7.4000020027160645
            #Socket_22
            group.inputs[17].default_value = 1.0
            #Socket_23
            group.inputs[18].default_value = 3.299999952316284
            #Socket_24
            group.inputs[19].default_value = 4.0
            #Socket_42
            group.inputs[20].default_value = 1.0
            #Socket_25
            group.inputs[21].default_value = 0.0
            #Socket_26
            group.inputs[22].default_value = 68.70001220703125
            #Socket_41
            group.inputs[23].default_value = (0.0759604424238205, 0.032460059970617294, 0.01474732905626297, 1.0)
            #Socket_27
            group.inputs[24].default_value = 1.5999999046325684
            #Socket_43
            group.inputs[25].default_value = (0.002778589027002454, 0.0023477396462112665, 0.001788426423445344, 1.0)
            #Socket_28
            group.inputs[26].default_value = 114.0999984741211
            #Socket_29
            group.inputs[27].default_value = 0.7999999523162842
            #Socket_30
            group.inputs[28].default_value = 0.20000001788139343
            #Socket_31
            group.inputs[29].default_value = 0.640668511390686
            #Socket_44
            group.inputs[30].default_value = (0.10844108462333679, 0.06349866092205048, 0.02850329503417015, 1.0)
            #Socket_32
            group.inputs[31].default_value = 13.69999885559082
            #Socket_33
            group.inputs[32].default_value = 14.399999618530273
            #Socket_34
            group.inputs[33].default_value = 0.03999997675418854
            #Socket_35
            group.inputs[34].default_value = 0.9736967086791992
            #Socket_46
            group.inputs[35].default_value = (0.23746611177921295, 0.15854863822460175, 0.07315723598003387, 1.0)
            #Socket_36
            group.inputs[36].default_value = 29.200000762939453
            #Socket_37
            group.inputs[37].default_value = 67.80001068115234
            #Socket_38
            group.inputs[38].default_value = 0.3999999761581421
            #Socket_45
            group.inputs[39].default_value = (0.05139898881316185, 0.021688813343644142, 0.003315012203529477, 1.0)
            #Socket_47
            group.inputs[40].default_value = 1.0
            #Socket_48
            group.inputs[41].default_value = 1.0
            #Socket_49
            group.inputs[42].default_value = 0.0
            #Socket_50
            group.inputs[43].default_value = 0.3999999761581421
            #Socket_87
            group.inputs[44].default_value = 1.0

            #Set parents
            material_output.parent = frame_1
            principled_bsdf.parent = frame_1
            tangent.parent = frame_1
            value_002.parent = frame_1
            mix_004_1.parent = frame_1

            #Set locations
            material_output.location = (797.581787109375, -28.9722900390625)
            principled_bsdf.location = (497.2030029296875, -25.835205078125)
            texture_coordinate.location = (-3053.052734375, -1804.67529296875)
            tangent.location = (235.940185546875, -632.8272705078125)
            frame_1.location = (-2263.666748046875, -1862.3333740234375)
            value_002.location = (86.228515625, -539.6580810546875)
            mix_004_1.location = (281.1185302734375, -449.5989990234375)
            group.location = (-2625.73583984375, -1740.4212646484375)

            #Set dimensions
            material_output.width, material_output.height = 218.076904296875, 100.0
            principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
            texture_coordinate.width, texture_coordinate.height = 245.63330078125, 100.0
            tangent.width, tangent.height = 150.0, 100.0
            frame_1.width, frame_1.height = 987.41015625, 765.333251953125
            value_002.width, value_002.height = 140.0, 100.0
            mix_004_1.width, mix_004_1.height = 140.0, 100.0
            group.width, group.height = 258.8338317871094, 100.0

            #initialize realwood_1 links
            #tangent.Tangent -> principled_bsdf.Tangent
            realwood_1.links.new(tangent.outputs[0], principled_bsdf.inputs[17])
            #value_002.Value -> mix_004_1.A
            realwood_1.links.new(value_002.outputs[0], mix_004_1.inputs[2])
            #group.Knots Mask -> mix_004_1.Factor
            realwood_1.links.new(group.outputs[4], mix_004_1.inputs[0])
            #texture_coordinate.Object -> group.Coordinates
            realwood_1.links.new(texture_coordinate.outputs[3], group.inputs[0])
            #group.Color -> principled_bsdf.Base Color
            realwood_1.links.new(group.outputs[0], principled_bsdf.inputs[0])
            #mix_004_1.Result -> principled_bsdf.Anisotropic
            realwood_1.links.new(mix_004_1.outputs[0], principled_bsdf.inputs[15])
            #principled_bsdf.BSDF -> material_output.Surface
            realwood_1.links.new(principled_bsdf.outputs[0], material_output.inputs[0])
            #group.Roughness -> principled_bsdf.Roughness
            realwood_1.links.new(group.outputs[1], principled_bsdf.inputs[2])
            #group.Specularity -> principled_bsdf.Specular IOR Level
            realwood_1.links.new(group.outputs[3], principled_bsdf.inputs[13])
            #group.Normal -> principled_bsdf.Normal
            realwood_1.links.new(group.outputs[2], principled_bsdf.inputs[5])
            return realwood_1

        realwood_1 = realwood_1_node_group()

        return {'FINISHED'}
def menu_func(self, context):
    self.layout.operator(RealWood.bl_idname)

def register():
    bpy.utils.register_class(RealWood)
    bpy.types.NODE_MT_add.append(menu_func)

def unregister():
    bpy.utils.unregister_class(RealWood)
    bpy.types.NODE_MT_add.remove(menu_func)

if __name__ == "__main__":
    register()
